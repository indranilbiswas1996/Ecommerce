<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(backend_full_access_check() == true){
    //if($_SESSION['shop_uid'] != null || $_SESSION['shop_uid'] != ""){
        if(isset($_POST['xcsrf']) ){
            if($_POST['xcsrf'] == $csrf_token) {
                $shop_type =htmlspecialchars($_POST["shop_type"]);
                $shop_type_hidden = htmlspecialchars($_POST["shop_type_hidden"]);
                if(empty($shop_type)){
                    $code = 400;
                    $msg .= "<li>Enter main category</li>";
                }          
                if(empty($msg)){
                    include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                    $one = 1;
                    if($shop_type_hidden == 0){
                        $stmt = $conn->prepare("INSERT INTO shop_type (shop_type_details,status) VALUES (?,?)"); 
                        $stmt->bind_param('ss', $shop_type, $one);
                        $stmt->execute();
                        $stmt->close();
                        $code = 200;
                        $msg .= "Success";
                    }
                    if($shop_type_hidden > 0){
                        $stmt = $conn->prepare("UPDATE shop_type SET shop_type_details = ? WHERE id = ?"); 
                        $stmt->bind_param('ss', $shop_type, $shop_type_hidden);
                        $stmt->execute();
                        $stmt->close();
                        $code = 200;
                        $msg .= "Success";
                    }                    
                    $conn->close();
                }else{
                    $code = 400;
                }
            }
        }
    //}
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>