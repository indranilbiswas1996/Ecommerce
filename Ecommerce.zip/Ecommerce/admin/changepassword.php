<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
if(login_check() != true){
    header("Location: login.php");
}
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
<?php include 'header.php';?>
<div class="container">
    <div class="login-container">
            <div class="login-div">
                <div class="login-part">
                    <!-- Change password -->
                    <div class="login-part-inner" id="login_div" >
                        <div class="headline"><span>Change password</span></div>
                        <div class="alert alert-danger" id="login_err">
                        </div>
                        <div class="login-item">
                            <input type="text" name="userid" id="userid" class="login-textbox" value="<?php echo $_SESSION['phone']; ?>" disabled>
                        </div>
                        <div class="login-item">
                            <input type="password" name="n_password" id="n_password" class="login-textbox" placeholder="New password">
                        </div>
                        <div class="login-item">
                            <input type="password" name="c_password" id="c_password" class="login-textbox" placeholder="Confirm password">
                        </div>
                        <div class="login-item">
                            <button type="submit" class="login-button background-green" name="change_pass" id="change_pass" onclick="change_pass()" >Change password</button>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    
    <img src="icons/banner.png" class="banner"/>
</div>
<script type="text/javascript">
    function change_pass(){
        var n_password = document.getElementById('n_password').value;
        var c_password = document.getElementById('c_password').value;
        var err = "";
        if(n_password==""){
            err +=  '<li>Enter password</li>'; 
        }
        if(c_password==""){
            err +=  '<li>Enter confirm password</li>'; 
        }
        if(err != ""){         
            $("#login_err").html("<ul>"+err+"</ul>");
            $("#login_err").css("display","block");
        }else{
            var ajaxRequest, fd;
            try {
                ajaxRequest = new XMLHttpRequest();
            }catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                }catch (e) {
                    try{
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    }catch (e){
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }
            ajaxRequest.onreadystatechange = function(){
                if(ajaxRequest.readyState == 4){
                    var data = JSON.parse(ajaxRequest.responseText);
                    if(data.code == "200"){
                        alert("Password changed successfully!\nPlease log in again!");
                        window.location = "logout.php";
                    }else{
                        $("#login_err").html("<ul>"+data.msg+"</ul>");
                        $("#login_err").css("display","block");
                    }
                }
            }
            fd = new FormData();
            fd.append("n_password", n_password);  
            fd.append("c_password", c_password);   
            fd.append("xcsrf", "<?php echo $csrf_token;?>");          
            ajaxRequest.open("POST", "changepassword_background.php", true);
            ajaxRequest.send(fd);
        }
        
    }
</script>
</body>
</html>