/*-------------------- admin ----------------- Editable */

CREATE TABLE admin( 
    id           BIGINT(20) NOT NULL auto_increment PRIMARY KEY, 
    shop_uid     VARCHAR(100) NULL, /*fk shop */
    f_name       VARCHAR(40) NOT NULL, 
    m_name       VARCHAR(40), 
    l_name       VARCHAR(40), 
    gender       TINYINT(1) NULL, 
    phone        BIGINT(20) NOT NULL, 
    verify_phone TINYINT(1) NOT NULL DEFAULT 0, 
    email        VARCHAR(100), 
    verify_email TINYINT(1) DEFAULT 0, 
    admin_type   TINYINT(1) NOT NULL, /*Admin-Super admin */
    admin_status TINYINT(1) NOT NULL, /*Active-Inactive */
    password     VARCHAR(256) NOT NULL,
    created_time timestamp NULL DEFAULT current_timestamp(),
    approve_time timestamp NULL
);
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('admin','admin_type',0,'Super Admin');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('admin','admin_type',1,'Admin');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('admin','admin_type',2,'Moderator');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('admin','admin_status',1,'Active');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('admin','admin_status',0,'Inactive');

/*-----------   shop_type      -------------- Editable*/
CREATE TABLE shop_type( 
	id                INT(4) NOT NULL auto_increment PRIMARY KEY, 
	shop_type_details VARCHAR(100), 
	status            TINYINT(1) NOT NULL /*Active-Inactive */ 
); 
INSERT INTO `shop_type`( `shop_type_details`, `status`) VALUES ('Electronics',1);
INSERT INTO `shop_type`( `shop_type_details`, `status`) VALUES ('Gift shop',1);
INSERT INTO `shop_type`( `shop_type_details`, `status`) VALUES ('Dairy',1);

INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('shop_type','status',1,'Active');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('shop_type','status',0,'Inactive');

/*---------------- shop  --------------- Editable*/
CREATE TABLE shop( 
	id                    BIGINT(20) NOT NULL auto_increment PRIMARY KEY,
	shop_uid              VARCHAR(100) NULL, 
	shop_name             VARCHAR(100) NOT NULL, 
	shop_type             INT(4) NOT NULL, /*fk  shop_type */
	phone                 BIGINT(20) NOT NULL, 
	verify_phone          TINYINT(1) NOT NULL DEFAULT 0, 
	email                 VARCHAR(100), 
	verify_email          TINYINT(1) DEFAULT 0, 
	alternet_phone        BIGINT(20) NULL, 
	alternet_verify_phone TINYINT(1) DEFAULT 0, 
	alternet_email        VARCHAR(100) NULL, 
	alternet_verify_email TINYINT(1) DEFAULT 0, 
	pin                   INT(6) NOT NULL, 
	locality              VARCHAR(100), 
	address               VARCHAR(255), 
	dist                  VARCHAR(40), 
	state                 VARCHAR(100), 
	gst  				  VARCHAR(20) NULL, 
	govt_proof 	  		  VARCHAR(100), 
	govt_proof_no	      VARCHAR(100), 
	pan    	              VARCHAR(20) NULL, 
	status 		          TINYINT(1) NOT NULL ,  /*--Active-Inactive*/
	created_date timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
	activation_date 	  TIMESTAMP NULL
);

INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('shop','status',1,'Active');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('shop','status',0,'Inactive');

/*-----------   product main category      -------------- Editable*/
CREATE TABLE product_main_category( 
	id       INT(6) NOT NULL auto_increment PRIMARY KEY, 
	shop_uid VARCHAR(100) NULL,    /*fk  shop*/
	details  VARCHAR(100) NOT NULL, 
	status   TINYINT(1) NOT NULL /*--Active-Inactive */
);
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('product_main_category','status',1,'Active');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('product_main_category','status',0,'Inactive');


/*-----------   product sub category    ----------- Editable*/
CREATE TABLE product_sub_category( 
	id              INT(6) NOT NULL auto_increment PRIMARY KEY, 
	product_main_id INT(6) NOT NULL, /*fk product_main_category */
	details         VARCHAR(100) NOT NULL, 
	status          TINYINT(1) NOT NULL /*--Active-Inactive */
);
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('product_sub_category','status',1,'Active');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('product_sub_category','status',0,'Inactive');

/*------------  product   ----------------- Editable*/
CREATE TABLE product( 
	id                  BIGINT(20) NOT NULL auto_increment PRIMARY KEY,
	product_sub_id      INT(6) NULL , /*fk product_sub_category */
	product_details     VARCHAR(255) NULL, 
	product_name        VARCHAR(100) NULL, 
	payment_details     TINYINT(1) NULL DEFAULT 1,
	status              TINYINT(1) NULL DEFAULT 1, /*--Active-Inactive */
	original_price      INT(6) NULL, 
	basic_offer         INT(3) DEFAULT 0, 
	selling_price       INT(6) NULL, 	
	delivery_charges    INT(6) NULL,
	delivery_time		INT(2) DEFAULT 0, 
	quantity            INT(6) NULL, 
	total_sold          INT(6) NULL, 
	warranty            VARCHAR(100) NULL, 
	replacement         TINYINT(1) DEFAULT 0, /* --Yes-No */
	replacement_details VARCHAR(100) NULL, 
	return_type         TINYINT(1) DEFAULT 0, /*--Yes-No */
	return_details      VARCHAR(100) NULL ,
	publish_date 		timestamp NULL, 
	close_date 			timestamp NULL, 
	created_date 		timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('product','status',1,'Active');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('product','status',0,'Inactive');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('product','status',2,'Set publish time');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('product','replacement',1,'Yes');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('product','replacement',0,'No');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('product','return_type',1,'Yes');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('product','return_type',0,'No');



/*-------------------- product_details   -------------------- Editable*/
CREATE TABLE product_details( 
	id 			 BIGINT(20) NOT NULL auto_increment PRIMARY KEY,
	product_id   BIGINT(20) NOT NULL,/*fk product */
	details_type VARCHAR(100) NOT NULL, 
	details      VARCHAR(255) NOT NULL 
); 


/*------------- product_pics --------- Editable*/
CREATE TABLE product_pics(
	id 			BIGINT(20) NOT NULL auto_increment PRIMARY KEY,
	product_id  BIGINT(20) NOT NULL,/*fk product */
	img			VARCHAR(100) NOT NULL
);

/*--------- offer ------ Editable*/
CREATE TABLE offer(
	id            BIGINT(20) NOT NULL auto_increment PRIMARY KEY, 
	shop_uid      VARCHAR(100) NOT NULL,    /*fk  shop*/
	offer_details VARCHAR(255) NOT NULL, 
	offer_percentage INT(3) DEFAULT 0, 
	max_offer     INT(6) DEFAULT 0, 
	min_order      INT(6) DEFAULT 0, 
	start_date    datetime NOT NULL, 
	end_date      datetime NOT NULL, 
	offer_type    TINYINT(1) NOT NULL DEFAULT 0, /*--Global - Not global */
	status  TINYINT(1) NOT NULL DEFAULT 1 /*--Activated or not */
);
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('offer','status',1,'Active');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('offer','status',0,'Inactive');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('offer','offer_type',1,'Global');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('offer','offer_type',0,'Local');

/*----------product_offer------- Editable*/
CREATE TABLE product_offer(
	id         BIGINT(20) NOT NULL auto_increment PRIMARY KEY, 
	product_id BIGINT(20) NOT NULL,/*fk product */
	offer_id   BIGINT(20) NOT NULL/*fk offer */
);



/*----------  customer  ------------ Editable*/
CREATE TABLE customer ( 
	customer_id  BIGINT(20) NOT NULL auto_increment PRIMARY KEY, 
	f_name       VARCHAR(40) NOT NULL, 
	m_name       VARCHAR(40), 
	l_name       VARCHAR(40), 
	gender       TINYINT(1) NOT NULL, 
	phone        BIGINT(20) NOT NULL, 
	verify_phone TINYINT(1) NOT NULL DEFAULT 0, 
	email        VARCHAR(100), 
	verify_email TINYINT(1) DEFAULT 0, 
	user_type    TINYINT(1) DEFAULT 1, 
	password     VARCHAR(255) NOT NULL 
); 

/*------------  customer_address  ------------ Editable*/
CREATE TABLE customer_address ( 
	id             BIGINT(20) NOT NULL auto_increment PRIMARY KEY, 
	customer_id    BIGINT(20) NOT NULL,/*fk customer */
	name           VARCHAR(100) NOT NULL, 
	phone          BIGINT(20) NOT NULL, 
	alt_phone      BIGINT(20), 
	pin            INT(6), 
	locality       VARCHAR(100), 
	address        VARCHAR(255), 
	dist           VARCHAR(40), 
	state          VARCHAR(100), 
	address_type   TINYINT(1) DEFAULT 1,/*--Home-Office */
	address_status TINYINT(1) DEFAULT 1 /*--Active-Inactive */
); 
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('customer_address','address_type',1,'Home');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('customer_address','address_type',0,'Office');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('customer_address','address_status',1,'Active');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('customer_address','address_status',0,'Inactive');

/*----------------   order_details    -------------*/
CREATE TABLE order_details( 
	order_id            BIGINT(20) NOT NULL auto_increment PRIMARY KEY, 
	customer_id         BIGINT(20) NOT NULL,/*fk customer */
	shop_id             BIGINT(20) NOT NULL,/*fk shop */
	product_id          BIGINT(20) NOT NULL,/*fk product */
	customer_address_id BIGINT(20) NOT NULL, /*fk customer_address */
	original_price      INT(6) NOT NULL, 
	basic_offer         INT(3) NOT NULL, 
	selling_price       INT(6) NOT NULL, 
	delivery_charges    INT(6) NOT NULL, 
	status              TINYINT(1) DEFAULT 1, /*-- 0 -> CANCELLED , 1->ORDERED, 2->PACKAGE, 3-> RECEIVED, 4-> DELIVERED */
	payment_status      TINYINT(1) DEFAULT 1, /* -- 1->COD, 2->ONLINE */
	offer_file			VARCHAR(100) NULL,
	address_file		VARCHAR(100) NULL
);
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('order_details','status',0,'Cancelled');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('order_details','status',1,'Ordered');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('order_details','status',2,'Packed');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('order_details','status',3,'Shipped');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('order_details','status',4,'Delivered');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('order_details','payment_status',1,'Cash on Delivery');
INSERT INTO `status_info`(`table_name`, `column_name`, `symbol`, `details`) VALUES ('order_details','payment_status',2,'Online Payment');

/*-------------- Tracking_status   ----------- Not Editable*/
CREATE TABLE tracking_status( 
	id       BIGINT(20) NOT NULL auto_increment PRIMARY KEY, 
	order_id BIGINT(20) NOT NULL,	/*fk order */
	details  VARCHAR(255) 
); 

/*--------- rating  ----------- Not Editable*/
CREATE TABLE rating(
	id          BIGINT(20) NOT NULL auto_increment PRIMARY KEY, 
	product_id  BIGINT(20) NOT NULL,	/*fk product  */
	customer_id BIGINT(20) NOT NULL,	/*fk customer */
	rating      TINYINT(1) NOT NULL DEFAULT 3, 
	feedback    VARCHAR(255) NULL 
); 

/*--------- status_info  ----------- Symbol Not Editable*/
CREATE TABLE status_info( 
	id       	INT(3) NOT NULL auto_increment PRIMARY KEY, 
	table_name  VARCHAR(255) NULL, 
	column_name VARCHAR(255) NULL, 
	symbol 		TINYINT(1) NOT NULL,
	details  	VARCHAR(100) 
); 
/*--------- admin_otp  ----------- Symbol Not Editable*/
CREATE TABLE `admin_otp` (
  `id` bigint(10) NOT NULL auto_increment PRIMARY KEY, 
  `phone` BIGINT(20) NOT NULL,
  `phone_otp` int(6) NOT NULL,
  `p_send_count` int(2) NOT NULL DEFAULT 0,
  `p_created_time` timestamp NULL DEFAULT current_timestamp(),
  `p_resend_count` int(2) NOT NULL DEFAULT 0,
  `p_resend_time` timestamp NULL DEFAULT current_timestamp(),
  `email_otp` int(6) NOT NULL,
  `e_send_count` int(2) NOT NULL DEFAULT 0,
  `e_created_time` timestamp NULL DEFAULT current_timestamp(),
  `e_resend_count` int(2) NOT NULL DEFAULT 0,
  `e_resend_time` timestamp NULL DEFAULT current_timestamp()
);
/*-----------   govt_proof      -------------- Editable*/
CREATE TABLE govt_proof( 
	id                INT(4) NOT NULL auto_increment PRIMARY KEY, 
	govt_proof_details VARCHAR(100), 
	status            TINYINT(1) NOT NULL /*Active-Inactive */ 
); 
INSERT INTO `govt_proof`( `govt_proof_details`, `status`) VALUES ('Aadhaar',1);
INSERT INTO `govt_proof`( `govt_proof_details`, `status`) VALUES ('PAN card',1);
INSERT INTO `govt_proof`( `govt_proof_details`, `status`) VALUES ('Voter card',1);