<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(backend_full_access_check() == true){
    //if($_SESSION['shop_uid'] != null || $_SESSION['shop_uid'] != ""){
        if(isset($_POST['xcsrf']) ){
            if($_POST['xcsrf'] == $csrf_token) {
                $main_category =htmlspecialchars($_POST["main_category"]);
                $main_category_hidden = htmlspecialchars($_POST["main_category_hidden"]);
                if(empty($main_category)){
                    $code = 400;
                    $msg .= "<li>Enter main category</li>";
                }          
                if(empty($msg)){
                    include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                    $one = 1;
                    $shop_uid = $_SESSION['shop_uid'];
                    if($main_category_hidden == 0){
                        $stmt = $conn->prepare("INSERT INTO product_main_category (shop_uid,details,status) VALUES (?,?,?)"); 
                        $stmt->bind_param('sss', $shop_uid, $main_category, $one);
                        $stmt->execute();
                        $stmt->close();
                        $code = 200;
                        $msg .= "Success";
                    }
                    if($main_category_hidden > 0){
                        $stmt = $conn->prepare("UPDATE product_main_category SET details = ? WHERE id = ?"); 
                        $stmt->bind_param('ss', $main_category, $main_category_hidden);
                        $stmt->execute();
                        $stmt->close();
                        $code = 200;
                        $msg .= "Success";
                    }                    
                    $conn->close();
                }else{
                    $code = 400;
                }
            }
        }
    //}
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>