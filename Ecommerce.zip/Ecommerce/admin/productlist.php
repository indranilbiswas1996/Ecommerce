<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
frontend_full_access_check();

//To keep the same option after reload
if(isset($_POST['live_status'])){
    $live_status = $_POST['live_status'];
}else{
    $live_status = 1;
}
//$live_status = 1;
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
    <?php include 'header.php';?>
    <div class="container">
        <?php include 'mobile_menu.php'; ?>
        <div class="dashboard-details-container">
        <div class="dashboard-details-inner-container-search-div">
            <form name="form-login" class="form-login" id="form-login" action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
                <div class="dashboard-details-inner-container-search-item">
                    <select id="live_status" name="live_status" class="login-selectbox">
                        <option value="1" <?php if($live_status == '1'){echo("selected");}?>>In stock</option>
                        <option value="0" <?php if($live_status == '0'){echo("selected");}?>>Deleted</option>
                        <option value="2" <?php if($live_status == '2'){echo("selected");}?>>Out of stock</option>
                    </select>
                </div>
                <!--<div class="dashboard-details-inner-container-search-item">
                    <select id="time_period" name="time_period" class="login-selectbox" onchange="time_period_change()">
                        <option value="1">Active</option>
                        <option value="0">Inactive</option>
                    </select>
                </div>-->
                <div class="dashboard-details-inner-container-search-item">
                    <input type="hidden" name="xcsrf" value="<?php echo $csrf_token;?>" id="xcsrf" />
                    <button type="submit" class="login-button" >Search</button>
                </div>
            </form>
        </div>
        <div class="alert alert-danger" id="productlist_err"></div>
        <?php
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                if(isset($_POST['xcsrf']) && isset($_POST['live_status']) /*&& isset($_POST['time_period'])*/){
                    $live_status = $_POST['live_status'];
                    //$time_period = $_POST['time_period'];
                    $stmt = $conn->prepare("SELECT `id`, `product_sub_id`,  `product_name`, `payment_details`, `status`, `live_status`, `original_price`, `basic_offer`, `selling_price`,  `quantity`, `total_sold`, `publish_date`, `close_date`, `created_date` FROM `product` WHERE shop_uid = ? AND live_status = ? ");
                    $stmt->bind_param('ss', $_SESSION['shop_uid'], $live_status);  
                    $stmt->execute();
                    $stmt->store_result();    
                }else{
                    $stmt = $conn->prepare("SELECT `id`, `product_sub_id`,  `product_name`, `payment_details`, `status`, `live_status`, `original_price`, `basic_offer`, `selling_price`,  `quantity`, `total_sold`, `publish_date`, `close_date`, `created_date` FROM `product` WHERE shop_uid = ? AND live_status = ? ");
                    $stmt->bind_param('ss', $_SESSION['shop_uid'], $live_status);  
                    $stmt->execute();
                    $stmt->store_result();
                }
                if($stmt->num_rows() != 0){                    
                    $stmt->bind_result($id, $product_sub_id, $product_name, $payment_details, $status, $live_status, $original_price, $basic_offer, $selling_price, $quantity, $total_sold, $publish_date, $close_date, $created_date);
                    while($stmt->fetch()){
                        echo '<div class="dashboard-details-inner-container">
                            <div class="productlist-item-container">
                                <div class="productlist-item-img-container">
                                    <div class="productlist-img-div">';
                        $stmt1 = $conn->prepare("SELECT `img` FROM `product_pics` WHERE product_id = ? LIMIT 1");
                        $stmt1->bind_param('s', $id);
                        $stmt1->execute();
                        $stmt1->store_result();
                        if($stmt1->num_rows() != 0){                    
                            $stmt1->bind_result($img);
                            while($stmt1->fetch()){
                                echo '<img src="img/'.$img.'">';
                            }
                        }
                        $stmt1->close();
                        echo '</div>
                                </div>
                                <div class="productlist-item-details-container">
                                    <span class="productlist-item-details-product-name">'.$product_name.'</span>
                                    <div class="productlist-item-details-inner-container">';
                                        $stmt2 = $conn->prepare("SELECT `product_main_id`, `details` FROM `product_sub_category` WHERE id = ?");
                                        $stmt2->bind_param('s', $product_sub_id);
                                        $stmt2->execute();
                                        $stmt2->store_result();
                                        if($stmt2->num_rows() != 0){                    
                                            $stmt2->bind_result($product_main_id, $product_sub_details);
                                            while($stmt2->fetch()){
                                                $stmt3 = $conn->prepare("SELECT `details` FROM `product_main_category` WHERE id = ?");
                                                $stmt3->bind_param('s', $product_main_id);
                                                $stmt3->execute();
                                                $stmt3->store_result();
                                                if($stmt3->num_rows() != 0){                    
                                                    $stmt3->bind_result($product_main_details);
                                                    while($stmt3->fetch()){
                                                        echo '<span class="productlist-item-details-product-category">'.$product_main_details.' <i class="fa fa-angle-double-right" aria-hidden="true"></i> '.$product_sub_details.'</span>';
                                                    }
                                                }
                                                $stmt3->close();                                                
                                            }
                                        }
                                        $stmt2->close();
                                        echo '                                        
                                        <span class="productlist-item-details-product-price-selling">₹'.$selling_price.'</span>
                                        <span class="productlist-item-details-product-price-actual">₹'.$original_price.'</span>
                                        <span class="productlist-item-details-product-price-offer">'.$basic_offer.'% off</span>';
                                        $table_name = "product";
                                        $column_name = "payment_details";
                                        $stmt4 = $conn->prepare("SELECT `details` FROM `status_info` WHERE `symbol` = ? AND `table_name` = ? AND `column_name` = ?");                                        
                                        $stmt4->bind_param('sss', $payment_details, $table_name, $column_name);
                                        $stmt4->execute();
                                        $stmt4->store_result();
                                        if($stmt4->num_rows() != 0){                    
                                            $stmt4->bind_result($payment_details_info);
                                            while($stmt4->fetch()){
                                                echo '<span class="productlist-item-details-product-payment">'.$payment_details_info.'</span>';
                                            }
                                        }
                                        $stmt4->close();
                                        if($status == 2){
                                            echo '<span class="productlist-item-details-product-publish-date">Publish date : '.$publish_date.' </span>';
                                        }
                                        if($status == 3){
                                            echo '<span class="productlist-item-details-product-publish-date">Publish date : '.$close_date.' </span>';
                                        }
                                        if($status == 4){
                                            echo '<span class="productlist-item-details-product-publish-date">Publish date : '.$publish_date.' </span>
                                                  <span class="productlist-item-details-product-end-date">End date : '.$close_date.'</span>';
                                        }
                                        echo ' 
                                    </div>  
                                    <div class="productlist-item-price-container">                        
                                        <span class="productlist-item-details-product-quantity">Quantity : '.$quantity.'</span>
                                        <span class="productlist-item-details-product-sold">Sold : '.$total_sold.'</span>';
                                        $table_name = "product";
                                        $column_name = "status";
                                        $stmt5 = $conn->prepare("SELECT `details` FROM `status_info` WHERE `symbol` = ? AND `table_name` = ? AND `column_name` = ?");                                        
                                        $stmt5->bind_param('sss', $status, $table_name, $column_name);
                                        $stmt5->execute();
                                        $stmt5->store_result();
                                        if($stmt5->num_rows() != 0){                    
                                            $stmt5->bind_result($status_info);
                                            while($stmt5->fetch()){
                                                if($status == 0){
                                                    echo '<span class="productlist-item-details-product-status red">Time period : '.$status_info.'</span>';
                                                }
                                                if($status == 1){
                                                    echo '<span class="productlist-item-details-product-status green">Time period : '.$status_info.'</span>';
                                                }
                                                if($status == 2){
                                                    date_default_timezone_set('Asia/Kolkata');
                                                    $current_time = date('Y-m-d H:i:s');
                                                    if($current_time > $publish_date){
                                                        echo '<span class="productlist-item-details-product-status green">Time period : Active</span>';
                                                    }else{
                                                        echo '<span class="productlist-item-details-product-status red">Time period : Inactive</span>';
                                                    }                                                    
                                                }
                                                if($status == 3){
                                                    date_default_timezone_set('Asia/Kolkata');
                                                    $current_time = date('Y-m-d H:i:s');
                                                    if($current_time < $close_date){
                                                        echo '<span class="productlist-item-details-product-status green">Time period : Active</span>';
                                                    }else{
                                                        echo '<span class="productlist-item-details-product-status red">Time period : Inactive</span>';
                                                    }                                                    
                                                }
                                                if($status == 4){
                                                    date_default_timezone_set('Asia/Kolkata');
                                                    $current_time = date('Y-m-d H:i:s');
                                                    if($current_time > $publish_date && $current_time < $close_date){
                                                        echo '<span class="productlist-item-details-product-status green">Time period : Active</span>';
                                                    }else{
                                                        echo '<span class="productlist-item-details-product-status red">Time period : Inactive</span>';
                                                    }                                                    
                                                }
                                            }
                                        }
                                        $stmt5->close();
                                        $table_name = "product";
                                        $column_name = "live_status";
                                        $stmt6 = $conn->prepare("SELECT `details` FROM `status_info` WHERE `symbol` = ? AND `table_name` = ? AND `column_name` = ?");                                        
                                        $stmt6->bind_param('sss', $live_status, $table_name, $column_name);
                                        $stmt6->execute();
                                        $stmt6->store_result();
                                        if($stmt6->num_rows() != 0){                    
                                            $stmt6->bind_result($live_status_info);
                                            while($stmt6->fetch()){
                                                if($live_status == 0){
                                                    echo '<span class="productlist-item-details-product-status red">Live status : '.$live_status_info.'</span>';
                                                }
                                                if($live_status == 1){
                                                    echo '<span class="productlist-item-details-product-status green">Live status : '.$live_status_info.'</span>';
                                                }
												if($live_status == 2){
                                                    echo '<span class="productlist-item-details-product-status yellow">Live status : '.$live_status_info.'</span>';
                                                }
                                            }
                                        }
                                        $stmt6->close();
                                        echo '                                        
                                    </div>
                                    <div class="productlist-item-action-container">';
                                    if($live_status == 0){
                                        echo '
                                        <div class="productlist-save-action-div">
                                            <span class="productlist-item-details-button" onclick="edit_product(\''.$id.'\')"><i class="fa fa-edit green"></i></span>
                                        </div>
                                        <div class="productlist-save-action-div">
                                                <span class="productlist-item-details-button" onclick="restore(\''.$id.'\')"><i class="fa fa-undo yellow"></i></span>
                                            </div>';
                                    }else{
                                    echo '
                                        <div class="productlist-save-action-div">
                                            <span class="productlist-item-details-button" onclick="edit_product(\''.$id.'\')"><i class="fa fa-edit green"></i></span>
                                        </div>
                                        <div class="productlist-save-action-div">
                                            <span class="productlist-item-details-button" onclick="delete_product(\''.$id.'\')"><i class="fa fa-trash red"></i></span>
                                        </div>';
                                    }
                                    echo '
                                    </div>
                                </div>
                            </div>
                        </div>';
                    }
                }
                $stmt->close();
                $conn->close();
            ?> 
    </div>
</body>
<script type="text/javascript">  

function edit_product(id){
    window.location = "product.php?id="+id;
}
function delete_product(id){
    if(confirm("Are you sure to delete the product ? Press ok to confirm.")){    
        var ajaxRequest, fd;
        try {
            ajaxRequest = new XMLHttpRequest();
        }catch (e) {
            try {
                ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
            }catch (e) {
                try{
                    ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                }catch (e){
                    alert("Your browser broke!");
                    return false;
                }
            }
        }
        ajaxRequest.onreadystatechange = function(){
            if(ajaxRequest.readyState == 4){
                var data = JSON.parse(ajaxRequest.responseText);
                if(data.code == "200"){
                    window.location.reload();
                }else{
                    $("#productlist_err").html("<ul>"+data.msg+"</ul>");
                    $("#productlist_err").css("display","block");
                }
            }
        }
        fd = new FormData();
        fd.append("product_id", id);
        fd.append("xcsrf", "<?php echo $csrf_token;?>");          
        ajaxRequest.open("POST", "delete_product_background.php", true);
        ajaxRequest.send(fd);
    }
}  
function restore(id){
    if(confirm("Are you sure to restore the product ? Press ok to confirm.")){  
        var ajaxRequest, fd;
        try {
            ajaxRequest = new XMLHttpRequest();
        }catch (e) {
            try {
                ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
            }catch (e) {
                try{
                    ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                }catch (e){
                    alert("Your browser broke!");
                    return false;
                }
            }
        }
        ajaxRequest.onreadystatechange = function(){
            if(ajaxRequest.readyState == 4){
                var data = JSON.parse(ajaxRequest.responseText);
                if(data.code == "200"){
                    window.location.reload();
                }else{
                    $("#main_err").html("<ul>"+data.msg+"</ul>");
                    $("#main_err").css("display","block");
                }
            }
        }
        fd = new FormData();
        fd.append("product_id", id);
        fd.append("xcsrf", "<?php echo $csrf_token;?>");          
        ajaxRequest.open("POST", "product_restore_background.php", true);
        ajaxRequest.send(fd);
    }
}
</script>
</html>