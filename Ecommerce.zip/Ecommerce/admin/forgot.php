<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
if(login_check() == true){
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
<?php include 'header.php';?>
<div class="container">
    <div class="login-container">
            <div class="login-div">
                <div class="login-part">
                    <!-- Login -->
                    <div class="login-part-inner" id="login_div" >
                        <div class="headline"><span>Forgot password</span></div>
                        <div class="alert alert-danger" id="login_err">
                        </div>
                        <div class="login-item">
                            <label class="login-label">Mobile number<span class="red">*</span></label>
                            <input type="text" name="phone" id="phone" class="login-textbox" placeholder="Enter mobile number">
                        </div>
                        <div class="login-item">
                            <button type="submit" class="login-button" name="forgot" id="forgot" onclick="forgot()" >Submit</button>
                        </div>
                        <div class="login-item">
                            <a href="registration.php">Create an account</a>
                            <a href="login.php" class="right">Login</a>
                        </div>
                    </div>
                </div>
            </div>
    </div>
</div>
<script type="text/javascript">
    /* Start : Code to trigger submit button when press enter */
    var login_div = document.getElementById("login_div");
    login_div.addEventListener("keyup", function(event) {
        if (event.keyCode === 13) {
            event.preventDefault();
            document.getElementById("forgot").click();
        }
    });
    try{
        $('input').removeClass('outline-red');
        $('select').removeClass('outline-red');
    }catch(e){}
    if(phone == ""){
        err +=  '<li>Enter mobile number</li>';
        document.getElementById("phone").classList.add("outline-red");
    }else{
        var mob = /^[6-9]{1}[0-9]{9}$/;
        if (mob.test(phone) == false) {
            err +=  '<li>Enter 10 digit mobile number</li>';
            document.getElementById("phone").classList.add("outline-red");
        }
    }
    /* End : Code to trigger submit button when press enter */
    function forgot(){
        var phone = document.getElementById('phone').value;
        var err = "";
        if(phone == ""){
            err +=  '<li>Enter mobile number</li>';
            document.getElementById("phone").classList.add("outline-red");
        }else{
            var mob = /^[6-9]{1}[0-9]{9}$/;
            if (mob.test(phone) == false) {
                err +=  '<li>Enter 10 digit mobile number</li>';
                document.getElementById("phone").classList.add("outline-red");
            }
        }
        if(err != ""){          
            $("#login_err").html("<ul>"+err+"</ul>");
            $("#login_err").css("display","block");
        }else{
            var ajaxRequest, fd;
            try {
                ajaxRequest = new XMLHttpRequest();
            }catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                }catch (e) {
                    try{
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    }catch (e){
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }
            ajaxRequest.onreadystatechange = function(){
                if(ajaxRequest.readyState == 4){
                    var data = JSON.parse(ajaxRequest.responseText);
                    if(data.code == "201"){
                        window.location = "otp.php";
                    }else{
                        $("#login_err").html("<ul>"+data.msg+"</ul>");
                        $("#login_err").css("display","block");
                    }
                }
            }
            fd = new FormData();
            fd.append("phone", phone); 
            fd.append("xcsrf", "<?php echo $csrf_token;?>");          
            ajaxRequest.open("POST", "forgot_background.php", true);
            ajaxRequest.send(fd);
        }
        
    }
</script>
</body>
</html>