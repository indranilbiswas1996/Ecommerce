<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$res = '{"error": 3}';
if(isset($_POST['xcsrf']) ){      

    if($_POST['xcsrf'] == $csrf_token) {
        include 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
        $product_main_id = htmlspecialchars($_POST['main_category_select']);
        $display_string = "";   
        $one = 1;
        $stmt = $conn->prepare("SELECT id, details FROM `product_sub_category` WHERE product_main_id = ? AND status = ?");        
        $stmt->bind_param('ss', $product_main_id, $one);
        $stmt->execute();
        $stmt->store_result();
        $display_string = '[';
        $display_string .= '{"id": "-1", "value":"Select sub category"},';    
        if($stmt->num_rows() != 0){                    
            $stmt->bind_result($id, $details);               
            while($stmt->fetch()){    
                $display_string .= '{"id": "'.$id.'", "value":"'.$details.'"},';        
            }            
        }
        $display_string = substr($display_string, 0, strlen($display_string) -1);
        $display_string .=']';
        
        $stmt->close();
        $conn->close();
        $res = '{"error": 0, "msg": "Successfully added!"}';
    }
}
echo $display_string;
?>