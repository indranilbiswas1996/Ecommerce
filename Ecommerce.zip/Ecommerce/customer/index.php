<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
    <?php include 'header.php';?>
    INDEX
    <a href="search.php">Search</a>
</body>
</html>