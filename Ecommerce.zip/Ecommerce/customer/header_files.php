<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, target-densityDpi=device-dpi" />
<link type="text/css" rel="stylesheet" href="css/header.css"/>
<link type="text/css" rel="stylesheet" href="css/customer_main.css"/>
<link type="text/css" rel="stylesheet" href="css/basic.css"/>
<link type="text/css" rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<title><?php echo $customerTitle; ?></title>