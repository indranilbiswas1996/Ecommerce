<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
frontend_full_access_check();
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
    <?php include 'header.php';?>
    <div class="container">
        <?php include 'mobile_menu.php'; ?>
        <div class="dashboard-details-container">
            <div class="dashboard-details-inner-container center">
                <div class="dashboard-details-inner-div-first">
                    <div class="alert alert-danger" id="main_category_err">
                    </div>
                    <div class="main-category-textbox-container">
                        <label class="login-label">Main category<span class="red">*</span></label>
                        <input type="text" name="main_category" id="main_category" class="login-textbox" placeholder="Enter main category">
                        <input type="hidden" id="main_category_hidden" value="0">
                    </div>                    
                    <div class="main-category-button-container">
                        <button type="submit" class="login-button" name="add_main_category" id="add_main_category" onclick="add_main_category()" >Add</button>
                    </div>                    
                    <div class="main-category-button-container">
                        <button type="submit" class="login-button background-red" name="reset_main_category" id="reset_main_category" onclick="reset_main_category()" >Reset</button>
                    </div>
                </div>
                <div class="dashboard-details-inner-div-second">
                    <div class="alert alert-danger" id="sub_category_err">
                    </div>
                    <div class="sub-category-textbox-container">
                        <label class="login-label">Sub category<span class="red">*</span></label>
                        <input type="text" name="sub_category" id="sub_category" class="login-textbox" placeholder="Enter sub category">
                        <input type="hidden" id="sub_category_hidden" value="0">
                    </div>
                    <div class="sub-category-textbox-container">
                        <label class="login-label">Main category<span class="red">*</span></label>
                        <select id="main_category_select" name="main_category_select" class="login-selectbox">
                            <option value="-1">Select main category</option>
                            <?php
                            include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                                $one = 1;
                                $stmt = $conn->prepare("SELECT id, details FROM product_main_category WHERE shop_uid = ? AND status = ? ORDER BY details ASC");
                                $stmt->bind_param('ss', $_SESSION['shop_uid'], $one);
                                $stmt->execute();
                                $stmt->store_result();
                                if($stmt->num_rows() != 0){                    
                                    $stmt->bind_result($id, $details);
                                    while($stmt->fetch()){
                                        echo '<option value="'.$id.'">'.$details.'</option>';
                                    }
                                }
                                $stmt->close();
                            ?>                            
                        </select>
                    </div>
                    <div class="main-category-button-container">
                        <button type="submit" class="login-button" name="add_sub_category" id="add_sub_category" onclick="add_sub_category()" >Add</button>
                    </div>
                    <div class="main-category-button-container">
                        <button type="submit" class="login-button background-red" name="reset_sub_category" id="reset_sub_category" onclick="reset_sub_category()" >Reset</button>
                    </div>
                </div>
            </div>
            <div class="dashboard-details-inner-container center">
            <?php
                $one = 1;
                $stmt = $conn->prepare("SELECT id, details FROM product_main_category WHERE shop_uid = ? AND status = ? ORDER BY details ASC");
                $stmt->bind_param('ss', $_SESSION['shop_uid'], $one);
                $stmt->execute();
                $stmt->store_result();
                if($stmt->num_rows() != 0){                    
                    $stmt->bind_result($id, $details);
                    while($stmt->fetch()){
                        echo '<div class="category-item-container">
                            <div class="main-category-item background-blue white">'
                                .$details.
                                '<div class="category-item-action">
                                    <span class="fa fa-edit white" onclick="edit_main_category('.$id.',\''.$details.'\')"></span>
                                    <span class="fa fa-trash red" onclick="delete_main_category('.$id.',\''.$details.'\')"></span>
                                </div>
                            </div>
                            <div class="sub-category-container">';
                                    $stmt2 = $conn->prepare("SELECT id, product_main_id, details FROM product_sub_category WHERE product_main_id = ? AND status = ? ORDER BY details ASC");
                                    $stmt2->bind_param('ss', $id, $one);
                                    $stmt2->execute();
                                    $stmt2->store_result();
                                    if($stmt2->num_rows() != 0){                    
                                        $stmt2->bind_result($sub_id, $product_main_id, $sub_details);
                                        while($stmt2->fetch()){
                                            echo '
                                            <div class="sub-category-item">'.$sub_details.'
                                                <div class="category-item-action">
                                                    <span class="fa fa-edit green" onclick="edit_sub_category('.$sub_id.','.$product_main_id.',\''.$sub_details.'\')"></span>
                                                    <span class="fa fa-trash red" onclick="delete_sub_category('.$sub_id.',\''.$sub_details.'\')"></span>
                                                </div>
                                            </div>';
                                        }
                                    }
                       echo '</div>
                        </div>';
                    }
                }
                $stmt->close();
                $conn->close();
            ?>    
            </div>
        </div>
    </div>
<script type="text/javascript">   
/* Main category */
    function reset_main_category(){
        $("#main_category_err").css("display","none");
        document.getElementById('main_category').value = "";
        document.getElementById('main_category_hidden').value = "0";
        try{
            $('input').removeClass('outline-red');
            $('select').removeClass('outline-red');
        }catch(e){}
    }
    function edit_main_category(id, details){
        document.getElementById('main_category').value = details;
        document.getElementById('main_category_hidden').value = id;
    }
    function add_main_category(){
        var err = "";
        var main_category = document.getElementById('main_category').value;
        var main_category_hidden = document.getElementById('main_category_hidden').value;
        if(main_category == ""){
            err +=  '<li>Enter main category</li>';
            document.getElementById("main_category").classList.add("outline-red");
        }
        if(err != ""){
            console.log(err);           
            $("#main_category_err").html("<ul>"+err+"</ul>");
            $("#main_category_err").css("display","block");
        }else{
            var ajaxRequest, fd;
            try {
                ajaxRequest = new XMLHttpRequest();
            }catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                }catch (e) {
                    try{
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    }catch (e){
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }
            ajaxRequest.onreadystatechange = function(){
                if(ajaxRequest.readyState == 4){
                    var data = JSON.parse(ajaxRequest.responseText);
                    if(data.code == "200"){
                        window.location = "category.php";
                    }else{
                        $("#main_category_err").html("<ul>"+data.msg+"</ul>");
                        $("#main_category_err").css("display","block");
                    }
                }
            }
            fd = new FormData();
            fd.append("main_category", main_category);
            fd.append("main_category_hidden", main_category_hidden);
            fd.append("xcsrf", "<?php echo $csrf_token;?>");          
            ajaxRequest.open("POST", "add_main_category_background.php", true);
            ajaxRequest.send(fd);
        }
    }
    function delete_main_category(id, details){    
        if(confirm("Are you sure to delete the "+details+" ? Press ok to confirm.")){    
            var ajaxRequest, fd;
            try {
                ajaxRequest = new XMLHttpRequest();
            }catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                }catch (e) {
                    try{
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    }catch (e){
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }
            ajaxRequest.onreadystatechange = function(){
                if(ajaxRequest.readyState == 4){
                    var data = JSON.parse(ajaxRequest.responseText);
                    if(data.code == "200"){
                        window.location = "category.php";
                    }else{
                        $("#login_err").html("<ul>"+data.msg+"</ul>");
                        $("#login_err").css("display","block");
                    }
                }
            }
            fd = new FormData();
            fd.append("main_category_id", id);
            fd.append("xcsrf", "<?php echo $csrf_token;?>");          
            ajaxRequest.open("POST", "delete_main_category_background.php", true);
            ajaxRequest.send(fd);
        }
    }
    /* Sub category */
    function reset_sub_category(){
        $("#sub_category_err").css("display","none");
        document.getElementById('sub_category').value = "";
        document.getElementById('main_category_select').value = "-1";
        document.getElementById('sub_category_hidden').value = "0";
        try{
            $('input').removeClass('outline-red');
            $('select').removeClass('outline-red');
        }catch(e){}
    }
    function edit_sub_category(id, product_main_id, details){
        document.getElementById('sub_category').value = details;
        document.getElementById('main_category_select').value = product_main_id;
        document.getElementById('sub_category_hidden').value = id;
    }
    function add_sub_category(){
        var err = "";
        var sub_category = document.getElementById('sub_category').value;
        var sub_category_hidden = document.getElementById('sub_category_hidden').value;
        var main_category_select = document.getElementById('main_category_select').value;
        if(sub_category == ""){
            err +=  '<li>Enter sub category</li>';
            document.getElementById("sub_category").classList.add("outline-red");
        }
        if(main_category_select == "" || main_category_select <= 0){
            err +=  '<li>Select main category</li>';
            document.getElementById("sub_category").classList.add("outline-red");
        }
        if(err != ""){
            console.log(err);           
            $("#sub_category_err").html("<ul>"+err+"</ul>");
            $("#sub_category_err").css("display","block");
        }else{
            var ajaxRequest, fd;
            try {
                ajaxRequest = new XMLHttpRequest();
            }catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                }catch (e) {
                    try{
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    }catch (e){
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }
            ajaxRequest.onreadystatechange = function(){
                if(ajaxRequest.readyState == 4){
                    var data = JSON.parse(ajaxRequest.responseText);
                    if(data.code == "200"){
                        window.location = "category.php";
                    }else{
                        $("#sub_category_err").html("<ul>"+data.msg+"</ul>");
                        $("#sub_category_err").css("display","block");
                    }
                }
            }
            fd = new FormData();
            fd.append("sub_category", sub_category);
            fd.append("main_category_select", main_category_select);
            fd.append("sub_category_hidden", sub_category_hidden);
            fd.append("xcsrf", "<?php echo $csrf_token;?>");          
            ajaxRequest.open("POST", "add_sub_category_background.php", true);
            ajaxRequest.send(fd);
        }
    }
    function delete_sub_category(id, details){    
        if(confirm("Are you sure to delete the "+details+" ? Press ok to confirm.")){    
            var ajaxRequest, fd;
            try {
                ajaxRequest = new XMLHttpRequest();
            }catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                }catch (e) {
                    try{
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    }catch (e){
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }
            ajaxRequest.onreadystatechange = function(){
                if(ajaxRequest.readyState == 4){
                    var data = JSON.parse(ajaxRequest.responseText);
                    if(data.code == "200"){
                        window.location = "category.php";
                    }else{
                        $("#login_err").html("<ul>"+data.msg+"</ul>");
                        $("#login_err").css("display","block");
                    }
                }
            }
            fd = new FormData();
            fd.append("sub_category_id", id);
            fd.append("xcsrf", "<?php echo $csrf_token;?>");          
            ajaxRequest.open("POST", "delete_sub_category_background.php", true);
            ajaxRequest.send(fd);
        }
    }
</script>
</body>
</html>