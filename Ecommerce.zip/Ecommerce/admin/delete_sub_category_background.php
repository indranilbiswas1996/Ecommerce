<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(backend_full_access_check() == true){
    //if($_SESSION['shop_uid'] != null || $_SESSION['shop_uid'] != ""){
        if(isset($_POST['xcsrf']) ){
            if($_POST['xcsrf'] == $csrf_token) {
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                $sub_category_id = htmlspecialchars($_POST["sub_category_id"]);
                if($sub_category_id > 0){
                    //----- Update product
                    $null = "";
                    $stmt = $conn->prepare("UPDATE product SET product_sub_id = ? WHERE product_sub_id = ?"); 
                    $stmt->bind_param('ss', $null, $sub_category_id);
                    $stmt->execute();
                    $stmt->close();
                    //----- Delete from product_sub_category
                    $stmt2 = $conn->prepare("DELETE FROM product_sub_category WHERE id = ?"); 
                    $stmt2->bind_param('s', $sub_category_id);
                    $stmt2->execute();
                    $stmt2->close();
                    $code = 200;
                    $msg .= "Success";
                }
                $conn->close();
            }
        }
    //}
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>