<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(backend_full_access_check() == true){
    //if($_SESSION['shop_uid'] != null || $_SESSION['shop_uid'] != ""){
        if(isset($_POST['xcsrf']) ){
            if($_POST['xcsrf'] == $csrf_token) {
                $shop_uid = $_SESSION['shop_uid'];
                $load_img_final_list_length = htmlspecialchars($_POST["load_img_final_list_length"]);
                $product_id_hidden = htmlspecialchars($_POST["product_id_hidden"]);
                $product_name = htmlspecialchars($_POST["product_name"]);
                $product_main_id = htmlspecialchars($_POST["main_category_select"]);
                $product_sub_id = htmlspecialchars($_POST["sub_category_select"]);
                $product_details = htmlspecialchars($_POST["product_details"]);
                $original_price = htmlspecialchars($_POST["original_price"]);
                $basic_offer = htmlspecialchars($_POST["basic_offer"]);
                $selling_price = htmlspecialchars($_POST["selling_price"]);
                $payment_details = htmlspecialchars($_POST["payment_details"]);
                $quantity = htmlspecialchars($_POST["quantity"]);
                $publish_status = htmlspecialchars($_POST["publish_status"]);
                $publish_date = htmlspecialchars($_POST["publish_date"]);
                $close_date = htmlspecialchars($_POST["close_date"]);
                $delivery_charges = htmlspecialchars($_POST["delivery_charges"]);
                $delivery_time = htmlspecialchars($_POST["delivery_time"]);
                $return_type = htmlspecialchars($_POST["return_type"]);
                $return_details = htmlspecialchars($_POST["return_details"]);
                $warranty = htmlspecialchars($_POST["warranty"]);
                $product_detailsjsonObj = json_decode($_POST["product_detailsjsonObj"]);
                $offer_ids = explode(",",htmlspecialchars($_POST["offer_ids"]));
                $img_count = 0;
                $live_status = 1;
                //For new product start
                if($product_id_hidden == 0){
                    /* Image validation start*/
                    if($load_img_final_list_length > 0){
                        for($i = 0 ; $i < $load_img_final_list_length ; $i++){
                            $img_flag = 0;
                            $target_file = basename($_FILES["img".$i]["name"]);
                            $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
                            if ($_FILES["img".$i]["size"] > 300000) {
                                $code = 400;
                                $msg = "Sorry, your file is too large.";
                                $img_flag = 1;
                            }
                            if ($imageFileType != "png" && $imageFileType != "PNG" && $imageFileType != "jpeg" && $imageFileType != "JPEG" && $imageFileType != "jpg" && $imageFileType != "JPG" ) {
                                $code = 400;
                                $msg = "Sorry, only image files are allowed.";
                                $img_flag = 1;
                            }
                            if($img_flag == 0){
                                $img_count++;
                            }
                        }
                    }else{
                        $code = 400;
                        $msg .= "Please select product image";
                    }
                    /* Image validation end*/                    
                }else{
                    /* Image validation start*/
                    if($load_img_final_list_length > 0){
                        for($i = 0 ; $i < $load_img_final_list_length ; $i++){
                            $img_flag = 0;
                            $target_file = basename($_FILES["img".$i]["name"]);
                            $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
                            if ($_FILES["img".$i]["size"] > 300000) {
                                $code = 400;
                                $msg = "Sorry, your file is too large.";
                                $img_flag = 1;
                            }
                            if ($imageFileType != "png" && $imageFileType != "PNG" && $imageFileType != "jpeg" && $imageFileType != "JPEG" && $imageFileType != "jpg" && $imageFileType != "JPG" ) {
                                $code = 400;
                                $msg = "Sorry, only image files are allowed.";
                                $img_flag = 1;
                            }
                            if($img_flag == 0){
                                $img_count++;
                            }
                        }
                    }
                    /* Image validation end*/
                }
                if($product_name == ""){
                    $code = 400;
                    $msg .= "<li>Please enter product name</li>";
                }
                if($product_main_id < 0){
                    $code = 400;
                    $msg .= "<li>Please select main category</li>";
                }
                if($product_sub_id < 0){
                    $code = 400;
                    $msg .= "<li>Please select sub category</li>";
                }
                if($product_details == ""){
                    $code = 400;
                    $msg .= "<li>Please enter product details</li>";
                }
                if($original_price == ""){
                    $code = 400;
                    $msg .= "<li>Please enter original price</li>";
                }
                if($basic_offer == ""){
                    $code = 400;
                    $msg .= "<li>Please basic offer</li>";
                }
                if($selling_price == ""){
                    $code = 400;
                    $msg .= "<li>Please enter selling price</li>";
                }
                if($payment_details < "0"){
                    $code = 400;
                    $msg .= "<li>Please select payment details</li>";
                }
                if($quantity == ""){
                    $code = 400;
                    $msg .= "<li>Please enter quantity</li>";
                }else{
                    if($product_id_hidden == 0){
                        if($quantity <0){
                            $code = 400;
                            $msg .= "<li>Please enter valid quantity</li>";
                        }
                    }
                    if($quantity == 0){
                        $live_status = 2;
                    }
                }
                if($publish_status < "0"){
                    $code = 400;
                    $msg .= "<li>Please select publish status</li>";
                }    
                if($publish_status == 2 || $publish_status == 4){
                    if($publish_date == ""){
                        $code = 400;
                        $msg .= "<li>Enter publish date</li>";
                    }else{
                        if($product_id_hidden == 0){
                            $publish_date = $publish_date.":00";
                        }
                        $publish_date = str_replace('T', ' ', $publish_date);
                        /*
                            if(!DateTime::createFromFormat('Y-m-d H:i:s', $publish_date) && DateTime::createFromFormat('Y-m-d H:i:s', $publish_date)->format('Y-m-d H:i:s') != $publish_date){
                                $code = 400;
                                $msg .= "<li>Enter publish date</li>";
                            }*/
                    }
                }
                if($publish_status == 3 || $publish_status == 4){
                    if($close_date == ""){
                        $code = 400;
                        $msg .= "<li>Enter close date</li>";
                    }else{
                        if($product_id_hidden == 0){
                            $close_date = $close_date.":00";
                        }
                        $close_date = str_replace('T', ' ', $close_date);
                        /*if(!DateTime::createFromFormat('Y-m-d H:i:s', $close_date) && DateTime::createFromFormat('Y-m-d H:i:s', $close_date)->format('Y-m-d H:i:s') != $close_date){
                            $code = 400;
                            $msg .= "<li>Enter close date</li>";
                        }*/
                    }
                }
                if($publish_status == 4){
                    if($publish_date != "" && $close_date != ""){
                        if($publish_date > $close_date ){
                            $code = 400;
                            $msg .= '<li>Close date should be greater than end date</li>';
                        }
                    }
                }
                if($delivery_charges < 0 || $delivery_charges == ""){
                    $code = 400;
                    $msg .= "<li>Please enter delivery charges</li>";
                }
                if($delivery_time < 0 || $delivery_time == ""){
                    $code = 400;
                    $msg .= "<li>Please enter delivery time</li>";
                }
                if($return_type < "0"){
                    $code = 400;
                    $msg .= "<li>Please select Return/Replacement type</li>";
                }
                if($return_type > 0){
                    if($return_details == ""){
                        $code = 400;
                        $msg .= "<li>Please enter Return/Replacement ddtails</li>";
                    }
                }                
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                if($code == 0 && $product_id_hidden == 0){
                    date_default_timezone_set('Asia/Kolkata');
                    $product_id = date('YmdGis').rand(100,999);                    
                    $stmt = $conn->prepare("INSERT INTO product (id, shop_uid, product_name, product_main_id, product_sub_id,product_details, original_price, basic_offer, selling_price, payment_details, quantity, status, live_status, publish_date, close_date, delivery_charges, delivery_time, return_type, return_details, warranty) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"); 
                    $stmt->bind_param('ssssssssssssssssssss', $product_id, $shop_uid, $product_name, $product_main_id, $product_sub_id, $product_details, $original_price, $basic_offer, $selling_price, $payment_details, $quantity, $publish_status, $live_status, $publish_date, $close_date, $delivery_charges, $delivery_time, $return_type, $return_details, $warranty);
                    $stmt->execute();
                    //$product_id = $conn->insert_id;
                    $stmt->close();
                    for($i = 0 ; $i < $load_img_final_list_length ; $i++){
                        $target_file = basename($_FILES["img".$i]["name"]);
                        $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
                        $new_name = hash('md5', date('dmY') . time() . mt_rand(1, 100));
                        if (move_uploaded_file($_FILES["img".$i]["tmp_name"], 'img/' . $new_name . '.' . $imageFileType)) {
                            $fileName = $new_name . '.' . $imageFileType;
                            $stmt1 = $conn->prepare("INSERT INTO product_pics (product_id,img) VALUES (?,?)"); 
                            $stmt1->bind_param('ss', $product_id, $fileName);
                            $stmt1->execute();
                            $stmt1->close();
                            $code = 200;
                            $msg = $product_id;
                        } 
                    }
                    /* Insert offer ids */
                    for($i = 0 ; $i < count($offer_ids) ; $i++){	
                        $value = $offer_ids[$i];
                        $stmt2 = $conn->prepare("INSERT INTO product_offer (`product_id`, `offer_id`) VALUES (?,?)"); 
                        $stmt2->bind_param('ss', $product_id, $value);
                        $stmt2->execute();
                        $stmt2->close();
                        $code = 200;
                        $msg = $product_id;
                    }
                    /* Insert product details */
                    for($i = 0 ; $i < count($product_detailsjsonObj) ; $i++){	
                        $type = $product_detailsjsonObj[$i]->type;	
                        $details = $product_detailsjsonObj[$i]->details;
                        $stmt2 = $conn->prepare("INSERT INTO product_details (`product_id`, `details_type`, `details`) VALUES (?,?,?)"); 
                        $stmt2->bind_param('sss', $product_id, $type, $details);
                        $stmt2->execute();
                        $stmt2->close();
                        $code = 200;
                        $msg = $product_id;
                    }
                } 
                //For new product end
                //For update product start  
                if($code == 0 && $product_id_hidden > 0){
                    $available_quantity = htmlspecialchars($_POST["available_quantity"]);
                    $quantity = $available_quantity + $quantity;
                    if($quantity > 0){
                        $live_status = 1;
                    }else{
                        $quantity = 0;
                        $live_status = 2;
                    }
                    $stmt = $conn->prepare("UPDATE `product` SET product_name = ?, product_main_id = ?, product_sub_id = ?, product_details = ?, original_price = ?, basic_offer = ?, selling_price = ?, payment_details = ?, quantity = ?, live_status = ?, status = ?, publish_date = ?, close_date = ?, delivery_charges = ?, delivery_time = ?, return_type = ?, return_details = ?, warranty = ? WHERE id = ?") ; 
                    $stmt->bind_param('sssssssssssssssssss',  $product_name, $product_main_id, $product_sub_id, $product_details, $original_price, $basic_offer, $selling_price, $payment_details, $quantity, $live_status, $publish_status, $publish_date, $close_date, $delivery_charges, $delivery_time, $return_type, $return_details, $warranty, $product_id_hidden);
                    $stmt->execute();
                    $stmt->close();
                    for($i = 0 ; $i < $load_img_final_list_length ; $i++){
                        $target_file = basename($_FILES["img".$i]["name"]);
                        $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
                        $new_name = hash('md5', date('dmY') . time() . mt_rand(1, 100));
                        if (move_uploaded_file($_FILES["img".$i]["tmp_name"], 'img/' . $new_name . '.' . $imageFileType)) {
                            $fileName = $new_name . '.' . $imageFileType;
                            $stmt1 = $conn->prepare("INSERT INTO product_pics (product_id,img) VALUES (?,?)"); 
                            $stmt1->bind_param('ss', $product_id_hidden, $fileName);
                            $stmt1->execute();
                            $stmt1->close();
                            $code = 200;
                            $msg = $product_id_hidden;
                        } 
                    }
                    /* Delete offer ids */
                    $stmt2 = $conn->prepare("DELETE FROM product_offer WHERE product_id = ?"); 
                    $stmt2->bind_param('s', $product_id_hidden);
                    $stmt2->execute();
                    $stmt2->close();
                    /* Insert offer ids */
                    for($i = 0 ; $i < count($offer_ids) ; $i++){	
                        $value = $offer_ids[$i];
                        $stmt2 = $conn->prepare("INSERT INTO product_offer (`product_id`, `offer_id`) VALUES (?,?)"); 
                        $stmt2->bind_param('ss', $product_id_hidden, $value);
                        $stmt2->execute();
                        $stmt2->close();
                        $code = 200;
                        $msg = $product_id_hidden;
                    }
                    /* Delete product details */
                    $stmt2 = $conn->prepare("DELETE FROM product_details WHERE product_id = ?"); 
                    $stmt2->bind_param('s', $product_id_hidden);
                    $stmt2->execute();
                    $stmt2->close();
                    /* Insert product details */
                    for($i = 0 ; $i < count($product_detailsjsonObj) ; $i++){	
                        $type = $product_detailsjsonObj[$i]->type;	
                        $details = $product_detailsjsonObj[$i]->details;
                        $stmt2 = $conn->prepare("INSERT INTO product_details (`product_id`, `details_type`, `details`) VALUES (?,?,?)"); 
                        $stmt2->bind_param('sss', $product_id_hidden, $type, $details);
                        $stmt2->execute();
                        $stmt2->close();
                        $code = 200;
                        $msg = $product_id_hidden;
                    }
                }
                $conn->close();
                //For update product end       
            }
            else{
                $code = 400;
                $msg = "Error";
            }
        }
    //}
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>