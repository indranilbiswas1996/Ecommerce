<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(login_check() != true){
    if(isset($_POST['xcsrf']) ){
        if($_POST['xcsrf'] == $csrf_token) {
            $phone = $_SESSION["phone"];
            if(empty($msg)){
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                    $stmt2 = $conn->prepare("SELECT phone_otp, email_otp FROM superadmin_otp WHERE phone = ?");        
                    $stmt2->bind_param('s', $phone);
                    $stmt2->execute();
                    $stmt2->store_result();
                    $stmt2->bind_result($phone_otp, $email_otp);
                    $p_count = 0; $e_count = 0;
                    if($stmt2->num_rows() == 1){
                        $stmt2->fetch();
                    }
                    $stmt2->close();
                    $code = 200;
                    $msg = "Success"; 
                    /* SMS and Mail*/
                    sendsmsotp($phone, $phone_otp);
                    sendemailotp($phone, $email_otp);
                $conn->close();
            }else{
                $code = 400;
            }
        }
    }
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>