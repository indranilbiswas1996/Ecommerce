<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
frontend_full_access_check();
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
    <?php include 'header.php';?>
    <div class="container">
        <?php include 'mobile_menu.php'; ?>
        <div class="dashboard-details-container">
        <div class="alert alert-danger" id="login_err"></div>
            <div class="dashboard-details-inner-container center">
                <div class="dashboard-details-inner-div-first">
                    <div class="alert alert-danger" id="shop_type_err">
                    </div>
                    <div class="main-category-textbox-container">
                        <label class="login-label">Shop type<span class="red">*</span></label>
                        <input type="text" name="shop_type" id="shop_type" class="login-textbox" placeholder="Enter shop type">
                        <input type="hidden" id="shop_type_hidden" value="0">
                    </div>                    
                    <div class="main-category-button-container">
                        <button type="submit" class="login-button" name="add_shop_type" id="add_shop_type" onclick="add_shop_type()" >Add</button>
                    </div>                    
                    <div class="main-category-button-container">
                        <button type="submit" class="login-button background-red" name="reset_shop_type" id="reset_shop_type" onclick="reset_shop_type()" >Reset</button>
                    </div>
                </div>
            </div>
            <div class="dashboard-details-inner-container center">
            <?php
                $one = 1;
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                $stmt = $conn->prepare("SELECT `id`, `shop_type_details` FROM `shop_type` ORDER BY shop_type_details ASC");
                //$stmt->bind_param('ss', $_SESSION['shop_uid'], $one);
                $stmt->execute();
                $stmt->store_result();
                if($stmt->num_rows() != 0){                    
                    $stmt->bind_result($id, $details);
                    while($stmt->fetch()){
                        echo '<div class="category-item-container">
                            <div class="main-category-item background-green white">'
                                .$details.
                                '<div class="category-item-action">
                                    <span class="fa fa-edit white" onclick="edit_shop_type('.$id.',\''.$details.'\')"></span>
                                    <span class="fa fa-trash red" onclick="delete_shop_type('.$id.',\''.$details.'\')"></span>
                                </div>
                            </div>
                            
                        </div>';
                    }
                }
                $stmt->close();
                $conn->close();
            ?>    
            </div>
        </div>
    </div>
<script type="text/javascript">   
/* Main category */
    function reset_shop_type(){
        $("#shop_type_err").css("display","none");
        document.getElementById('shop_type').value = "";
        document.getElementById('shop_type_hidden').value = "0";
        try{
            $('input').removeClass('outline-red');
            $('select').removeClass('outline-red');
        }catch(e){}
    }
    function edit_shop_type(id, details){
        document.getElementById('shop_type').value = details;
        document.getElementById('shop_type_hidden').value = id;
    }
    function add_shop_type(){
        var err = "";
        var shop_type = document.getElementById('shop_type').value;
        var shop_type_hidden = document.getElementById('shop_type_hidden').value;
        if(shop_type == ""){
            err +=  '<li>Enter main category</li>';
            document.getElementById("shop_type").classList.add("outline-red");
        }
        if(err != ""){
            console.log(err);           
            $("#shop_type_err").html("<ul>"+err+"</ul>");
            $("#shop_type_err").css("display","block");
        }else{
            var ajaxRequest, fd;
            try {
                ajaxRequest = new XMLHttpRequest();
            }catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                }catch (e) {
                    try{
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    }catch (e){
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }
            ajaxRequest.onreadystatechange = function(){
                if(ajaxRequest.readyState == 4){
                    var data = JSON.parse(ajaxRequest.responseText);
                    if(data.code == "200"){
                        window.location.reload();
                    }else{
                        $("#shop_type_err").html("<ul>"+data.msg+"</ul>");
                        $("#shop_type_err").css("display","block");
                    }
                }
            }
            fd = new FormData();
            fd.append("shop_type", shop_type);
            fd.append("shop_type_hidden", shop_type_hidden);
            fd.append("xcsrf", "<?php echo $csrf_token;?>");          
            ajaxRequest.open("POST", "add_shop_type_background.php", true);
            ajaxRequest.send(fd);
        }
    }
    function delete_shop_type(id, details){    
        if(confirm("Are you sure to delete the "+details+" ? Press ok to confirm.")){    
            var ajaxRequest, fd;
            try {
                ajaxRequest = new XMLHttpRequest();
            }catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                }catch (e) {
                    try{
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    }catch (e){
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }
            ajaxRequest.onreadystatechange = function(){
                if(ajaxRequest.readyState == 4){
                    var data = JSON.parse(ajaxRequest.responseText);
                    if(data.code == "200"){
                        window.location.reload();;
                    }else{
                        $("#login_err").html("<ul>"+data.msg+"</ul>");
                        $("#login_err").css("display","block");
                    }
                }
            }
            fd = new FormData();
            fd.append("shop_type_id", id);
            fd.append("xcsrf", "<?php echo $csrf_token;?>");          
            ajaxRequest.open("POST", "delete_shop_type_background.php", true);
            ajaxRequest.send(fd);
        }
    }
    
</script>
</body>
</html>