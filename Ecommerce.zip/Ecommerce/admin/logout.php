<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
session_destroy();
header("Location: login.php");
?>