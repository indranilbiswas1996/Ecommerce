<span class="show-menu" id="showMenu" onclick="showMenu(1)"><i class="fa fa-bars"></i></span>
<div class="dashboard-menu-container" id="dashboard_menu_container">
    <a href="index.php">Home</a>
    <a href="superadminlist.php">Superadmin </a>
    <a href="adminlist.php">Admin</a>
    <a href="customerlist.php">Customer</a>
    <a href="request.php">Request</a>
    <a href="shoptype.php">Shop type</a>
    <div class="gap-div background-pink"><span class="fa fa-user-circle-o"></span> Information</div>
    <a href="superadmindetails.php">Profile</a>
    <a href="changepassword.php">Change password</a>
    <a href="changemobile.php">Change mobile number</a>
    <a href="settings.php">Settings</a>

    <script type="text/javascript">
        function showMenu(i){
            if(i == 1){
                document.getElementById('dashboard_menu_container').style.display = 'block';
                document.getElementById("showMenu").setAttribute( "onClick", "showMenu(0)" );
            }else{
                document.getElementById('dashboard_menu_container').style.display = 'none';
                document.getElementById("showMenu").setAttribute( "onClick", "showMenu(1)" );
            }
        }
    </script>
</div>