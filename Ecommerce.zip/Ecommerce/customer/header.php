<header>
    <div class="topnav-desktop">
        <a class="img-icon-a" href="index.php">
            <img src="icons/2.png" class="img-icon">
        </a>
        <div class="search-container">
            <form action="">
                <input type="text" id="search" name="search" placeholder="Search for products, brands and more">
                <button type="submit"><i class="fa fa-search"></i></button>
                <div class="desktop-hover-search">
                    <a href="#">Profile</a>
                    <a href="#">Orders</a>
                    <a href="#">Wishlist</a>
                    <a href="#">Address</a>
                    <a href="#">Logout</a>
                </div>
            </form>
        </div>
        <?php if(login_check() == true){ ?>
        <div class="desktop-hover-menu-container">
            <span class="topnav-desktop-a desktop-hover-icon"><i class="fa fa-user-circle-o" aria-hidden="true"></i> &nbsp;<?php echo $_SESSION['f_name'] ?></span>
            <div class="desktop-hover-menu">
                <i class="triangle-up"></i>
                <a href="profile.php"><i class="fa fa-user-circle-o" aria-hidden="true"></i> &nbsp;Profile</a>
                <a href="orders.php"><i class="fa fa-truck" aria-hidden="true"></i> &nbsp;Orders</a>
                <a href="wishlist.php"><i class="fa fa-heart" aria-hidden="true"></i> &nbsp;Wishlist</a>
                <a href="address.php"><i class="fa fa-address-card-o" aria-hidden="true"></i> &nbsp;Address</a>
                <a href="logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i> &nbsp;Logout</a>
            </div>
        </div>
        <?php }else{ ?>
            <a class="topnav-desktop-a" href="login.php"> <i class="fa fa-user-circle-o" aria-hidden="true"></i> &nbsp;Login</a>
        <?php } ?>            
        <a class="topnav-desktop-a" href="cart.php">
        <i class="fa fa-shopping-cart" aria-hidden="true"></i>
            <script>
                try{
                    var cart_count = JSON.parse(localStorage.getItem('product')).length;
                    if(cart_count > 0){
                        document.write('<div class="KK-o3G">'+cart_count+'</div>');
                    }
                }catch{}
                
            </script>
            &nbsp;Cart
        </a>
    </div> 
    <div class="topnav-mobile">
        <a class="img-icon-a" href="index.php">
            <img src="icons/2.png" class="img-icon">
        </a>
        <?php if(login_check() == true){ ?>
            <a class="topnav-mobile-a" href="logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i></a>
            <a class="topnav-mobile-a" href="cart.php"><i class="fa fa-shopping-cart" aria-hidden="true"></i> 
            <script>
                try{
                    var cart_count = JSON.parse(localStorage.getItem('product')).length;
                    if(cart_count > 0){
                        document.write('<div class="KK-o3G">'+cart_count+'</div>');
                    }
                }catch{}
            </script>
            </a>
            <a class="topnav-mobile-a" href="profile.php"> <i class="fa fa-user-circle-o" aria-hidden="true"></i></a>
        <?php }else{ ?>
            <a class="topnav-mobile-a" href="login.php">Login</a>
            <a class="topnav-mobile-a" href="cart.php"><i class="fa fa-shopping-cart" aria-hidden="true"></i>
            <script>
                try{
                    var cart_count = JSON.parse(localStorage.getItem('product')).length;
                    if(cart_count > 0){
                        document.write('<div class="KK-o3G">'+cart_count+'</div>');
                    }
                }catch{}
            </script>
            &nbsp;Cart</a>
        <?php } ?>
        <div class="search-container">
            <form action="#">
                <input type="text" placeholder="Search for products, brands and more" name="search">
                <button type="submit"><i class="fa fa-search"></i></button>
                <div class="desktop-hover-search">
                    <a href="#">Profile</a>
                    <a href="#">Orders</a>
                    <a href="#">Wishlist</a>
                    <a href="#">Address</a>
                    <a href="#">Logout</a>
                </div>
            </form>
        </div>
    </div> 
</header>