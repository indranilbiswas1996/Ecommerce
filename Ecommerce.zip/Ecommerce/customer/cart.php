<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
if(isset($_GET['product'])){
    $product_id = $_GET['product'];
    //echo $product_id;
}
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
<?php include 'header.php';?>
<!--
<script type="text/javascript">
var storedNames = JSON.parse(localStorage.getItem("product"));
if(storedNames == null){
    //alert(0);
    var namesArr = [];  
    namesArr.push('a'); 
    namesArr.push('b'); //Add the text 'item1' to nameArr
    localStorage.setItem('product', JSON.stringify(namesArr));
}else{
    var namesArr = storedNames;
    //namesArr.push('d'); //Add the text 'item1' to nameArr
    /* Remove
    const index = namesArr.indexOf('d');
    if (index > -1) {
        namesArr.splice(index, 1);
    }*/
    localStorage.setItem('product', JSON.stringify(namesArr));
    for(var i=0; i<storedNames.length; i++){
        alert(storedNames[i]);
    }
}
//localStorage.clear();
</script>
-->
<?php
$a = "<script>document.write(JSON.parse(localStorage.getItem('product')))</script>";
//echo $a;
include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
$zero = "20210525160658925,20210525154146494";
$stmt = $conn->prepare("SELECT product_name FROM product WHERE id IN (?)");
$stmt->bind_param('s', $zero);  
$stmt->execute();
$stmt->store_result();

if($stmt->num_rows() != 0){
    $stmt->bind_result($product_name);             
    while($stmt->fetch()){
        echo $product_name." : ";
    }
}else{
    echo 'No row';
}
?>
</body>
</html>