<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">    
    <?php include 'header_files.php';?>
</head>
<body>
<?php include 'header.php';?>
<div class="container">
    <div class="login-container">
            <div class="login-div">
                <div class="login-part">
                    <!-- Login -->
                    <div class="login-part-inner  alert-danger">
                        <div class="login-item">
                            <label class="login-label">
                            <?php 
                                echo 'Dear '.$_SESSION['f_name'].', <br><br> Your application will be verified soon. You will get approvial sms/email.<br> <br> Thank you';
                                
                                /*echo 'Admin status : '.$_SESSION['admin_status'].'<br>';
                                echo 'Mobile number : '.$_SESSION['phone'].'<br>';
                                echo 'Shop id : '.$_SESSION['shop_uid'].'<br>';
                                echo 'Name : '.$_SESSION['f_name'].'<br><br><br>';*/
                            ?>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
    </div>
</div>
</body>
</html>