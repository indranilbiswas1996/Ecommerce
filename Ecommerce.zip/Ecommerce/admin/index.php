<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
/*if(login_check() == false){
    header("Location: login.php");
}else{
    if($_SESSION['shop_uid'] == null || $_SESSION['shop_uid'] == ""){
        header("Location: shop.php");
    }else{
        if($_SESSION['admin_status'] == 0){
            header("Location: status.php");
        }
    }
}*/
frontend_full_access_check();
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
    <?php include 'header.php';?>
    <div class="container">
        <?php include 'mobile_menu.php'; ?>  
        <?php
            include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
            $stmt = $conn->prepare("SELECT * FROM `product` WHERE shop_uid = ?");
            $stmt->bind_param('s', $_SESSION['shop_uid']);  
            $stmt->execute();
            $stmt->store_result();
            $total_product = $stmt->num_rows();
           
            $stmt = $conn->prepare("SELECT * FROM `offer` WHERE shop_uid = ?");
            $stmt->bind_param('s', $_SESSION['shop_uid']);  
            $stmt->execute();
            $stmt->store_result();
            $total_offer = $stmt->num_rows();
            $stmt->close();
            $conn->close();
        ?>      
        <div class="dashboard-details-container center">
            <div class="dashboard-details-inner-container">
                <div class="card-container">
                    <a href="#">
                        <span class="green"><span class="fa fa-dollar"></span></span>
                        <span class="green">&nbsp;</span>
                        <span class="background-green">Transaction</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="product.php">
                        <span class="blue"><span class="fa fa-plus"></span></span>
                        <span class="blue">&nbsp;</span>
                        <span class="background-blue">Add Product</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="productlist.php">
                        <span class="sky"><span class="fa fa-shopping-bag"></span></span>
                        <span class="sky"><?php echo $total_product; ?></span>
                        <span class="background-sky">Product List</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="offer.php">
                        <span class="violet"><span class="fa fa-percent"></span></span>
                        <span class="violet"><?php echo $total_offer; ?></span>
                        <span class="background-violet">Offers</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="pink"><span class="fa fa-group"></span></span>
                        <span class="pink">&nbsp;</span>
                        <span class="background-pink">Group</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="sky"><span class="fa fa-cart-plus"></span></span>
                        <span class="sky">&nbsp;</span>
                        <span class="background-sky">New orders</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="violet"><span class="fa fa-gift"></span></span>
                        <span class="violet">&nbsp;</span>
                        <span class="background-violet">Packed</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="blue"><span class="fa fa-truck"></span></span>
                        <span class="blue">&nbsp;</span>
                        <span class="background-blue">Shipped</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="green"><span class="fa fa-dropbox"></span></span>
                        <span class="green">&nbsp;</span>
                        <span class="background-green">Delivered</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="pink"><span class="fa fa-undo"></span></span>
                        <span class="pink">&nbsp;</span>
                        <span class="background-pink">Returned</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="yellow"><span class="fa fa-exchange"></span></span>
                        <span class="yellow">&nbsp;</span>
                        <span class="background-yellow">Replacement</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="red"><span class="fa fa-close"></span></span>
                        <span class="red">&nbsp;</span>
                        <span class="background-red">Cancelled</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="blue"><span class="fa fa-star"></span></span>
                        <span class="blue">&nbsp;</span>
                        <span class="background-blue">Rating</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>