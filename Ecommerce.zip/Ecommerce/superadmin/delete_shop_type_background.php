<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(backend_full_access_check() == true){
    //if($_SESSION['shop_uid'] != null || $_SESSION['shop_uid'] != ""){
        if(isset($_POST['xcsrf']) ){
            if($_POST['xcsrf'] == $csrf_token) {
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                $shop_type_id = htmlspecialchars($_POST["shop_type_id"]);
                if($shop_type_id > 0){
                    //----- Update product
                    $stmt2 = $conn->prepare("SELECT shop_type FROM shop WHERE shop_type = ?");
                    $stmt2->bind_param('s', $shop_type_id);
                    $stmt2->execute();
                    $stmt2->store_result();
                    if($stmt2->num_rows() != 0){                    
                        $code = 400;
                        $msg .= "<li>The shop type already used by retailer. Can't delete the shop type. But it is editable.</li>";
                    }else{
                        //----- Delete from product_shop_type
                        $stmt4 = $conn->prepare("DELETE FROM shop_type WHERE id = ?"); 
                        $stmt4->bind_param('s', $shop_type_id);
                        $stmt4->execute();
                        $stmt4->close();
                        $code = 200;
                        $msg .= "Success";
                    }
                    $stmt2->close();
                    
                }                    
                $conn->close();
            }
        }
    //}
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>