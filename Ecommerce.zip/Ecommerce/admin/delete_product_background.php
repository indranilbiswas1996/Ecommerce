<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(backend_full_access_check() == true){
    //if($_SESSION['shop_uid'] != null || $_SESSION['shop_uid'] != ""){
        if(isset($_POST['xcsrf']) ){
            if($_POST['xcsrf'] == $csrf_token) {
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                $product_id = htmlspecialchars($_POST["product_id"]);
                if($product_id > 0){
                    //----- Delete product_offer
                    $stmt = $conn->prepare("DELETE FROM product_offer WHERE product_id = ?"); 
                    $stmt->bind_param('s', $product_id);
                    $stmt->execute();
                    $stmt->close();
                    //----- Delete from product_pics and keeping only one img.
                    /*$stmt1 = $conn->prepare("SELECT id, img FROM product_pics WHERE product_id = ? AND ID NOT IN (SELECT ID FROM (SELECT ID FROM product_pics WHERE product_id = ? ORDER BY ID ASC LIMIT 1)a)");
                    $stmt1->bind_param('ss', $product_id, $product_id);
                    $stmt1->execute();
                    $stmt1->store_result();
                    if($stmt1->num_rows() != 0){                    
                        $stmt1->bind_result($id, $img);
                        while($stmt1->fetch()){
                            unlink('img/'.$img);
                            $stmt2 = $conn->prepare("DELETE FROM product_pics WHERE id = ?"); 
                            $stmt2->bind_param('s', $id);
                            $stmt2->execute();
                            $stmt2->close();
                        }
                    }
                    $stmt1->close();*/
                    //----- Delete from product_details.
                    /*$stmt2 = $conn->prepare("DELETE FROM product_details WHERE product_id = ?"); 
                    $stmt2->bind_param('s', $product_id);
                    $stmt2->execute();
                    $stmt2->close();*/
                    //----- Update live_status in product as 0(Deleted)
                    $live_status = 0;
                    $zero = 0;
                    $stmt3 = $conn->prepare("UPDATE product SET live_status=?, quantity=? WHERE id = ?"); 
                    $stmt3->bind_param('sss', $live_status, $zero, $product_id);
                    $stmt3->execute();
                    $stmt3->close();
                    $code = 200;
                    $msg .= "Success";
                }
                $conn->close();
            }
        }
    //}
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>