<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(backend_full_access_check() == true){
    //if($_SESSION['shop_uid'] != null || $_SESSION['shop_uid'] != ""){
        if(isset($_POST['xcsrf']) ){
            if($_POST['xcsrf'] == $csrf_token) {
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                $offer_id = htmlspecialchars($_POST["offer_id"]);
                if($offer_id > 0){
                    //----- Update product_offer
                    $stmt = $conn->prepare("DELETE FROM product_offer WHERE offer_id = ?"); 
                    $stmt->bind_param('s', $offer_id);
                    $stmt->execute();
                    $stmt->close();
                    //----- Delete from offer
                    $stmt2 = $conn->prepare("DELETE FROM offer WHERE id = ?"); 
                    $stmt2->bind_param('s', $offer_id);
                    $stmt2->execute();
                    $stmt2->close();
                    $code = 200;
                    $msg .= "Success";
                }
                $conn->close();
            }
        }
    //}
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>