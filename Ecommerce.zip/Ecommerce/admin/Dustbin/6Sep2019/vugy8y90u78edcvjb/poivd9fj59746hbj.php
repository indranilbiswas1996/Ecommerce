<?php
/**
 * Created by IntelliJ IDEA.
 * User: INDRANIL
 * Date: 9/4/2019
 * Time: 11:06 AM
 */
$page_title = 'Ecommerce';
$profile_name = 'Signup';
session_start();
if(isset($_SESSION['logged_in'])) {
    if ($_SESSION['logged_in'] == 1) {
        $profile_name = $_SESSION["f_name"];
    }
}
function make_hash($pass)
{
    $salt = substr(strtr(base64_encode(openssl_random_pseudo_bytes(22)), '+', '.'), 0, 22);
    $hash = crypt($pass, '$2y$10$' . $salt);
    return str_replace("$2y$10$", "",$hash);
}
//Use this Function to check if the given password is correct
function check_hash($pass, $hash)
{
    $hash = '$2y$10$'.$hash;
    if(crypt($pass, $hash) == $hash)
    {
        return true;
    }
    else
    {
        return false;
    }
}
function login_check(){
    $res = false;
    if(isset($_SESSION['logged_in'])) {
        if ($_SESSION['logged_in'] == 1) {
            $res = true;
        }
    }
    return $res;
}
?>