<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
//if(isset($_SESSION['admin_status']) || isset($_SESSION['phone'])){
if(isset($_SESSION['phone']) && !isset($_SESSION['logged_in'])){
    if(isset($_POST['xcsrf']) ){
        if($_POST['xcsrf'] == $csrf_token) {
            $phone_otp = htmlspecialchars($_POST["phone_otp"]);        
            if(empty($phone_otp)){
                $code = 400;
                $msg .= "<li>Enter OTP</li>";
            }
            if(empty($msg)){
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                $stmt = $conn->prepare("SELECT phone_otp FROM superadmin_otp WHERE phone = ?");        
                $stmt->bind_param('s', $_SESSION['phone']);
                $stmt->execute();
                $stmt->store_result();
                $stmt->bind_result($db_phone_otp);
                if($stmt->num_rows() == 1){
                    $stmt->fetch();
                    if($db_phone_otp == $phone_otp){
                        $one = 1;
                        $stmt2 = $conn->prepare("UPDATE superadmin SET verify_phone = ? WHERE phone = ?");        
                        $stmt2->bind_param('ss', $one, $_SESSION['phone']);
                        $stmt2->execute();
                        $stmt2->close();
                        $_SESSION['logged_in'] = 1;
                        //$_SESSION['admin_status'] = $one;
                        if(isset($_SESSION['forgot'])){
                            if($_SESSION['forgot'] == $one){
                                $code = 201;
                                $msg = "Change password";
                            }
                        }else{
                            $code = 200;
                            $msg = "Success";
                        }
                    }else{
                        $code = 400;
                        $msg = "<li>Wrong OTP</li>";
                    }
                }
                else{
                    $code = 400;
                    $msg = "<li>Account Doesn't exist</li>";
                }
                $stmt->close();
                $conn->close();
            }else{
                $code = 400;
            }
        }
    }
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>