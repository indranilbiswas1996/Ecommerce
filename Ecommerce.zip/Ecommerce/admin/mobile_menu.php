<span class="show-menu" id="showMenu" onclick="showMenu(1)"><i class="fa fa-bars"></i></span>
<div class="dashboard-menu-container" id="dashboard_menu_container">
    <a href="index.php">Home</a>
    <a href="transaction.php">Transaction</a>
    <a href="product.php">Add Product</a>
    <a href="productlist.php">Product List</a>
    <a href="category.php">Category</a>
    <a href="offer.php">Offers</a>
    <a href="orders.php">New orders</a>
    <a href="packed.php">Packed</a>
    <a href="shipped.php">Shipped</a>
    <a href="delivered.php">Delivered</a>
    <a href="return.php">Returned</a>
    <a href="replaced.php">Replaced</a>
    <a href="cancelled.php">Cancelled</a>
    <a href="rating.php">Rating</a>
    <div class="gap-div background-pink"><span class="fa fa-user-circle-o"></span> Information</div>
    <a href="shop.php">Profile</a>
    <a href="group.php">Group</a>
    <a href="changepassword.php">Change password</a>
    <a href="changemobile.php">Change mobile number</a>
    <a href="settings.php">Settings</a>

    <script type="text/javascript">
        function showMenu(i){
            if(i == 1){
                document.getElementById('dashboard_menu_container').style.display = 'block';
                document.getElementById("showMenu").setAttribute( "onClick", "showMenu(0)" );
            }else{
                document.getElementById('dashboard_menu_container').style.display = 'none';
                document.getElementById("showMenu").setAttribute( "onClick", "showMenu(1)" );
            }
        }
    </script>
</div>