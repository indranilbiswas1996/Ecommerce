<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(backend_full_access_check() == true){
    if(isset($_POST['xcsrf']) ){
        if($_POST['xcsrf'] == $csrf_token) {
            include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
            $admin_type = htmlspecialchars($_POST["admin_type"]);
            $phone = htmlspecialchars($_POST["phone"]);
            if($admin_type == 0){
                $one = -1;
                $stmt = $conn->prepare("UPDATE superadmin SET admin_status = ? WHERE phone = ?"); 
                $stmt->bind_param('ss', $one, $phone);
                $stmt->execute();
                $stmt->close();
                $code = 200;
                $msg .= "Success";
            }
            if($admin_type == 1){
                $one = -1;
                $stmt = $conn->prepare("UPDATE admin SET admin_status = ? WHERE phone = ?"); 
                $stmt->bind_param('ss', $one, $phone);
                $stmt->execute();
                $stmt->close();
                $code = 200;
                $msg .= "Success";
            }
            $conn->close();
        }
    }
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>