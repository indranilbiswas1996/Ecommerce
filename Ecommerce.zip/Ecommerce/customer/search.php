<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
    <?php include 'header.php';?>
    <div class="container">
        <div class="search-container">
            <div class="productlist-container">
            <?php
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                $zero = 0;
                $stmt = $conn->prepare("SELECT p.id,  p.product_name,  p.status, p.live_status, p.original_price, p.basic_offer, p.selling_price, p.publish_date, p.close_date, s.shop_name FROM product p, shop s WHERE p.status > ? AND p.live_status > ? AND p.shop_uid = s.shop_uid");
                $stmt->bind_param('ss', $zero, $zero);  
                $stmt->execute();
                $stmt->store_result();
                
                if($stmt->num_rows() != 0){                    
                    $stmt->bind_result($product_id, $product_name, $status, $live_status, $original_price, $basic_offer, $selling_price, $publish_date, $close_date, $shop_name);
                    while($stmt->fetch()){
                        $flag = 0;
                        if($status == 1){
                            $flag = 1;
                        }
                        if($status == 2){
                            date_default_timezone_set('Asia/Kolkata');
                            $current_time = date('Y-m-d H:i:s');
                            if($current_time > $publish_date){
                                $flag = 1;
                            }                                                   
                        }
                        if($status == 3){
                            date_default_timezone_set('Asia/Kolkata');
                            $current_time = date('Y-m-d H:i:s');
                            if($current_time < $close_date){
                                $flag = 1;
                            }                                                   
                        }
                        if($status == 4){
                            date_default_timezone_set('Asia/Kolkata');
                            $current_time = date('Y-m-d H:i:s');
                            if($current_time > $publish_date && $current_time < $close_date){
                                $flag = 1;
                            }                                                    
                        }
                        if($flag == 1){
                            $stmt1 = $conn->prepare("SELECT `img` FROM `product_pics` WHERE product_id = ? LIMIT 1");
                            $stmt1->bind_param('s', $product_id);
                            $stmt1->execute();
                            $stmt1->store_result();
                            if($stmt1->num_rows() != 0){                    
                                $stmt1->bind_result($img);
                                while($stmt1->fetch()){
                                    //echo '<img src="'.$img_link.'img/'.$img.'">';
                                    echo '
                                        
                                        <div class="product-container">
                                            <span class="wishlist-span" onclick="wishlist('.$product_id.')"><i class="fa fa-heart" aria-hidden="true"></i></span>
                                            <a href="product.php?product='.$product_id.'" target="_blank">
                                                <div class="product-img-container">
                                                    <img src="'.$img_link.'img/'.$img.'">
                                                </div>
                                                <div class="product-details-container">
                                                    <span class="product-shop-span">'.$shop_name.'</span>
                                                    <span class="product-details-span">'.$product_name.'</span>
                                                    <span class="product-selling-price-span">₹'.$selling_price.'</span>
                                                    <span class="product-actual-price-span">₹'.$original_price.'</span>
                                                    <span class="product-offer-span">'.$basic_offer.'% off</span>
                                                </div>
                                            </a>
                                        </div>
                                    ';
                                }
                            }
                            $stmt1->close();
                        }
                    }
                }		
                $stmt->close();
                $conn->close();
            ?>
                <!--<a href="">
                    <div class="product-container">
                        <i class="fa fa-heart" onclick="wishlist()" aria-hidden="true"></i>
                        <div class="product-img-container">
                            <img src="http://localhost/Ecommerce/admin/img/tv1.jpeg" />
                        </div>
                        <div class="product-details-container">
                            <span class="product-shop-span">Sofdvine</span>
                            <span class="product-details-span">Designer Black Ankle-Length Boots Boots For Men</span>
                            <span class="product-selling-price-span">₹16200</span>
                            <span class="product-actual-price-span">₹18000</span>
                            <span class="product-offer-span">10% off</span>
                        </div>
                    </div>
                </a>-->
            </div>
        </div>
    </div>
</body>
<script language="javascript">
    function wishlist(id){
        alert(id);
    }
</script>
</html>