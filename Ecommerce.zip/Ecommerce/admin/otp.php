<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
if(!isset($_SESSION['phone'])){
    header("Location: logout.php");
}
if(isset($_SESSION['logged_in'])){
    if($_SESSION['logged_in'] == 1){
        header("Location: logout.php");
    }
}
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
<?php include 'header.php';?>
<div class="container">
    <div class="login-container">
            <div class="login-div">
                <div class="login-part">
                    <!-- Login -->
                    <div class="login-part-inner" id="login_div" >
                        <div class="headline"><span>Verify OTP</span></div>
                        <div class="alert alert-danger" id="login_err">
                        </div>
                        <div class="login-item">
                            <label class="login-label">Mobile number<span class="red">*</span></label>
                            <input type="text" name="userid" id="userid" class="login-textbox" value="<?php echo $_SESSION['phone']; ?>" disabled>
                        </div>
                        <div class="login-item">
                            <label class="login-label">OTP<span class="red">*</span></label>
                            <input type="number" name="phone_otp" id="phone_otp" class="login-textbox" placeholder="Enter OTP">
                        </div>
                        <div class="login-item">
                            <button type="submit" class="login-button background-green" name="verify_otp" id="verify_otp" onclick="verify_otp()" >Verify OTP</button>
                        </div>
                        <div class="login-item">
                            <button type="submit" style="cursor: no-drop;" class="login-button background-red" name="resend_otp" id="resend_otp" onclick="resend_otp()" disabled>Resend OTP</button>
                        </div>
                        <div id="timer">&nbsp;</div>                        
                    </div>
                </div>
            </div>
    </div>
    
    <img src="icons/banner.png" class="banner"/>
</div>
<script type="text/javascript">
    function verify_otp(){
        var err = "";
        var phone_otp = document.getElementById('phone_otp').value;
        if (phone_otp == "") {
            err += "<li>Enter OTP</li>";
            document.getElementById("phone_otp").classList.add("outline-red");
        }
        if(err != ""){          
            $("#login_err").html("<ul>"+err+"</ul>");
            $("#login_err").css("display","block");
        }else{
            var ajaxRequest, fd;
            try {
                ajaxRequest = new XMLHttpRequest();
            }catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                }catch (e) {
                    try{
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    }catch (e){
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }
            ajaxRequest.onreadystatechange = function(){
                if(ajaxRequest.readyState == 4){
                    var data = JSON.parse(ajaxRequest.responseText);
                    if(data.code == "200"){
                        window.location = "index.php";
                    }else if(data.code == "201"){
                        window.location = "changepassword.php";
                    }else{
                        $("#login_err").html("<ul>"+data.msg+"</ul>");
                        $("#login_err").css("display","block");
                    }
                }
            }
            fd = new FormData();
            fd.append("phone_otp", phone_otp);   
            fd.append("xcsrf", "<?php echo $csrf_token;?>");          
            ajaxRequest.open("POST", "otp_background.php", true);
            ajaxRequest.send(fd);
        }        
    }
    function resend_otp(){
        var ajaxRequest, fd;
        try {
            ajaxRequest = new XMLHttpRequest();
        }catch (e) {
            try {
                ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
            }catch (e) {
                try{
                    ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                }catch (e){
                    alert("Your browser broke!");
                    return false;
                }
            }
        }
        ajaxRequest.onreadystatechange = function(){
            if(ajaxRequest.readyState == 4){
                var data = JSON.parse(ajaxRequest.responseText);
                if(data.code == "200"){
                    window.location.reload();
                }else{
                    $("#login_err").html("<ul>"+data.msg+"</ul>");
                    $("#login_err").css("display","block");
                }
            }
        }
        fd = new FormData();
        fd.append("xcsrf", "<?php echo $csrf_token;?>");          
        ajaxRequest.open("POST", "resend_otp_background.php", true);
        ajaxRequest.send(fd);
    }
    var timeleft = 30;
	var downloadTimer = setInterval(function(){
        if(timeleft == 0){
            clearInterval(downloadTimer);
            document.getElementById("timer").innerHTML = "&nbsp;";
        } else {
            document.getElementById("timer").innerHTML ="* "+  timeleft + " seconds remaining to resend OTP";
        }
        timeleft -= 1;
	}, 1000);
	window.onload = function() {
    	window.setTimeout(setEnable, (timeleft+1)*1000);
	}
	function setEnable() {
		document.getElementById('resend_otp').disabled = false;
		document.getElementById('resend_otp').style.cursor = 'pointer';
		document.getElementById('resend_otp').style.background = '#FF9800';
	}
</script>
</body>
</html>