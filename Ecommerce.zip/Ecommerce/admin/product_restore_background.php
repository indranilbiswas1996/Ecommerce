<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(backend_full_access_check() == true){
    //if($_SESSION['shop_uid'] != null || $_SESSION['shop_uid'] != ""){
        if(isset($_POST['xcsrf']) ){
            if($_POST['xcsrf'] == $csrf_token) {
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                $product_id = htmlspecialchars($_POST["product_id"]);
                if($product_id > 0){
                    //----- Update product_offer
                    $live_status = 1;

                    $stmt1 = $conn->prepare("SELECT quantity FROM product WHERE id = ?");
                    $stmt1->bind_param('s', $product_id);
                    $stmt1->execute();
                    $stmt1->store_result();
                    $stmt1->bind_result($quantity);
                    if($stmt1->num_rows() != 0){   
                        $stmt1->fetch();
                        if($quantity <= 0){
                            $live_status = 2;
                        }
                    }    
                    $stmt1->close();
                    $stmt = $conn->prepare("UPDATE product SET live_status=? WHERE id = ?"); 
                    $stmt->bind_param('ss', $live_status, $product_id);
                    $stmt->execute();
                    $stmt->close();
                    $code = 200;
                    $msg .= "Success";
                }
                $conn->close();
            }
        }
    //}
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>