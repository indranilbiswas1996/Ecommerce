<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(login_check() == true){
    if(isset($_POST['xcsrf']) ){
        if($_POST['xcsrf'] == $csrf_token) {
            $n_password = htmlspecialchars($_POST["n_password"]);
            $c_password = htmlspecialchars($_POST["c_password"]);     
            if(empty($_POST["n_password"])){
                $code = 400;
                $msg .= "<li>Enter New password</li>";
            }
            if(empty($_POST["c_password"])){
                $code = 400;
                $msg .= "<li>Enter Confirm password</li>";
            }
            if(!preg_match('/^(?=.*\d)(?=.*[A-Za-z])[0-9A-Za-z!@#$%]{8,12}$/', $_POST["n_password"])) {
                $code = 400;
                $msg .= '<li>Week password!</li>';
                $msg .= "Use at least 8 to 12 characters</br>";
                $msg .= "Use 1 or more alphabet</br>";
                $msg .= "Use 1 or more number</br>";
                $msg .= "Use 1 or more special characters";
            }
            if($c_password != $n_password) {
                $code = 400;
                $msg .= "<li>Password does not match</li>";
            }
            if(empty($msg)){
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                $one = 1;
                $password_hash = make_hash($c_password);
                $stmt2 = $conn->prepare("UPDATE admin SET password = ? WHERE phone = ?");        
                $stmt2->bind_param('ss', $password_hash, $_SESSION['phone']);
                $stmt2->execute();
                $stmt2->close();
                //$_SESSION['logged_in'] = 1;
                //$_SESSION['admin_status'] = $one;
                if(isset($_SESSION['forgot'])){
                    unset($_SESSION['forgot']);
                }
                $code = 200;
                $msg = "Success";
                $conn->close();
            }else{
                $code = 400;
            }
        }
    }
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>