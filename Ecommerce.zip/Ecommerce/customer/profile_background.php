<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(login_check() == true){
    if(isset($_POST['xcsrf']) ){
        if($_POST['xcsrf'] == $csrf_token) {
            $f_name =htmlspecialchars($_POST["f_name"]);
            $m_name =htmlspecialchars($_POST["m_name"]);
            $l_name =htmlspecialchars($_POST["l_name"]);
            $gender = htmlspecialchars($_POST["gender"]);
            $dob =htmlspecialchars($_POST["dob"]);
            $email =htmlspecialchars($_POST["email"]);
            if(empty($f_name)){
                $code = 400;
                $msg .= "<li>Enter First name</li>";
            }
            if(empty($l_name)){
                $code = 400;
                $msg .= "<li>Enter last name</li>";
            }
            if(empty($gender)){
                $code = 400;
                $msg .= "<li>Select gender</li>";
            } 
            if(empty($dob)){
                $code = 400;
                $msg .= "<li>Enter date of birth</li>";
            }          
            if(empty($msg)){
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                $stmt = $conn->prepare("SELECT id FROM customer WHERE phone = ?");        
                $stmt->bind_param('s', $_SESSION['phone']);
                $stmt->execute();
                $stmt->store_result();
                $stmt->bind_result($id);
                if($stmt->num_rows() == 1){
                    $stmt->fetch();
                    $customer_uid = date('Y').'SDVN'.date('m').'SAN'.(00000+$id);

                    $stmt3 = $conn->prepare("UPDATE customer SET customer_uid = ?, f_name = ?, m_name = ?, l_name = ?, gender = ?, dob = ?, email = ?  WHERE phone = ?"); 
                    $stmt3->bind_param('ssssssss', $customer_uid, $f_name, $m_name, $l_name, $gender, $dob, $email, $_SESSION['phone']);
                    $stmt3->execute();
                    $stmt3->close();

                    $_SESSION['customer_uid'] = $customer_uid;
                    $_SESSION['f_name'] = $f_name;
                    $code = 200;
                    $msg = "Success";
                }
                $stmt->close();
                $conn->close();
            }else{
                $code = 400;
            }
        }
    }
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>