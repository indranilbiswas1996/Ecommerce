<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
frontend_full_access_check();
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
    <?php include 'header.php';?>
    <div class="container">
        <?php include 'mobile_menu.php'; ?>  
        <div class="dashboard-details-container center">
            <div class="dashboard-details-inner-container">
                <div class="card-container">
                    <a href="superadminlist.php">
                        <span class="green"><span class="fa fa-user-plus"></span></span>
                        <span class="green">&nbsp;</span>
                        <span class="background-green">Superadmin</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="adminlist.php">
                        <span class="blue"><span class="fa fa-user"></span></span>
                        <span class="blue">&nbsp;</span>
                        <span class="background-blue">Admin</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="customerlist.php">
                        <span class="sky"><span class="fa fa-users"></span></span>
                        <span class="sky">&nbsp;</span>
                        <span class="background-sky">Customer</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="request.php">
                        <span class="violet"><span class="fa fa-handshake-o"></span></span>
                        <span class="violet">&nbsp;</span>
                        <span class="background-violet">Request</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="shoptype.php">
                        <span class="pink"><span class="fa fa-university"></span></span>
                        <span class="pink">&nbsp;</span>
                        <span class="background-pink">Shop type</span>
                    </a>
                </div>
                <!--
                <div class="card-container">
                    <a href="#">
                        <span class="sky"><span class="fa fa-cart-plus"></span></span>
                        <span class="sky">&nbsp;</span>
                        <span class="background-sky">New orders</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="violet"><span class="fa fa-gift"></span></span>
                        <span class="violet">&nbsp;</span>
                        <span class="background-violet">Packed</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="blue"><span class="fa fa-truck"></span></span>
                        <span class="blue">&nbsp;</span>
                        <span class="background-blue">Shipped</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="green"><span class="fa fa-dropbox"></span></span>
                        <span class="green">&nbsp;</span>
                        <span class="background-green">Delivered</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="pink"><span class="fa fa-undo"></span></span>
                        <span class="pink">&nbsp;</span>
                        <span class="background-pink">Returned</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="yellow"><span class="fa fa-exchange"></span></span>
                        <span class="yellow">&nbsp;</span>
                        <span class="background-yellow">Replacement</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="red"><span class="fa fa-close"></span></span>
                        <span class="red">&nbsp;</span>
                        <span class="background-red">Cancelled</span>
                    </a>
                </div>
                <div class="card-container">
                    <a href="#">
                        <span class="blue"><span class="fa fa-star"></span></span>
                        <span class="blue">&nbsp;</span>
                        <span class="background-blue">Rating</span>
                    </a>
                </div> -->
            </div>
        </div>
    </div>
</body>
</html>