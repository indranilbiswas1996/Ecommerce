<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
frontend_full_access_check();

//To keep the same option after reload
if(isset($_POST['admin_status'])){
    $admin_status = $_POST['admin_status'];
}else{
    $admin_status = 1;
}
$admin_type = 0;
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
    <?php include 'header.php';?>
    <div class="container">
        <?php include 'mobile_menu.php'; ?>
        <div class="dashboard-details-container">
        <div class="dashboard-details-inner-container-search-div">
            <form name="form-login" class="form-login" id="form-login" action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
                <div class="dashboard-details-inner-container-search-item">
                    <select id="admin_status" name="admin_status" class="login-selectbox">
                        <option value="1" <?php if($admin_status == '1'){echo("selected");}?>>Active</option>
                        <option value="-1" <?php if($admin_status == '-1'){echo("selected");}?>>Deleted</option>
                        <option value="0" <?php if($admin_status == '0'){echo("selected");}?>>Request</option>
                    </select>
                </div>
                <div class="dashboard-details-inner-container-search-item">
                    <input type="hidden" name="xcsrf" value="<?php echo $csrf_token;?>" id="xcsrf" />
                    <button type="submit" class="login-button" >Search</button>
                </div>
            </form>
        </div>
        <div class="offer-expand-div" id="request_expand_div">
        </div>
        <div class="alert alert-danger" id="productlist_err"></div>
                <?php
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                if(isset($_POST['xcsrf']) && isset($_POST['admin_status'])){
                    $admin_status = $_POST['admin_status'];
                    if($admin_status == "1"){
                        $one = 1;
                        $stmt = $conn->prepare("SELECT a.superadmin_uid, a.f_name, a.m_name, a.l_name, a.dob, a.gender, a.phone,  a.email, a.created_time, s.alternet_phone, s.alternet_email, s.pin, s.locality, s.address, c.city_name, ast.state_name, s.gst, gf.govt_proof_details, s.govt_proof_no, s.pan, s.created_date FROM superadmin a,  superadmin_details s, all_cities c, all_states ast, govt_proof gf WHERE a.superadmin_uid = s.superadmin_uid AND a.admin_status = ? and c.city_code = s.dist and ast.state_code = s.state and s.govt_proof = gf.id;");
                        $stmt->bind_param('s', $one);
                        $stmt->execute();
                        $stmt->store_result();
                        if($stmt->num_rows() != 0){                            
                            $stmt->bind_result($superadmin_uid, $f_name, $m_name, $l_name, $dob, $gender, $phone,  $email, $created_time, $alternet_phone, $alternet_email, $pin, $locality, $address, $dist_name, $state_name, $gst, $govt_proof_details, $govt_proof_no, $pan, $created_date);
                            while($stmt->fetch()){				
                                if($gender == 1){
                                    $gender = 'Male';
                                }elseif($gender == 2){
                                    $gender = 'Female';
                                }else{
                                    $gender = 'Other';
                                }
                                if($alternet_phone == 0){
                                    $alternet_phone = "";
                                }
                                echo '
                                    <div class="dashboard-details-inner-container">
                                    <div class="requestlist-item-container">
                                        <div class="requestlist-item">
                                            <span><strong>Name : </strong>'.$f_name.' '.$m_name.' '.$l_name.'</span>
                                            <span><strong>Phone : </strong>'.$phone.'</span>
                                            <span><strong>Reg date : </strong>'.$created_date.'</span>
                                            <span><strong>'.$govt_proof_details.' : </strong>'.$govt_proof_no.'</span>
                                        </div>
                                        <div class="requestlist-item-action">
                                            <span onclick="expand_request(\''.$admin_type.'\',\''.$superadmin_uid.'\',\''.$f_name.'\',\''.$m_name.'\',\''.$l_name.'\',\''.$dob.'\',\''.$gender.'\',\''.$phone.'\',\''.$email.'\',\''.$created_time.'\',\''.$alternet_phone.'\',\''.$alternet_email.'\',\''.$pin.'\',\''.$locality.'\',\''.$address.'\',\''.$dist_name.'\',\''.$state_name.'\',\''.$gst.'\',\''.$govt_proof_details.'\',\''.$govt_proof_no.'\',\''.$pan.'\',\''.$created_date.'\')"><i class="fa fa-expand blue"></i></span>
                                            <span onclick="reject_request(\''.$admin_type.'\',\''.$phone.'\')"><i class="fa fa-trash red"></i></span>
                                        </div>
                                    </div>
                                </div>
                                ';
                            }
                        }
                        $stmt->close();
                    }
                    if($admin_status == "0"){
                        $zero = 0;
                        $stmt = $conn->prepare("SELECT a.superadmin_uid, a.f_name, a.m_name, a.l_name, a.dob, a.gender, a.phone,  a.email, a.created_time, s.alternet_phone, s.alternet_email, s.pin, s.locality, s.address, c.city_name, ast.state_name, s.gst, gf.govt_proof_details, s.govt_proof_no, s.pan, s.created_date FROM superadmin a,  superadmin_details s, all_cities c, all_states ast, govt_proof gf WHERE a.superadmin_uid = s.superadmin_uid AND a.admin_status = ? and c.city_code = s.dist and ast.state_code = s.state and s.govt_proof = gf.id;");
                        $stmt->bind_param('s', $zero);
                        $stmt->execute();
                        $stmt->store_result();
                        if($stmt->num_rows() != 0){                            
                            $stmt->bind_result($superadmin_uid, $f_name, $m_name, $l_name, $dob, $gender, $phone,  $email, $created_time, $alternet_phone, $alternet_email, $pin, $locality, $address, $dist_name, $state_name, $gst, $govt_proof_details, $govt_proof_no, $pan, $created_date);
                            while($stmt->fetch()){				
                                if($gender == 1){
                                    $gender = 'Male';
                                }elseif($gender == 2){
                                    $gender = 'Female';
                                }else{
                                    $gender = 'Other';
                                }
                                if($alternet_phone == 0){
                                    $alternet_phone = "";
                                }
                                echo '
                                    <div class="dashboard-details-inner-container">
                                    <div class="requestlist-item-container">
                                        <div class="requestlist-item">
                                            <span><strong>Name : </strong>'.$f_name.' '.$m_name.' '.$l_name.'</span>
                                            <span><strong>Phone : </strong>'.$phone.'</span>
                                            <span><strong>Reg date : </strong>'.$created_date.'</span>
                                            <span><strong>'.$govt_proof_details.' : </strong>'.$govt_proof_no.'</span>
                                        </div>
                                        <div class="requestlist-item-action">
                                            <span onclick="expand_request(\''.$admin_type.'\',\''.$superadmin_uid.'\',\''.$f_name.'\',\''.$m_name.'\',\''.$l_name.'\',\''.$dob.'\',\''.$gender.'\',\''.$phone.'\',\''.$email.'\',\''.$created_time.'\',\''.$alternet_phone.'\',\''.$alternet_email.'\',\''.$pin.'\',\''.$locality.'\',\''.$address.'\',\''.$dist_name.'\',\''.$state_name.'\',\''.$gst.'\',\''.$govt_proof_details.'\',\''.$govt_proof_no.'\',\''.$pan.'\',\''.$created_date.'\')"><i class="fa fa-expand blue"></i></span>
                                            <span onclick="accept_request(\''.$admin_type.'\',\''.$phone.'\')"><i class="fa fa-check green"></i></span>
                                            <span onclick="reject_request(\''.$admin_type.'\',\''.$phone.'\')"><i class="fa fa-trash red"></i></span>
                                        </div>
                                    </div>
                                </div>
                                ';
                            }
                        }
                        $stmt->close();
                    }
                    if($admin_status == "-1"){
                        $minusone = -1;
                        $stmt = $conn->prepare("SELECT a.superadmin_uid, a.f_name, a.m_name, a.l_name, a.dob, a.gender, a.phone,  a.email, a.created_time, s.alternet_phone, s.alternet_email, s.pin, s.locality, s.address, c.city_name, ast.state_name, s.gst, gf.govt_proof_details, s.govt_proof_no, s.pan, s.created_date FROM superadmin a,  superadmin_details s, all_cities c, all_states ast, govt_proof gf WHERE a.superadmin_uid = s.superadmin_uid AND a.admin_status = ? and c.city_code = s.dist and ast.state_code = s.state and s.govt_proof = gf.id;");
                        $stmt->bind_param('s', $minusone);
                        $stmt->execute();
                        $stmt->store_result();
                        if($stmt->num_rows() != 0){                            
                            $stmt->bind_result($superadmin_uid, $f_name, $m_name, $l_name, $dob, $gender, $phone,  $email, $created_time, $alternet_phone, $alternet_email, $pin, $locality, $address, $dist_name, $state_name, $gst, $govt_proof_details, $govt_proof_no, $pan, $created_date);
                            while($stmt->fetch()){				
                                if($gender == 1){
                                    $gender = 'Male';
                                }elseif($gender == 2){
                                    $gender = 'Female';
                                }else{
                                    $gender = 'Other';
                                }
                                if($alternet_phone == 0){
                                    $alternet_phone = "";
                                }
                                echo '
                                    <div class="dashboard-details-inner-container">
                                    <div class="requestlist-item-container">
                                        <div class="requestlist-item">
                                            <span><strong>Name : </strong>'.$f_name.' '.$m_name.' '.$l_name.'</span>
                                            <span><strong>Phone : </strong>'.$phone.'</span>
                                            <span><strong>Reg date : </strong>'.$created_date.'</span>
                                            <span><strong>'.$govt_proof_details.' : </strong>'.$govt_proof_no.'</span>
                                        </div>
                                        <div class="requestlist-item-action">
                                            <span onclick="expand_request(\''.$admin_type.'\',\''.$superadmin_uid.'\',\''.$f_name.'\',\''.$m_name.'\',\''.$l_name.'\',\''.$dob.'\',\''.$gender.'\',\''.$phone.'\',\''.$email.'\',\''.$created_time.'\',\''.$alternet_phone.'\',\''.$alternet_email.'\',\''.$pin.'\',\''.$locality.'\',\''.$address.'\',\''.$dist_name.'\',\''.$state_name.'\',\''.$gst.'\',\''.$govt_proof_details.'\',\''.$govt_proof_no.'\',\''.$pan.'\',\''.$created_date.'\')"><i class="fa fa-expand blue"></i></span>
                                            <span onclick="accept_request(\''.$admin_type.'\',\''.$phone.'\')"><i class="fa fa-check green"></i></span>
                                        </div>
                                    </div>
                                </div>
                                ';
                            }
                        }
                        $stmt->close();
                    }
                }else{
                    $one = 1;
                    $stmt = $conn->prepare("SELECT a.superadmin_uid, a.f_name, a.m_name, a.l_name, a.dob, a.gender, a.phone,  a.email, a.created_time, s.alternet_phone, s.alternet_email, s.pin, s.locality, s.address, c.city_name, ast.state_name, s.gst, gf.govt_proof_details, s.govt_proof_no, s.pan, s.created_date FROM superadmin a,  superadmin_details s, all_cities c, all_states ast, govt_proof gf WHERE a.superadmin_uid = s.superadmin_uid AND a.admin_status = ? and c.city_code = s.dist and ast.state_code = s.state and s.govt_proof = gf.id;");
                    $stmt->bind_param('s', $one);
                    $stmt->execute();
                    $stmt->store_result();
                    if($stmt->num_rows() != 0){                            
                        $stmt->bind_result($superadmin_uid, $f_name, $m_name, $l_name, $dob, $gender, $phone,  $email, $created_time, $alternet_phone, $alternet_email, $pin, $locality, $address, $dist_name, $state_name, $gst, $govt_proof_details, $govt_proof_no, $pan, $created_date);
                        while($stmt->fetch()){				
                            if($gender == 1){
                                $gender = 'Male';
                            }elseif($gender == 2){
                                $gender = 'Female';
                            }else{
                                $gender = 'Other';
                            }
                            if($alternet_phone == 0){
                                $alternet_phone = "";
                            }
                            echo '
                                <div class="dashboard-details-inner-container">
                                <div class="requestlist-item-container">
                                    <div class="requestlist-item">
                                        <span><strong>Name : </strong>'.$f_name.' '.$m_name.' '.$l_name.'</span>
                                        <span><strong>Phone : </strong>'.$phone.'</span>
                                        <span><strong>Reg date : </strong>'.$created_date.'</span>
                                        <span><strong>'.$govt_proof_details.' : </strong>'.$govt_proof_no.'</span>
                                    </div>
                                    <div class="requestlist-item-action">
                                        <span onclick="expand_request(\''.$admin_type.'\',\''.$superadmin_uid.'\',\''.$f_name.'\',\''.$m_name.'\',\''.$l_name.'\',\''.$dob.'\',\''.$gender.'\',\''.$phone.'\',\''.$email.'\',\''.$created_time.'\',\''.$alternet_phone.'\',\''.$alternet_email.'\',\''.$pin.'\',\''.$locality.'\',\''.$address.'\',\''.$dist_name.'\',\''.$state_name.'\',\''.$gst.'\',\''.$govt_proof_details.'\',\''.$govt_proof_no.'\',\''.$pan.'\',\''.$created_date.'\')"><i class="fa fa-expand blue"></i></span>
                                        <span onclick="reject_request(\''.$admin_type.'\',\''.$phone.'\')"><i class="fa fa-trash red"></i></span>
                                    </div>
                                </div>
                            </div>
                            ';
                        }
                    }
                    $stmt->close();
                }
                $conn->close();
            ?>
    </div>
</body>
<script type="text/javascript">
function expand_request(admin_type,superadmin_uid,f_name,m_name,l_name,dob,gender,phone,email,created_time,alternet_phone,alternet_email,pin,locality,address,dist,state,gst,govt_proof,govt_proof_no,pan,created_date){
    var shop_detailsString = "";
    if(admin_type == 1){
        shop_detailsString = "<div><span>Shop name : </span><span>"+shop_name+"</span>	</div>	<div><span>Shop type : </span><span>"+shop_type+"</span>	</div>";
    }
    document.getElementById('request_expand_div').style.display = 'inline-block';
    var theString = "<div class=\ 'offer-expand-container\'><div class=\ 'offer-item background-green white\'>"+f_name+" "+m_name+" "+l_name+"	<div class=\ 'offer-item-action\'><span class=\ 'fa fa-close white\' onclick=\ 'offer_close()\'></span>	</div></div><div class=\ 'request-all-details-container\'>	<div><span>Superadmin id : </span><span>"+superadmin_uid+"</span>	</div> "+shop_detailsString+"	<div><span>Phone : </span><span>"+phone+"</span>	</div>	<div><span>Email : </span><span>"+email+"</span>	</div>	<div><span>Gender : </span><span>"+gender+"</span>	</div>	<div><span>Date of birth : </span><span>"+dob+"</span>	</div>	<div><span>Alternet phone : </span><span>"+alternet_phone+"</span>	</div>	<div><span>Alternet email : </span><span>"+alternet_email+"</span>	</div>	<div><span>Locality : </span><span>"+locality+"</span>	</div>	<div><span>Address : </span><span>"+address+"</span>	</div>	<div><span>District : </span><span>"+dist+"</span>	</div>	<div><span>State : </span><span>"+state+"</span>	</div>	<div><span>Pin code : </span><span>"+pin+"</span>	</div>	<div><span>"+govt_proof+"</span><span>"+govt_proof_no+"</span>	</div>	<div><span>PAN</span><span>"+pan+"</span>	</div>	<div><span>GSR</span><span>"+gst+"</span>	</div>	<div><span>User created time : </span><span>"+created_time+"</span>	</div>	<div><span>Submit date : </span><span>"+created_date+"</span>	</div></div></div>";
    var theParent=document.getElementById("request_expand_div");
    theParent.innerHTML=theString;
}
function offer_close(){
    document.getElementById('request_expand_div').style.display = 'none';
}
function accept_request(admin_type,phone){
    if(confirm("Are you sure to accept the request? Press ok to confirm.")){    
        var ajaxRequest, fd;
        try {
            ajaxRequest = new XMLHttpRequest();
        }catch (e) {
            try {
                ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
            }catch (e) {
                try{
                    ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                }catch (e){
                    alert("Your browser broke!");
                    return false;
                }
            }
        }
        ajaxRequest.onreadystatechange = function(){
            if(ajaxRequest.readyState == 4){
                var data = JSON.parse(ajaxRequest.responseText);
                if(data.code == "200"){
                    window.location.reload();
                }else{
                    $("#offer_err").html("<ul>"+data.msg+"</ul>");
                    $("#offer_err").css("display","block");
                }
            }
        }
        fd = new FormData();
        fd.append("admin_type", admin_type);
        fd.append("phone", phone);
        fd.append("xcsrf", "<?php echo $csrf_token;?>");          
        ajaxRequest.open("POST", "accept_request_background.php", true);
        ajaxRequest.send(fd);
    }
}
function reject_request(admin_type,phone){
    if(confirm("Are you sure to reject the request? Press ok to confirm.")){    
        var ajaxRequest, fd;
        try {
            ajaxRequest = new XMLHttpRequest();
        }catch (e) {
            try {
                ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
            }catch (e) {
                try{
                    ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                }catch (e){
                    alert("Your browser broke!");
                    return false;
                }
            }
        }
        ajaxRequest.onreadystatechange = function(){
            if(ajaxRequest.readyState == 4){
                var data = JSON.parse(ajaxRequest.responseText);
                if(data.code == "200"){
                    window.location.reload();
                }else{
                    $("#offer_err").html("<ul>"+data.msg+"</ul>");
                    $("#offer_err").css("display","block");
                }
            }
        }
        fd = new FormData();
        fd.append("admin_type", admin_type);
        fd.append("phone", phone);
        fd.append("xcsrf", "<?php echo $csrf_token;?>");          
        ajaxRequest.open("POST", "reject_request_background.php", true);
        ajaxRequest.send(fd);
    }
}
</script>
</html>