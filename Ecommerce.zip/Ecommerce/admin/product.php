<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
/*if(login_check() == false){
    header("Location: login.php");
}else{
    if($_SESSION['shop_uid'] == null || $_SESSION['shop_uid'] == ""){
        header("Location: shop.php");
    }
}*/
frontend_full_access_check();
if(isset($_GET['id'])){
    $product_id = $_GET['id'];
    //echo $product_id;
}

?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
    <?php include 'header.php';?>
    <?php
        $main_id = $main_basic_offer = $main_total_sold = 0;
        $main_product_details = $main_product_name = $main_original_price = $main_selling_price = $main_quantity = $main_delivery_charges = $main_delivery_time = $main_return_details = $main_warranty = null;
        $main_live_status = $main_product_main_id = $main_product_sub_id = $main_payment_details = $main_return_type = $main_status = -1;
        $main_publish_date = $main_close_date = "0000-00-00 00:00:00";
        include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
        $shop_uid = $_SESSION['shop_uid'];
        $stmt = $conn->prepare("SELECT `id`, `product_main_id`,`product_sub_id`, `product_details`, `product_name`, `payment_details`, `status`, `live_status`, `original_price`, `basic_offer`, `selling_price`, `delivery_charges`, `delivery_time`, `quantity`, `total_sold`, `warranty`, `replacement`, `replacement_details`, `return_type`, `return_details`, `publish_date`, `close_date`, `created_date` FROM `product` WHERE id = ? AND shop_uid = ?");        
        $stmt->bind_param('ss', $product_id, $shop_uid);
        $stmt->execute();
        $stmt->store_result();
        if($stmt->num_rows() != 0){                    
            $stmt->bind_result($main_id, $main_product_main_id, $main_product_sub_id, $main_product_details, $main_product_name, $main_payment_details, $main_status, $main_live_status, $main_original_price, $main_basic_offer, $main_selling_price, $main_delivery_charges, $main_delivery_time, $main_quantity, $main_total_sold, $main_warranty, $main_replacement, $main_replacement_details, $main_return_type, $main_return_details, $main_publish_date, $main_close_date, $main_created_date);               
            $stmt->fetch();
            //echo $main_product_main_id." + ".$main_product_sub_id." + ".$main_payment_details." + ".$main_return_type." + ".$main_status;
        }                
        $stmt->close();

    ?>
    <div class="container">
        <?php include 'mobile_menu.php'; ?>
        <div class="dashboard-details-container">
            <div class="dashboard-details-inner-container">
            <?php
                if($main_live_status == 0){
                    echo '<div class="alert alert-danger" style="display: block; background : #f2dede"><ul><li>Product deleted || Sold : '.$main_total_sold.'</li></ul></div>';
                }
                if($main_live_status == 1){
                    echo '<div class="alert alert-danger" style="display: block; background : #cfe5c1; color : #3e9806"><ul><li>In stock || Sold : '.$main_total_sold.'</li></ul></div>';
                }
                if($main_live_status == 2){
                    echo '<div class="alert alert-danger" style="display: block; background : #ffe8c5; color : #ff9800"><ul><li>Out of stock || Sold : '.$main_total_sold.'</li></ul></div>';
                }
            ?>

                <div class="alert alert-danger" id="main_err"></div>
                <input type="hidden" id="product_id_hidden" value="<?php echo $main_id ?>">
                <div class="product-img-container">
                    <div class="alert alert-danger" id="img_err"></div>
                    <div class="add-img-container">
                        <div id="add_img_tag" class="add-img-tag" onclick="load_pic()">
                            <i class="fa fa-cloud-upload"></i>
                            <i>Add picture</i>
                        </div>
                        <input type="file" id="load_pic" style="display:none" accept="image/x-png,image/gif,image/jpeg"/> 
                    </div>
                    <div id="load_img_container" class="load-img-container">
                        <!--
                        <div class="img-container" id="load_img_id0">
                            <img src="img/4.jpeg">
                            <span class="fa fa-close red" onclick="delete_load_pic(0)"></span>
                        </div>
                        -->
                        <?php
                            $stmt = $conn->prepare("SELECT `id`, `img` FROM `product_pics` WHERE  `product_id` = ? ORDER BY id ASC");
                            $stmt->bind_param('s', $main_id);
                            $stmt->execute();
                            $stmt->store_result();
                            if($stmt->num_rows() != 0){                    
                                $stmt->bind_result($img_id, $img);
                                while($stmt->fetch()){
                                    echo '<div class="img-container" id="load_img_id'.$img_id.'">
                                            <img src="img/'.$img.'">
                                            <span class="fa fa-close red" onclick="delete_pic('.$img_id.',\''.$img.'\')"></span>
                                        </div>';
                                }
                            }
                            $stmt->close();
                        ?>
                    </div>
                </div>
                <!-- -->
                <div class="product-details-container">
                    <div class="product-details-container-item">
                        <div class="product-details-item">
                            <div class="alert alert-danger" id="product_err">
                            </div>
                            <div class="product-details-item-inner">
                                <label class="login-label">Product name<span class="red">*</span></label>
                                <input type="text" name="product_name" id="product_name" class="login-textbox" value="<?php echo $main_product_name ?>" placeholder="Enter product name">
                            </div>
                            <div class="product-details-item-inner">
                                <label class="login-label">Main category<span class="red">*</span></label>
                                <select id="main_category_select" name="main_category_select" class="login-selectbox">
                                    <option value="-1">Select main category</option>
                                    <?php
                                        $one = 1;
                                        $stmt = $conn->prepare("SELECT id, details FROM product_main_category WHERE shop_uid = ? AND status = ? ORDER BY details ASC");
                                        $stmt->bind_param('ss', $_SESSION['shop_uid'], $one);
                                        $stmt->execute();
                                        $stmt->store_result();
                                        if($stmt->num_rows() != 0){                    
                                            $stmt->bind_result($id, $details);
                                            while($stmt->fetch()){
                                                echo '<option value="'.$id.'">'.$details.'</option>';
                                            }
                                        }
                                        $stmt->close();
                                    ?>                            
                                </select>
                            </div>
                            <div class="product-details-item-inner">
                                <label class="login-label">Sub category<span class="red">*</span></label>
                                <select id="sub_category_select" name="sub_category_select" class="login-selectbox">
                                    <option value="-1">Select sub category</option>
                                    <?php 
                                        if($main_id > 0){
                                            $one = 1;
                                            $stmt = $conn->prepare("SELECT id, details FROM `product_sub_category` WHERE product_main_id = ? AND status = ?");        
                                            $stmt->bind_param('ss', $main_product_main_id, $one);
                                            $stmt->execute();
                                            $stmt->store_result();
                                            if($stmt->num_rows() != 0){                    
                                                $stmt->bind_result($id, $details);
                                                while($stmt->fetch()){
                                                    echo '<option value="'.$id.'">'.$details.'</option>';
                                                }
                                            }
                                            $stmt->close();
                                        }
                                    ?>
                                </select>
                            </div>
                            <div class="product-details-item-inner">
                                <label class="login-label">Product details<span class="red">*</span></label>
                                <input type="text" name="product_details" id="product_details" class="login-textbox" value="<?php echo $main_product_details ?>" placeholder="Enter product details">
                            </div>
                        </div>
                    </div>
                    <div class="product-details-container-item">
                        <div class="product-details-item">
                            <div class="alert alert-danger" id="price_err">
                            </div>
                            <div class="product-details-item-inner">
                                <label class="login-label">Original price<span class="red">*</span></label>
                                <input type="number" name="original_price" id="original_price" class="login-textbox" value="<?php echo $main_original_price ?>" onchange="priceCalOP()" placeholder="Enter original price">
                            </div>
                            <div class="product-details-item-inner">
                                <label class="login-label">Basic offer percentage<span class="red">*</span></label>
                                <input type="number" name="basic_offer" id="basic_offer" class="login-textbox" value="<?php echo $main_basic_offer ?>" onchange="priceCalBO()" placeholder="Enter offer percentage" value = "0">
                            </div>
                            <div class="product-details-item-inner">
                                <label class="login-label">Selling price<span class="red">*</span></label>
                                <input type="number" name="selling_price" id="selling_price" class="login-textbox" value="<?php echo $main_selling_price ?>" onchange="priceCalSP()" placeholder="Enter selling price">
                            </div>
                            <div class="product-details-item-inner">
                                <label class="login-label">Payment option<span class="red">*</span></label>
                                <select id="payment_details" name="payment_details" class="login-selectbox">
                                    <option value="-1" <?php if($main_payment_details == "-1") echo "selected"; ?>>Select payment details</option>
                                    <option value="0" <?php if($main_payment_details == "0") echo "selected"; ?>>Cash on delivery</option>
                                    <option value="1" <?php if($main_payment_details == "1") echo "selected"; ?>>Online</option>
                                    <option value="2" <?php if($main_payment_details == "2") echo "selected"; ?>>Cash on delivery/Online</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="product-details-container-item">
                        <div class="product-details-item">
                            <div class="alert alert-danger" id="main_info_err">
                            </div>
                            <?php 
                            if($main_id > 0){
                                echo '
                                <div class="product-details-item-inner">
                                    <label class="login-label">Available quantity</label>
                                    <input type="number" name="available_quantity" id="available_quantity" class="login-textbox" disabled value="'.$main_quantity.'" placeholder="Enter product quantity">
                                </div>';
                            }
                            ?>
                            <div class="product-details-item-inner">
                                <label class="login-label">Add quantity<span class="red">*</span></label>
                                <input type="number" name="quantity" id="quantity" class="login-textbox" value="" placeholder="Enter product quantity">
                            </div>
                            <div class="product-details-item-inner">
                                <label class="login-label">Publish status<span class="red">*</span></label>
                                <select id="publish_status" name="publish_status" class="login-selectbox" onchange="publish_status_change()">
                                    <option value="-1" <?php if($main_status == "-1") echo "selected"; ?>>Select publish status</option>
                                    <option value="1" <?php if($main_status == "1") echo "selected"; ?>>Active</option>
                                    <option value="0" <?php if($main_status == "0") echo "selected"; ?>>Inactive</option>
                                    <option value="2" <?php if($main_status == "2") echo "selected"; ?>>Set publish date</option>
                                    <option value="3" <?php if($main_status == "3") echo "selected"; ?>>Set end date</option>
                                    <option value="4" <?php if($main_status == "4") echo "selected"; ?>>Set publish & end date</option>
                                </select>
                            </div>
                            <div class="product-details-item-inner">
                                <label class="login-label">Publish date</label>
                                <input type="datetime-local" name="publish_date" id="publish_date" class="login-textbox" value="<?php echo date('Y-m-d\TH:i', strtotime($main_publish_date)) ?>" placeholder="Enter publish date">
                            </div>
                            <div class="product-details-item-inner">
                                <label class="login-label">Close date</label>
                                <input type="datetime-local" name="close_date" id="close_date" class="login-textbox" value="<?php echo date('Y-m-d\TH:i', strtotime($main_close_date)) ?>" placeholder="Enter close date">
                            </div>
                        </div>
                    </div>
                    <div class="product-details-container-item">
                        <div class="product-details-item">
                            <div class="alert alert-danger" id="delivery_err">
                            </div>
                            <div class="product-details-item-inner">
                                <label class="login-label">Delivery charges<span class="red">*</span></label>
                                <input type="number" name="delivery_charges" id="delivery_charges" class="login-textbox" value="<?php echo $main_delivery_charges ?>" placeholder="Enter delivery charges">
                            </div>
                            <div class="product-details-item-inner">
                                <label class="login-label">Delivery time<span class="red">*</span></label>
                                <input type="number" name="delivery_time" id="delivery_time" class="login-textbox" value="<?php echo $main_delivery_time ?>" placeholder="Enter delivery days">
                            </div>
                            <div class="product-details-item-inner">
                                <label class="login-label">Return/Replacement<span class="red">*</span></label>
                                <select id="return_type" name="return_type" class="login-selectbox" onchange="return_type_change()">
                                    <option value="-1" <?php if($main_return_type == "-1") echo "selected"; ?>>Select Return/Replacement type</option>
                                    <option value="0" <?php if($main_return_type == "0") echo "selected"; ?>>No Returns Applicable</option>
                                    <option value="1" <?php if($main_return_type == "1") echo "selected"; ?>>Return</option>
                                    <option value="2" <?php if($main_return_type == "2") echo "selected"; ?>>Replacement</option>
                                    <option value="3" <?php if($main_return_type == "3") echo "selected"; ?>>Return/Replacement</option>
                                </select>
                            </div>
                            <div class="product-details-item-inner">
                                <label class="login-label">Return/Replacement details</label>
                                <input type="text" name="return_details" id="return_details" class="login-textbox" value="<?php echo $main_return_details ?>" placeholder="Enter return details">
                            </div><div class="product-details-item-inner">
                                <label class="login-label">Warranty</label>
                                <input type="text" name="warranty" id="warranty" class="login-textbox" value="<?php echo $main_warranty ?>" placeholder="Enter warranty details">
                            </div>
                        </div>
                    </div>                    
                    <div class="product-details-container-item">
                        <div class="product-details-item">
                            <div class="alert alert-danger" id="product_details_err">
                            </div>
                            <div class="dynamic-product-details-item-inner">
                                <div class="dynamic-product-details-item-inner-div">
                                    <label class="dynamic-product-details-item-inner-label">Details type</label>
                                </div>
                                <div class="dynamic-product-details-item-inner-div">
                                    <label class="dynamic-product-details-item-inner-label">Product details</label>
                                </div>
                            </div>
                            <div id="product_details_inner">
                                <!--<div class="dynamic-product-details-item-inner" id="product_details_div1">
                                    <div class="dynamic-product-details-item-inner-div">
                                        <input type="text" name="details_type1" id="details_type1" class="login-textbox" placeholder="Enter product details type">
                                    </div>
                                    <div class="dynamic-product-details-item-inner-div">
                                        <input type="text" name="product_details1" id="product_details1" class="login-textbox" placeholder="Enter product details">
                                    </div>
                                    <div class="dynamic-product-details-item-inner-action-div">
                                        <button class="login-button background-green" onclick="add_product_details()">Add</button>
                                    </div>
                                </div>-->
                                <?php
                                $stmt = $conn->prepare("SELECT `id`, `details_type`, `details` FROM `product_details` WHERE  `product_id` = ? ORDER BY id ASC");
                                $stmt->bind_param('s', $main_id);
                                $stmt->execute();
                                $stmt->store_result();
                                if($stmt->num_rows() != 0){                    
                                    $stmt->bind_result($details_id, $details_type, $details);
                                    $counter = 0;
                                    while($stmt->fetch()){
                                        if($counter == 0){
                                            echo '<div class="dynamic-product-details-item-inner" id="product_details_div'.$details_id.'">
                                                    <div class="dynamic-product-details-item-inner-div">
                                                        <input type="text" name="details_type1" id="details_type'.$details_id.'" class="login-textbox" placeholder="Enter product details type" value="'.$details_type.'">
                                                    </div>
                                                    <div class="dynamic-product-details-item-inner-div">
                                                        <input type="text" name="product_details1" id="product_details'.$details_id.'" class="login-textbox" placeholder="Enter product details" value="'.$details.'">
                                                    </div>
                                                    <div class="dynamic-product-details-item-inner-action-div">
                                                        <button class="login-button background-green" onclick="add_product_details()">Add</button>
                                                    </div>
                                                </div>';
                                        }else{
                                            echo '<div class="dynamic-product-details-item-inner" id="product_details_div'.$details_id.'">
                                                <div class="dynamic-product-details-item-inner-div">
                                                    <input type="text" name="details_type'.$details_id.'" id="details_type'.$details_id.'" class="login-textbox" placeholder="Enter product details type" value="'.$details_type.'">
                                                </div>
                                                <div class="dynamic-product-details-item-inner-div">
                                                    <input type="text" name="product_details'.$details_id.'" id="product_details'.$details_id.'" class="login-textbox" placeholder="Enter product details" value="'.$details.'">
                                                </div>
                                                <div class="dynamic-product-details-item-inner-action-div">
                                                    <button class="login-button" onclick="remove_product_details(\'product_details_div'.$details_id.'\')">Remove</button>
                                                </div>
                                            </div>';
                                        }
                                        $counter++;
                                    }
                                }else{
                                    echo '<div class="dynamic-product-details-item-inner" id="product_details_div0">
                                        <div class="dynamic-product-details-item-inner-div">
                                            <input type="text" name="details_type0" id="details_type0" class="login-textbox" placeholder="Enter product details type">
                                        </div>
                                        <div class="dynamic-product-details-item-inner-div">
                                            <input type="text" name="product_details0" id="product_details0" class="login-textbox" placeholder="Enter product details">
                                        </div>
                                        <div class="dynamic-product-details-item-inner-action-div">
                                            <button class="login-button background-green" onclick="add_product_details()">Add</button>
                                        </div>
                                    </div>';
                                }
                                $stmt->close();
                                ?>
                            </div>
                        </div>
                    </div>
                    <div class="product-details-container-item">
                        <div class="product-details-item">
                            <div class="alert alert-danger" id="offer_err">
                            </div>
                            <div class="offer-expand-div" id="offer_expand_div">
                            </div>
                            <div class="product-details-offer-inner">
                                <label class="product-details-offer-inner-label">Offer list</label>
                                <div class="product-details-offer-inner-div" id="offer_list">
                                <?php
                                    $one = 1;
                                    $stmt = $conn->prepare("SELECT id, offer_details, offer_percentage, max_offer, min_order, start_date, end_date, offer_type FROM offer WHERE shop_uid = ?  and offer_status = ? AND id NOT IN (SELECT `offer_id` FROM `product_offer` WHERE `product_id` = ?) ORDER BY offer_details ASC");
                                    $stmt->bind_param('sss', $_SESSION['shop_uid'], $one, $main_id);
                                    $stmt->execute();
                                    $stmt->store_result();
                                    if($stmt->num_rows() != 0){                    
                                        $stmt->bind_result($id, $offer_details, $offer_percentage, $max_offer, $min_order, $start_date, $end_date, $offer_type);
                                        while($stmt->fetch()){
                                            date_default_timezone_set('Asia/Kolkata');
                                            $current_time = date('Y-m-d H:i:s');
                                            if($start_date < $current_time && $end_date > $current_time){
                                                echo '<div class="product-details-offer-inner-div-item" id="offer_'.$id.'">
                                                        <span>'.$offer_details.'</span>                                         
                                                        <span class="fa fa-expand blue" onclick="expand_offer(\'offer_'.$id.'\',\''.$offer_details.'\',\''.$offer_percentage.'\',\''.$max_offer.'\',\''.$min_order.'\',\''.$start_date.'\',\''.$end_date.'\',\''.$offer_type.'\')"></span>
                                                        <span class="fa fa-plus green" onclick="add_offer(\'offer_'.$id.'\',\''.$offer_details.'\',\''.$offer_percentage.'\',\''.$max_offer.'\',\''.$min_order.'\',\''.$start_date.'\',\''.$end_date.'\',\''.$offer_type.'\')"></span>
                                                    </div>';
                                            }
                                        }
                                    }
                                    $stmt->close();
                                ?>                       
                                </div>
                            </div>
                            <div class="product-details-offer-inner">
                                <label class="product-details-offer-inner-label">Added offer</label>
                                <div class="product-details-offer-inner-div" id="added_offer">      
                                <?php
                                    $one =1;
                                    $stmt = $conn->prepare("SELECT id, offer_details, offer_percentage, max_offer, min_order, start_date, end_date, offer_type FROM offer WHERE shop_uid = ? AND offer_status = ? AND id IN (SELECT `offer_id` FROM `product_offer` WHERE `product_id` = ?) ORDER BY offer_details ASC");
                                    $stmt->bind_param('sss', $_SESSION['shop_uid'], $one, $main_id);
                                    $stmt->execute();
                                    $stmt->store_result();
                                    if($stmt->num_rows() != 0){                    
                                        $stmt->bind_result($id, $offer_details, $offer_percentage, $max_offer, $min_order, $start_date, $end_date, $offer_type);
                                        while($stmt->fetch()){	
                                            date_default_timezone_set('Asia/Kolkata');
                                            $current_time = date('Y-m-d H:i:s');
                                            if($start_date < $current_time && $end_date > $current_time){
                                                echo '<div class="product-details-offer-inner-div-item" id="offer_'.$id.'">
                                                    <span>'.$offer_details.'</span>                                         
                                                    <span class="fa fa-expand blue" onclick="expand_offer(\'offer_'.$id.'\',\''.$offer_details.'\',\''.$offer_percentage.'\',\''.$max_offer.'\',\''.$min_order.'\',\''.$start_date.'\',\''.$end_date.'\',\''.$offer_type.'\')"></span>
                                                    <span class="fa fa-trash red" onclick="remove_offer(\'offer_'.$id.'\',\''.$offer_details.'\',\''.$offer_percentage.'\',\''.$max_offer.'\',\''.$min_order.'\',\''.$start_date.'\',\''.$end_date.'\',\''.$offer_type.'\')"></span>
                                                </div>';
                                            }
                                        }
                                    }
                                    $stmt->close();
                                    $conn->close();
                                ?>                           
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Button action -->
                <div class="product-save-action-container">
                    <?php 
                        if($main_live_status == 0){
                            echo '<div class="product-save-action-div">
                                    <button type="submit" class="login-button" onclick="restore(\''.$main_id.'\')">Restore</button>
                                </div>';
                        }else if($main_live_status > 0){
                            echo '<div class="product-save-action-div">
                                    <button type="submit" class="login-button background-green" onclick="save()">Save</button>
                                </div>
                                <div class="product-save-action-div">
                                    <button type="submit" class="login-button background-red" onclick="delete_product(\''.$main_id.'\')">Delete</button>
                                </div>';
                        }else{
                            echo '<div class="product-save-action-div">
                                    <button type="submit" class="login-button background-green" onclick="save()">Save</button>
                                </div>
                                <div class="product-save-action-div">
                                    <button type="submit" class="login-button" onclick="reset()">Reset</button>
                                </div>';
                        }
                    ?>
                </div>
            </div>
        </div>
    </div>
</body>
<script type="text/javascript">
    <?php if($main_status == "2" || $main_status == "4"){ ?>                                       
        document.getElementById("publish_date").disabled = false; 
        /*var publish_date = "<?php echo ''.$main_publish_date.'' ?>";
        document.getElementById("publish_date").value = publish_date;*/
    <?php }else{ ?>
        document.getElementById("publish_date").disabled = true; 
    <?php } ?>
    <?php if($main_status == "3" || $main_status == "4"){ ?>                                       
        document.getElementById("close_date").disabled = false;     
        /*var close_date = "<?php echo $main_close_date ?>";
        document.getElementById("close_date").value = "<?php echo $main_close_date ?>";*/
    <?php }else{ ?>
        document.getElementById("close_date").disabled = true;
    <?php } ?>
    
    <?php if($main_return_type > 0){ ?>                                       
        document.getElementById("return_details").disabled = false; 
    <?php }else{ ?>
        document.getElementById("return_details").disabled = true; 
    <?php } ?>

    <?php if($main_product_main_id > -1) {?>
        document.getElementById('main_category_select').value=<?php echo $main_product_main_id ?>;
    <?php } ?>

    <?php if($main_product_sub_id > -1) {?>
        document.getElementById('sub_category_select').value=<?php echo $main_product_sub_id ?>;
    <?php } ?>

    function load_pic(){
        document.getElementById("load_pic").click();
    }
    function showImage(src) {        
        var fr=new FileReader();
        // when image is loaded, set the src of the image where you want to display it
        fr.onload = function(e) { 
            if(src.files[0].size < 300000){
                var load_img_id = new Date().getTime()
                var newdiv = document.createElement('div');
                newdiv.classList.add("img-container");
                newdiv.id = "load_img_id"+load_img_id;
                var newimg = document.createElement('img');
                newimg.src = this.result;
                var newspan = document.createElement('span');
                newspan.classList.add('fa', 'fa-close', 'red');
                newspan.setAttribute("onclick", "delete_load_pic("+load_img_id+")");
                newdiv.appendChild(newimg);
                newdiv.appendChild(newspan);
                document.getElementById('load_img_container').appendChild(newdiv);
                load_img_list.push(src.files[0]);
                load_img_id++;
            }else{
                alert("Product image should be less than 300KB");
            }
        };
        src.addEventListener("change",function() {
            // fill fr with image data    
            if(src.files.length > 0){
                fr.readAsDataURL(src.files[0]);
            }
        });        
    }
    var src = document.getElementById("load_pic");
    let load_img_id = 0;
    let load_img_list = [];
    showImage(src);

    function delete_load_pic(id){
        if(confirm("Are you sure to delete the product picture ? Press ok to confirm.")){  
            delete load_img_list[id];
           document.getElementById("load_img_id"+id).remove();
        }
    }
    function delete_pic(id, img){
        if(confirm("Are you sure to delete the product picture ? Press ok to confirm.")){  
            document.getElementById("load_img_id"+id).remove();
            var ajaxRequest, fd;
            try {
                ajaxRequest = new XMLHttpRequest();
            }catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                }catch (e) {
                    try{
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    }catch (e){
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }
            ajaxRequest.onreadystatechange = function(){
                if(ajaxRequest.readyState == 4){
                    var data = JSON.parse(ajaxRequest.responseText);
                    if(data.code == "200"){
                        //window.location = "offer.php";
                        window.location.reload();
                    }else{
                        $("#offer_err").html("<ul>"+data.msg+"</ul>");
                        $("#offer_err").css("display","block");
                    }
                }
            }
            fd = new FormData();
            fd.append("img_id", id);
            fd.append("img", img);
            fd.append("xcsrf", "<?php echo $csrf_token;?>");          
            ajaxRequest.open("POST", "delete_pic_background.php", true);
            ajaxRequest.send(fd);
        }
    }
    function save(){        
        $("#main_err").css("display","none");
        $("#img_err").css("display","none");
        $("#product_err").css("display","none");
        $("#price_err").css("display","none");
        $("#main_info_err").css("display","none");
        $("#delivery_err").css("display","none");
        $("#product_details_err").css("display","none");
        $("#offer_err").css("display","none");
        try{
            $('input').removeClass('outline-red');
            $('select').removeClass('outline-red');
        }catch(e){}
        var product_id_hidden = document.getElementById("product_id_hidden").value;
        var err = "";
        var product_err = 0;
        var img_flag = 0;
        /*Image caloculation for new product start*/
        var load_img_final_list = [];
        if(product_id_hidden == "0"){
            var j = 0;
            for(var i = 0; i<load_img_list.length; i++){
                if(load_img_list[i] != null){
                    load_img_final_list[j] = load_img_list[i];
                    j++;
                }
            }
            if(load_img_final_list.length < 1){
                err +=  '<li>Select product image</li>';
                document.getElementById("add_img_tag").classList.add("outline-red");
                img_flag = 1;
            }
        }else{
            if(load_img_list.length > 0){
                var j = 0;
                for(var i = 0; i<load_img_list.length; i++){
                    if(load_img_list[i] != null){
                        load_img_final_list[j] = load_img_list[i];
                        j++;
                    }
                }
            }else if(document.getElementById("load_img_container").children.length > 0){
                
            }else{
                err +=  '<li>Select product image</li>';
                document.getElementById("add_img_tag").classList.add("outline-red");
                img_flag = 1;
            }
        }
        
        if(img_flag == 1){
            $("#img_err").html("<ul>"+err+"</ul>");
            $("#img_err").css("display","block");
        }
        /*Image caloculation for new product end*/
        var product_name = document.getElementById("product_name").value;
        var main_category_select = document.getElementById("main_category_select").value;
        var sub_category_select = document.getElementById("sub_category_select").value;
        var product_details = document.getElementById("product_details").value;
        var number_reg = /^[+-]?\d+(\.\d+)?$/;
        err = "";
        if(product_name == ""){
            product_err = 1;
            err +=  '<li>Enter product name</li>';
            document.getElementById("product_name").classList.add("outline-red");
        }
        if(main_category_select < 0){
            product_err = 1;
            err +=  '<li>Select product main category</li>';
            document.getElementById("main_category_select").classList.add("outline-red");
        }
        if(sub_category_select < 0){
            product_err = 1;
            err +=  '<li>Select sub main category</li>';
            document.getElementById("sub_category_select").classList.add("outline-red");
        }
        if(product_details == ""){
            product_err = 1;
            err +=  '<li>Enter product details</li>';
            document.getElementById("product_details").classList.add("outline-red");
        }
        if(product_err == 1){
            $("#product_err").html("<ul>"+err+"</ul>");
            $("#product_err").css("display","block");
        }
        var original_price = document.getElementById("original_price").value;
        var basic_offer = document.getElementById("basic_offer").value;
        var selling_price = document.getElementById("selling_price").value;
        var payment_details = document.getElementById("payment_details").value;
        var price_err = 0;
        err = "";
        if(number_reg.test(original_price) == false){
            price_err = 1;
            err +=  '<li>Enter original price</li>';
            document.getElementById("original_price").classList.add("outline-red");
        }else{
            if(original_price < 0){
                price_err = 1;
                err +=  '<li>Original price should be greater than 0</li>';
                document.getElementById("original_price").classList.add("outline-red");
            }
        }
        if(number_reg.test(basic_offer) == false){
            err +=  '<li>Enter offer percentage</li>';
            price_err = 1;
            document.getElementById("basic_offer").classList.add("outline-red");
        }else{
            var z0to100 = /^(100(\.0{1,2})?|[1-9]?\d(\.\d{1,2})?)$/
            if(z0to100.test(basic_offer) == false){
                err +=  '<li>Offer percentage should be 0 to 100</li>';
                price_err = 1;
                document.getElementById("basic_offer").classList.add("outline-red");
            }
        }
        if(number_reg.test(selling_price) == false){
            price_err = 1;
            err +=  '<li>Enter selling price</li>';
            document.getElementById("selling_price").classList.add("outline-red");
        }else{
            if(selling_price < 0){
                price_err = 1;
                err +=  '<li>Selling price should be greater than 0</li>';
                document.getElementById("selling_price").classList.add("outline-red");
            }
        }
        if(payment_details < 0){
            price_err = 1;
            err +=  '<li>Select payment details</li>';
            document.getElementById("payment_details").classList.add("outline-red");
        }
        if(price_err == 1){
            $("#price_err").html("<ul>"+err+"</ul>");
            $("#price_err").css("display","block");
        }
        var quantity = document.getElementById("quantity").value;
        var publish_status = document.getElementById("publish_status").value;
        var publish_date = document.getElementById("publish_date").value;
        var close_date = document.getElementById("close_date").value;
        var main_info_err = 0;
        err = "";
        if(number_reg.test(quantity) == false){
            main_info_err = 1;
            err +=  '<li>Enter quantity</li>';
            document.getElementById("quantity").classList.add("outline-red");
        }else{
            <?php if($main_id == 0) {?>
                //Check for new product
                //If the product already exist, can upload negative value to Set OUT OF STOCK
                if(quantity < 0){
                    main_info_err = 1;
                    err +=  '<li>Enter valid quantity</li>';
                    document.getElementById("quantity").classList.add("outline-red");
                }
            <?php } ?>
        }
        <?php if($main_id > 0) {?>
        var available_quantity = document.getElementById("available_quantity").value;
        if(number_reg.test(available_quantity) == false){
            main_info_err = 1;
            err +=  '<li>Error on available quantity</li>';
            document.getElementById("available_quantity").classList.add("outline-red");
        }
        <?php }?>
        if(publish_status < 0){
            main_info_err = 1;
            err +=  '<li>Select publish status</li>';
            document.getElementById("publish_status").classList.add("outline-red");
        }     
        if(publish_status == 2 || publish_status == 4){
            if(publish_date == ""){
                main_info_err = 1;
                err +=  '<li>Enter publish date</li>';
                document.getElementById("publish_date").classList.add("outline-red");
            }
        }
        if(publish_status == 3 || publish_status == 4){
            if(close_date == ""){
                main_info_err = 1;
                err +=  '<li>Enter close date</li>';
                document.getElementById("close_date").classList.add("outline-red");
            }
        }
        if(publish_status == 4){
            if(publish_date != "" && close_date != ""){
                if(publish_date > close_date ){
                    main_info_err = 1;
                    err +=  '<li>Close date should be greater than end date</li>';
                    document.getElementById("close_date").classList.add("outline-red");
                }
            }
        }
        if(main_info_err == 1){
            $("#main_info_err").html("<ul>"+err+"</ul>");
            $("#main_info_err").css("display","block");
        }
        var delivery_charges = document.getElementById("delivery_charges").value;
        var delivery_time = document.getElementById("delivery_time").value;
        var warranty = document.getElementById("warranty").value;
        var return_type = document.getElementById("return_type").value;
        var return_details = document.getElementById("return_details").value;
        err = "";
        var delivery_err = 0;
        if(number_reg.test(delivery_charges) == false){
            delivery_err = 1;
            err +=  '<li>Enter delivery charges</li>';
            document.getElementById("delivery_charges").classList.add("outline-red");
        }else{
            if(delivery_charges < 0){
                delivery_err = 1;
                err +=  '<li>Enter valid delivery charges</li>';
                document.getElementById("delivery_charges").classList.add("outline-red");
            }
        }
        if(number_reg.test(delivery_time) == false){
            delivery_err = 1;
            err +=  '<li>Enter delivery time</li>';
            document.getElementById("delivery_time").classList.add("outline-red");
        }else{
            if(delivery_time < 0){
                delivery_err = 1;
                err +=  '<li>Enter valid delivery time</li>';
                document.getElementById("delivery_time").classList.add("outline-red");
            }
        }
        if(return_type == -1){
            delivery_err = 1;
            err +=  '<li>Select Return/Replacement type</li>';
            document.getElementById("return_type").classList.add("outline-red");
        }else{
            if(return_type > 0){
                if(return_details == ""){
                    delivery_err = 1;
                    err +=  '<li>Enter Return/Replacement details</li>';
                    document.getElementById("return_details").classList.add("outline-red");
                }
            }
        }
        if(delivery_err == 1){
            $("#delivery_err").html("<ul>"+err+"</ul>");
            $("#delivery_err").css("display","block");
        }
        err = "";
        var product_details_err = 0;
        product_detailsjsonObj = [];
        var product_details_inner_children = document.getElementById("product_details_inner").children; 
        for (var i = 0, len = product_details_inner_children.length ; i < len; i++) {
            //alert(product_details_inner_children[i].id);
            var product_details_div_children = document.getElementById(product_details_inner_children[i].id).getElementsByTagName("input"); 
            if(document.getElementById(product_details_div_children[0].id).value == ""){
                product_details_err = 1;
                err +=  '<li>Enter details type</li>';
                document.getElementById(product_details_div_children[0].id).classList.add("outline-red");
            }else{
                if(document.getElementById(product_details_div_children[0].id).value.length > 100){
                    product_details_err = 1;
                    err +=  '<li>Details type maximum length 100</li>';
                    document.getElementById(product_details_div_children[0].id).classList.add("outline-red");
                }
            }
            if(document.getElementById(product_details_div_children[1].id).value == ""){
                product_details_err = 1;
                err +=  '<li>Enter product details</li>';
                document.getElementById(product_details_div_children[1].id).classList.add("outline-red");
            }else{
                if(document.getElementById(product_details_div_children[1].id).value.length > 255){
                    product_details_err = 1;
                    err +=  '<li>Product details maximum length 255</li>';
                    document.getElementById(product_details_div_children[1].id).classList.add("outline-red");
                }
            }
            if(product_details_err == 0){
                item = {}
                item ["type"] = document.getElementById(product_details_div_children[0].id).value;
                item ["details"] = document.getElementById(product_details_div_children[1].id).value;
                product_detailsjsonObj.push(item);
            }
        }    
        if(product_details_err == 1){
            $("#product_details_err").html("<ul>"+err+"</ul>");
            $("#product_details_err").css("display","block");
        }
        //console.log(product_detailsjsonObj);
        err = "";
        var offer_err = 0;        
        var offer_ids = [];
        var added_offer_children = document.getElementById("added_offer").children; 
        for (var i = 0, len = added_offer_children.length ; i < len; i++) {
            offer_ids.push(added_offer_children[i].id.replace("offer_", ""));
        }        
        if(offer_err == 1){
            $("#offer_err").html("<ul>"+err+"</ul>");
            $("#offer_err").css("display","block");
        }
        if(img_flag == 0 && product_err == 0 && price_err == 0 && main_info_err == 0 && delivery_err == 0 && product_details_err == 0 && offer_err == 0){
            /* Ajax */
            var ajaxRequest, fd;
            try {
                ajaxRequest = new XMLHttpRequest();
            }catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                }catch (e) {
                    try{
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    }catch (e){
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }
            ajaxRequest.onreadystatechange = function(){
                if(ajaxRequest.readyState == 4){
                    var data = JSON.parse(ajaxRequest.responseText);
                    if(data.code == "200"){
                        window.location = "product.php?id="+data.msg;

                    }else{
                        $("#main_err").html("<ul>"+data.msg+"</ul>");
                        $("#main_err").css("display","block");
                    }
                }
            }
            fd = new FormData();
            for(var i = 0; i<load_img_final_list.length ; i++){
                fd.append("img"+i+"", load_img_final_list[i]);
            }
            fd.append("load_img_final_list_length", load_img_final_list.length);
            fd.append("product_id_hidden", product_id_hidden);
            fd.append("product_name", product_name);
            fd.append("main_category_select", main_category_select);
            fd.append("sub_category_select", sub_category_select);
            fd.append("product_details", product_details);
            fd.append("original_price", original_price);
            fd.append("basic_offer", basic_offer);
            fd.append("selling_price", selling_price);
            fd.append("payment_details", payment_details);
            <?php if($main_id > 0) {?>
                fd.append("available_quantity", available_quantity);
            <?php } ?>
            fd.append("quantity", quantity);
            fd.append("publish_status", publish_status);
            fd.append("publish_date", publish_date);
            fd.append("close_date", close_date);
            fd.append("delivery_charges", delivery_charges);
            fd.append("delivery_time", delivery_time);
            fd.append("return_type", return_type);
            fd.append("return_details", return_details);
            fd.append("warranty", warranty);
            fd.append("product_detailsjsonObj", JSON.stringify(product_detailsjsonObj));
            fd.append("offer_ids", offer_ids);
            fd.append("xcsrf", "<?php echo $csrf_token;?>");    
            ajaxRequest.open("POST", "product_background.php", true);
            ajaxRequest.send(fd);
        }
    }
    $(document).ready(function () {
        $("#main_category_select").change(function () {
            var main_category_select = $(this).val();
            if(main_category_select >= 0){
                var ajaxRequest, fd;
                try {
                    ajaxRequest = new XMLHttpRequest();
                }catch (e) {
                    try {
                        ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                    }catch (e) {
                        try{
                            ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                        }catch (e){
                            alert("Your browser broke!");
                            return false;
                        }
                    }
                }
                ajaxRequest.onreadystatechange = function(){
                    if(ajaxRequest.readyState == 4){                        
                        var data = JSON.parse(ajaxRequest.responseText);
                        $("#sub_category_select").empty();
                        var select = document.getElementById('sub_category_select');
                        var opt = document.createElement('option');
                        for (var i = 0; i<data.length; i++){  
                            var opt = document.createElement('option');                              
                            opt.value = data[i].id;
                            opt.innerHTML = data[i].value;
                            select.appendChild(opt);
                        }                        
                    }
                }
                fd = new FormData();
                fd.append("main_category_select", main_category_select);
                fd.append("xcsrf", "<?php echo $csrf_token;?>");            
                ajaxRequest.open("POST", "selectsubcategory.php", true);
                ajaxRequest.send(fd);
                
            }
        });
    });
    /* Price calculation start */
    function priceCalBO(){
        var original_price = document.getElementById('original_price').value;
        var basic_offer = document.getElementById('basic_offer').value;
        var selling_price = (((100-basic_offer)*original_price)/100).toFixed(2);//Calculation
        document.getElementById('selling_price').value = selling_price;//Calculation
        basic_offer = parseFloat(basic_offer).toFixed(2);//To round figure
        document.getElementById('basic_offer').value = basic_offer;
    }
    function priceCalSP(){
        var original_price = document.getElementById('original_price').value;
        var selling_price = document.getElementById('selling_price').value;
        var basic_offer = (100 - ((selling_price/original_price)*100)).toFixed(2);//Calculation
        document.getElementById('basic_offer').value = basic_offer;//Calculation value
        selling_price = parseFloat(selling_price).toFixed(2);//To round figure
        document.getElementById('selling_price').value = selling_price;
    }
    function priceCalOP(){
        var original_price = document.getElementById('original_price').value;
        var basic_offer = document.getElementById('basic_offer').value;
        var selling_price = document.getElementById('selling_price').value;
        try{
            var selling_price = (((100-basic_offer)*original_price)/100).toFixed(2);//Calculation
            document.getElementById('selling_price').value = selling_price;//Calculation value
            basic_offer = parseFloat(basic_offer).toFixed(2);//To round figure
            document.getElementById('basic_offer').value = basic_offer;
        }catch(err){
            var basic_offer = (100 - ((selling_price/original_price)*100)).toFixed(2);//Calculation
            document.getElementById('basic_offer').value = basic_offer;//Calculation value
            selling_price = parseFloat(selling_price).toFixed(2);//To round figure
            document.getElementById('selling_price').value = selling_price;
        }
    }
    /* Price calculation end */
    function publish_status_change(){
        var publish_status = document.getElementById("publish_status").value;
        if(publish_status == -1 || publish_status == 0 || publish_status == 1 ){
            document.getElementById("publish_date").disabled = true; 
            document.getElementById("publish_date").value = ""; 
            document.getElementById("close_date").disabled = true; 
            document.getElementById("close_date").value = ""; 
        }
        if(publish_status == 2){
            document.getElementById("publish_date").disabled = false; 
            document.getElementById("close_date").disabled = true; 
            document.getElementById("close_date").value = ""; 
        }
        if(publish_status == 3){
            document.getElementById("publish_date").disabled = true; 
            document.getElementById("publish_date").value = ""; 
            document.getElementById("close_date").disabled = false; 
        }
        if(publish_status == 4){
            document.getElementById("publish_date").disabled = false; 
            document.getElementById("close_date").disabled = false; 
        }
    }
    function return_type_change(){
        var return_type = document.getElementById("return_type").value;
        if(return_type == -1 || return_type == 0){            
            document.getElementById("return_details").disabled = true; 
            document.getElementById("return_details").value = "";
        }
        if(return_type > 0){            
            document.getElementById("return_details").disabled = false; 
        }
    }
    function add_offer(id,offer_details,offer_percentage,max_offer,min_order,start_date,end_date,offer_type){
        document.getElementById(id).remove();
        var newdiv = document.createElement('div');
        newdiv.classList.add("product-details-offer-inner-div-item");
        newdiv.id = id;
        var newspan = document.createElement('span');
        newspan.innerHTML = offer_details
        newdiv.appendChild(newspan);
        var newspan = document.createElement('span');
        newspan.classList.add('fa', 'fa-expand', 'blue');
        newspan.setAttribute("onclick", "expand_offer(\'"+id+"\',\'"+offer_details+"\',\'"+offer_percentage+"\',\'"+max_offer+"\',\'"+min_order+"\',\'"+start_date+"\',\'"+end_date+"\',\'"+offer_type+"\')");
        newdiv.appendChild(newspan);
        var newspan = document.createElement('span');
        newspan.classList.add('fa', 'fa-trash', 'red');
        newspan.setAttribute("onclick", "remove_offer(\'"+id+"\',\'"+offer_details+"\',\'"+offer_percentage+"\',\'"+max_offer+"\',\'"+min_order+"\',\'"+start_date+"\',\'"+end_date+"\',\'"+offer_type+"\')");
        newdiv.appendChild(newspan);
        document.getElementById('added_offer').appendChild(newdiv);
    }
    function remove_offer(id,offer_details,offer_percentage,max_offer,min_order,start_date,end_date,offer_type){
        document.getElementById(id).remove();
        var newdiv = document.createElement('div');
        newdiv.classList.add("product-details-offer-inner-div-item");
        newdiv.id = id;
        var newspan = document.createElement('span');
        newspan.innerHTML = offer_details
        newdiv.appendChild(newspan);
        var newspan = document.createElement('span');
        newspan.classList.add('fa', 'fa-expand', 'blue');
        newspan.setAttribute("onclick", "expand_offer(\'"+id+"\',\'"+offer_details+"\',\'"+offer_percentage+"\',\'"+max_offer+"\',\'"+min_order+"\',\'"+start_date+"\',\'"+end_date+"\',\'"+offer_type+"\')");
        newdiv.appendChild(newspan);
        var newspan = document.createElement('span');
        newspan.classList.add('fa', 'fa-plus', 'green');
        newspan.setAttribute("onclick", "add_offer(\'"+id+"\',\'"+offer_details+"\',\'"+offer_percentage+"\',\'"+max_offer+"\',\'"+min_order+"\',\'"+start_date+"\',\'"+end_date+"\',\'"+offer_type+"\')");
        newdiv.appendChild(newspan);
        document.getElementById('offer_list').appendChild(newdiv);
    }
    function expand_offer(id,offer_details,offer_percentage,max_offer,min_order,start_date,end_date,offer_type){
        document.getElementById('offer_expand_div').style.display = 'inline-block';
        if(offer_type == 0){
            offer_type = "Local";
        }else{
            offer_type = "Global";
        }
        var theString = "<div class=\'offer-expand-container\'><div class=\'offer-item background-green white\'>"+offer_details+"<div class=\'offer-item-action\'><span class=\'fa fa-close white\' onclick=\'offer_close()\'></span></div></div><div class=\'offer-all-details-container\'><div><span>Offer percentage</span><span>"+offer_percentage+"%</span></div><div><span>Maximum offer</span><span>"+max_offer+"/-</span></div><div><span>Manimum order</span><span>"+min_order+"/-</span></div><div><span>Start date</span><span>"+start_date+"</span></div><div><span>End date</span><span>"+end_date+"</span></div><div><span>Offer type</span><span>"+offer_type+"</span></div></div></div>";
        var theParent=document.getElementById("offer_expand_div");
        theParent.innerHTML=theString;
    }
    function offer_close(){
        document.getElementById('offer_expand_div').style.display = 'none';
    }
    function add_product_details(){
        var product_details_div_counter = new Date().getTime();
        var newdiv = document.createElement('div');
        newdiv.classList.add("dynamic-product-details-item-inner");
        newdiv.id = 'product_details_div'+product_details_div_counter;
        newdiv.innerHTML="<div class=\'dynamic-product-details-item-inner-div\'><input type=\'text\' name=\'details_type1\' id=\'details_type"+product_details_div_counter+"\' class=\'login-textbox\' placeholder=\'Enter product details type\'></div><div class=\'dynamic-product-details-item-inner-div\'><input type=\'text\' name=\'product_details1\' id=\'product_details"+product_details_div_counter+"\' class=\'login-textbox\' placeholder=\'Enter product details\'></div><div class=\'dynamic-product-details-item-inner-action-div\'><button class=\'login-button\' onclick=remove_product_details(\'product_details_div"+product_details_div_counter+"\')>Remove</button></div>";
        document.getElementById('product_details_inner').appendChild(newdiv);
    }
    function remove_product_details(id){
        document.getElementById(id).remove();
    }
    function reset(){
        window.location.reload();
    }
    function delete_product(id){
        if(confirm("Are you sure to delete the product ? Press ok to confirm.")){    
            var ajaxRequest, fd;
            try {
                ajaxRequest = new XMLHttpRequest();
            }catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                }catch (e) {
                    try{
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    }catch (e){
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }
            ajaxRequest.onreadystatechange = function(){
                if(ajaxRequest.readyState == 4){
                    var data = JSON.parse(ajaxRequest.responseText);
                    if(data.code == "200"){
                        window.location.reload();
                    }else{
                        $("#productlist_err").html("<ul>"+data.msg+"</ul>");
                        $("#productlist_err").css("display","block");
                    }
                }
            }
            fd = new FormData();
            fd.append("product_id", id);
            fd.append("xcsrf", "<?php echo $csrf_token;?>");          
            ajaxRequest.open("POST", "delete_product_background.php", true);
            ajaxRequest.send(fd);
        }
    }
    function restore(id){
        if(confirm("Are you sure to restore the product ? Press ok to confirm.")){  
            var ajaxRequest, fd;
            try {
                ajaxRequest = new XMLHttpRequest();
            }catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                }catch (e) {
                    try{
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    }catch (e){
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }
            ajaxRequest.onreadystatechange = function(){
                if(ajaxRequest.readyState == 4){
                    var data = JSON.parse(ajaxRequest.responseText);
                    if(data.code == "200"){
                        window.location.reload();
                    }else{
                        $("#main_err").html("<ul>"+data.msg+"</ul>");
                        $("#main_err").css("display","block");
                    }
                }
            }
            fd = new FormData();
            fd.append("product_id", id);
            fd.append("xcsrf", "<?php echo $csrf_token;?>");          
            ajaxRequest.open("POST", "product_restore_background.php", true);
            ajaxRequest.send(fd);
        }
    }
</script>
</html>