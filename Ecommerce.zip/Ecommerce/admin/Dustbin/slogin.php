<?php include 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
/*$err = '';
if(isset($_POST['submit'])){
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $gender = $_POST['gender'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $n_password = $_POST['n_password'];
    $c_password = $_POST['c_password'];
    if($fname!=''){
        if($lname!=''){
            if($gender=='0'||$gender=='1'||$gender=='2'){

            }else{
                $err = 'Select gender';
            }
        }else{
            $err = 'Enter Last name';
        }
    }else{
        $err = 'Enter First name';
    }
    if($err!=''){
        echo "<script type='text/javascript'>alert('$err');</script>";
    }
    /*$sql = "INSERT INTO a_profile (uid, f_name,l_name,gender,phone,verify_phone,email,verify_email,password,user_type)
    VALUES ('ngnbg','".$_POST["fname"]."','".$_POST["lname"]."',0,'".$_POST["phone"]."',0,'".$_POST["email"]."',0,'".$_POST["n_password"]."',0)";
    //$result = mysqli_query($conn,$sql);
    if(mysqli_query($conn,$sql)){
        //echo "ok";
    }*/
//}
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
<div class="container">
    <?php include 'sheader.php';?>
    <div class="login-container">
        <form action="<?=$_SERVER['PHP_SELF'];?>" method="post">
            <div class="login-div">
                <div class="login-part">
                    <img src="icons/4.png" class="login-part-img">
                </div>
                <div class="login-part">
                    <div class="login-part-inner" id="login_div" >
                        <div class="headline"><span>Login</span></div>
                        <div class="login-item">
                            <input type="text" name="userid" class="login-textbox" placeholder="Enter Mobile number">
                        </div>
                        <div class="login-item">
                            <input type="password" name="password" class="login-textbox" placeholder="Password">
                        </div>
                        <div class="login-item">
                            <button type="submit" class="login-button" name="login">Login</button>
                        </div>
                        <div class="login-item">
                            <a href="#" onclick="openRegistration()">Create an account</a>
                            <a href="#" style="float: right;">Forgot password?</a>
                        </div>
                    </div>
                    <div class="login-part-inner" id="registration_div" style="display: none">
                        <div class="headline"><span>Registration</span></div>
                        <div class="alert alert-danger" id="registration_err">
                            Invalid details
                        </div>
                        <div class="login-item">
                            <input type="text" name="fname" id="fname" class="login-textbox" placeholder="First name">
                        </div>
                        <div class="login-item">
                            <input type="text" name="lname" id="lname" class="login-textbox" placeholder="Last name">
                        </div>
                        <div class="login-item">
                            Gender :
                            <input type="radio" name="gender" value="1" checked> Male
                            <input type="radio" name="gender" value="2"> Female
                            <input type="radio" name="gender" value="3"> Other
                        </div>
                        <div class="login-item">
                            <input type="text" name="phone" id="phone" class="login-textbox" placeholder="Enter Mobile number">
                        </div>
                        <div class="login-item">
                            <input type="text" name="email" id="email" class="login-textbox" placeholder="Enter Email id">
                        </div>
                        <div class="login-item">
                            <input type="password" name="n_password" id="n_password" class="login-textbox" placeholder="New password">
                        </div>
                        <div class="login-item">
                            <input type="password" name="c_password" id="c_password" class="login-textbox" placeholder="Confirm password">
                        </div>
                        <div class="login-item">
                            <button type="submit" class="login-button" name="submit" id="submit">Submit</button>
                        </div>
                        <div class="login-item">
                            <a href="#" onclick="openLogin()">Existing User? Log in</a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript">
    function openRegistration(){
        document.getElementById('login_div').style.display = "none";
        document.getElementById('registration_div').style.display = "block";
    }
    function openLogin(){
        document.getElementById('login_div').style.display = "block";
        document.getElementById('registration_div').style.display = "none";
    }
    $(document).ready(function(){
        $('#submit').click(function(e){
            e.preventDefault();
            var fname = $("#fname").val();
            var lname = $("#lname").val();
            var gender =  $("input[name='gender']:checked").val();
            var phone = $("#phone").val();
            var email = $("#email").val();
            var n_password = $("#n_password").val();
            var c_password = $("#c_password").val();
            $.ajax({
                type : "POST",
                url : "/Ecommerce/sregistration_backgroung.php",
                dataType : "json",
                data:{fname:fname, lname:lname, gender:gender, phone:phone, email:email, n_password:n_password, c_password:c_password},
                success : function(data){
                    if(data.code == "200"){
                        $("#registration_err").html("<ul>"+data.msg+"</ul>");
                        $("#registration_err").css("display","block");
                    }else{
                        $("#registration_err").html("<ul>"+data.msg+"</ul>");
                        $("#registration_err").css("display","block");
                    }
                }
            });
        });
    });
</script>
</body>
</html>