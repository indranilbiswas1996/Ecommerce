<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
if(login_check() != true){
    header("Location: logout.php");
}
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
<?php include 'header.php';?>
<?php
    $f_name = $m_name = $l_name = $dob = "";
    $gender = 1;
    $email = $alternet_phone = $alternet_email = $pin = $locality = $address =  $gst =  $govt_proof_no = $pan = "";
    $dist = $state = $govt_proof = -1;
    include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
    $superadmin_uid = $_SESSION['superadmin_uid'];
    $stmt1 = $conn->prepare("SELECT `f_name`,`m_name`, `l_name`, `dob`, `gender` FROM `superadmin` WHERE `superadmin_uid` = ?");        
    $stmt1->bind_param('s', $superadmin_uid);
    $stmt1->execute();
    $stmt1->store_result();
    if($stmt1->num_rows() != 0){                    
        $stmt1->bind_result($f_name, $m_name, $l_name, $dob, $gender);               
        $stmt1->fetch();
    } 
    $stmt1->close();
    $stmt = $conn->prepare("SELECT `email`, `alternet_phone`, `alternet_email`, `pin`, `locality`, `address`, `dist`, `state`, `gst`, `govt_proof`, `govt_proof_no`, `pan` FROM `superadmin_details` WHERE `superadmin_uid` = ?");        
    $stmt->bind_param('s', $superadmin_uid);
    $stmt->execute();
    $stmt->store_result();
    if($stmt->num_rows() != 0){                    
        $stmt->bind_result($email, $alternet_phone, $alternet_email, $pin, $locality, $address, $dist, $state, $gst, $govt_proof, $govt_proof_no, $pan);               
        $stmt->fetch();
    }                
    $stmt->close();
    if($alternet_phone == 0){
        $alternet_phone = "";
    }

?>
<div class="container">
    <div class="shop-container">
    <div class="alert alert-danger" id="login_err"></div>
    <div class="shop-container-inner">
            <h4>Personal details</h4>
            <div class="alert alert-danger" id="personal_err"></div>
            <div class="shop-container-div-3">
                <label class="login-label">First name<span class="red">*</span></label>
                <input type="text" name="f_name" id="f_name" class="login-textbox" value="<?php echo $f_name; ?>" placeholder="Enter first name">
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">Middle name</label>
                <input type="text" name="m_name" id="m_name" class="login-textbox" value="<?php echo $m_name; ?>" placeholder="Enter middle name">
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">Last name<span class="red">*</span></label>
                <input type="text" name="l_name" id="l_name" class="login-textbox" value="<?php echo $l_name; ?>" placeholder="Enter last name">
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">Gender : <span class="red">*</span></label>
                <input type="radio" name="gender" value="1" <?php if($gender == 1) echo 'checked';?>> Male
                <input type="radio" name="gender" value="2" <?php if($gender == 2) echo 'checked';?>> Female
                <input type="radio" name="gender" value="3" <?php if($gender == 3) echo 'checked';?>> Other
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">Date of birth<span class="red">*</span></label>
                <input type="date" name="dob" id="dob" class="login-textbox" value="<?php echo $dob; ?>" placeholder="Enter date of birth">
            </div>
        </div>
        <div class="shop-container-inner">
            <h4>Shop information</h4>
            <div class="alert alert-danger" id="info_err"></div>
            
            <div class="shop-container-div-3">
                <label class="login-label">Mobile number<span class="red">*</span></label>
                <input type="text" name="phone" id="phone" class="login-textbox" placeholder="Enter mobile number" value="<?php echo $_SESSION['phone']; ?>" disabled>
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">Alternet mobile number</label>
                <input type="text" name="alternet_phone" id="alternet_phone" class="login-textbox" value="<?php echo $alternet_phone; ?>" placeholder="Enter alternet mobile number">  
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">Email id</label>
                <input type="text" name="email" id="email" class="login-textbox" value="<?php echo $email; ?>" placeholder="Enter email id">
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">Alternet email id</label>
                <input type="text" name="alternet_email" id="alternet_email" class="login-textbox" value="<?php echo $alternet_email; ?>" placeholder="Enter alternet email id">
            </div>
        </div>
        <div class="shop-container-inner">
            <h4>Address</h4>
            <div class="alert alert-danger" id="address_err"></div>
            <div class="shop-container-div-3">
                <label class="login-label">Locality<span class="red">*</span></label>
                <input type="text" name="locality" id="locality" class="login-textbox" value="<?php echo $locality; ?>" placeholder="Enter locality">  
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">Address<span class="red">*</span></label>
                <input type="text" name="address" id="address" class="login-textbox" value="<?php echo $address; ?>" placeholder="Enter address">
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">State<span class="red">*</span></label>
                <select id="state" name="state" class="login-selectbox">
                    <option value="-1">Select state</option>
                    <?php
                        $one = 1;
                        $stmt = $conn->prepare("SELECT state_code, state_name FROM all_states");
                        $stmt->execute();
                        $stmt->store_result();
                        if($stmt->num_rows() != 0){                    
                            $stmt->bind_result($state_code, $state_name);
                            while($stmt->fetch()){
                                echo '<option value="'.$state_code.'">'.$state_name.'</option>';
                            }
                        }
                        $stmt->close();
                    ?>                            
                </select>
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">District<span class="red">*</span></label>
                <select id="dist" name="dist" class="login-selectbox">
                    <option value="-1">Select district</option>   
                    <?php 
                        if($state > -1){
                            $stmt = $conn->prepare("SELECT city_name, city_code FROM `all_cities` WHERE state_code = ?");        
                            $stmt->bind_param('s', $state);
                            $stmt->execute();
                            $stmt->store_result();
                            if($stmt->num_rows() != 0){                    
                                $stmt->bind_result($city_name, $city_code); 
                                while($stmt->fetch()){
                                    echo '<option value="'.$city_code.'">'.$city_name.'</option>';
                                }
                            }
                            $stmt->close();
                        }
                    ?>                         
                </select>
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">Pin code<span class="red">*</span></label>
                <input type="number" name="pin" id="pin" class="login-textbox" value="<?php echo $pin; ?>" placeholder="Enter pin no">
            </div>
        </div>
        <div class="shop-container-inner">
            <h4>Proof details</h4>
            <div class="alert alert-danger" id="proof_err"></div>
            <div class="shop-container-div-3">
            <label class="login-label">Govt proof type<span class="red">*</span></label>
            <select id="govt_proof" name="govt_proof" class="login-selectbox" <?php if($_SESSION['admin_status'] == 1) echo "disabled"?>>
                    <option value="-1">Select Govt proof type</option>
                    <?php
                        $one = 1;
                        $stmt = $conn->prepare("SELECT id, govt_proof_details FROM govt_proof WHERE status = ?");
                        $stmt->bind_param('s', $one);
                        $stmt->execute();
                        $stmt->store_result();
                        if($stmt->num_rows() != 0){                    
                            $stmt->bind_result($id, $govt_proof_details);
                            while($stmt->fetch()){
                                echo '<option value="'.$id.'">'.$govt_proof_details.'</option>';
                            }
                        }
                        $stmt->close();
                        $conn->close();
                    ?>                            
                </select>
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">Govt proof id<span class="red">*</span></label>
                <input type="text" name="govt_proof_no" id="govt_proof_no" class="login-textbox"  <?php if($_SESSION['admin_status'] == 1) echo "disabled"?> value="<?php echo $govt_proof_no; ?>" placeholder="Enter id">  
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">GST number</label>
                <input type="text" name="gst" id="gst" class="login-textbox" value="<?php echo $gst; ?>" placeholder="Enter GST">
            </div>
            <div class="shop-container-div-3">
                <label class="login-label">PAN card</label>
                <input type="text" name="pan" id="pan" class="login-textbox" value="<?php echo $pan; ?>" placeholder="Enter PAN">
            </div>
        </div>
        <div class="shop-save-div">
            <button type="submit" class="login-button" name="shop" id="shop" onclick="shop()">Save</button>
        </div>
    </div>
    
</div>
<script type="text/javascript">
    
    
    <?php if($state > -1) {?>
        document.getElementById('state').value=<?php echo $state ?>;
    <?php } ?>
    <?php if($dist > -1) {?>
        document.getElementById('dist').value=<?php echo $dist ?>;
    <?php } ?>
    <?php if($govt_proof > -1) {?>
        document.getElementById('govt_proof').value=<?php echo $govt_proof ?>;
    <?php } ?>

    function shop(){
        $("#info_err").css("display","none");        
        $("#address_err").css("display","none");
        $("#proof_err").css("display","none");
        try{
            $('input').removeClass('outline-red');
            $('select').removeClass('outline-red');
        }catch(e){}
        var err = "";
        var err_flag = 0;
        var f_name = document.getElementById('f_name').value;
        var m_name = document.getElementById('m_name').value;
        var l_name = document.getElementById('l_name').value;
        var gender = document.querySelector('input[name = gender]:checked').value;
        var dob = document.getElementById('dob').value;
        var phone=document.getElementById('phone').value;
        var alternet_phone=document.getElementById('alternet_phone').value;
        var email=document.getElementById('email').value;
        var alternet_email=document.getElementById('alternet_email').value;
        var locality=document.getElementById('locality').value;
        var address=document.getElementById('address').value;
        var state=document.getElementById('state').value;
        var dist=document.getElementById('dist').value;
        var pin=document.getElementById('pin').value;
        var govt_proof=document.getElementById('govt_proof').value;
        var govt_proof_no=document.getElementById('govt_proof_no').value;
        var gst=document.getElementById('gst').value;
        var pan=document.getElementById('pan').value;
        if(f_name==""){
            err_flag++;
            err +=  '<li>Enter First name</li>'; 
            document.getElementById("f_name").classList.add("outline-red");
        }
        if(l_name==""){
            err_flag++;
            err +=  '<li>Enter last name</li>'; 
            document.getElementById("l_name").classList.add("outline-red");
        }
        if(gender<1 && gender > 3){
            err_flag++;
            err +=  '<li>Select gender</li>';
            document.querySelector('input[name = gender]:checked').classList.add("outline-red");
        }
        if(dob==""){
            err_flag++;
            err +=  '<li>Enter date of birth</li>'; 
            document.getElementById("dob").classList.add("outline-red");
        }
        if(err != ""){
            $("#personal_err").html("<ul>"+err+"</ul>");
            $("#personal_err").css("display","block");
        }
        err = "";
        var mob = /^[6-9]{1}[0-9]{9}$/;        
        if(alternet_phone != ""){
            if (mob.test(alternet_phone) == false) {
                err_flag++;
                err += "<li>Invalid alternet mobile no</li>";
                document.getElementById("alternet_phone").classList.add("outline-red");
            }
        }
        var email_reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;        
        if(email != ""){
            if (email_reg.test(email) == false) {
                err_flag++;
                err += "<li>Invalid email id</li>";
                document.getElementById("email").classList.add("outline-red");
            }
        }
        if(alternet_email != ""){
            if (email_reg.test(alternet_email) == false) {
                err_flag++;
                err += "<li>Invalid alternet email id</li>";
                document.getElementById("alternet_email").classList.add("outline-red");
            }
        }
        if(err != ""){
            $("#info_err").html("<ul>"+err+"</ul>");
            $("#info_err").css("display","block");
        }
        err = "";
        if (locality == "") {
            err_flag++;
            err += "<li>Enter locality</li>";
            document.getElementById("locality").classList.add("outline-red");
        }
        if (address == "") {
            err_flag++;
            err += "<li>Enter address</li>";
            document.getElementById("address").classList.add("outline-red");
        }
        if (state <= 0) {
            err_flag++;
            err += "<li>Select state</li>";
            document.getElementById("state").classList.add("outline-red");
        }
        if (dist <= 0) {
            err_flag++;
            err += "<li>Select district</li>";
            document.getElementById("dist").classList.add("outline-red");
        }
        var pin_p = /^[0-9]{6}$/;   
        if (pin == "") {
            err_flag++;
            err += "<li>Enter pin no</li>";
            document.getElementById("pin").classList.add("outline-red");
        }else{
            if (pin_p.test(pin) == false) {
                err_flag++;
                err += "<li>Invalid pin no</li>";
                document.getElementById("pin").classList.add("outline-red");
            }
        }
        if(err != ""){
            $("#address_err").html("<ul>"+err+"</ul>");
            $("#address_err").css("display","block");
        }
        err = "";
        if (govt_proof <= 0) {
            err_flag++;
            err += "<li>Select Govt proof type</li>";
            document.getElementById("govt_proof").classList.add("outline-red");
        }
        if (govt_proof_no <= 0) {
            err_flag++;
            err += "<li>Enter Govt proof id</li>";
            document.getElementById("govt_proof_no").classList.add("outline-red");
        }
        if(err != ""){
            $("#proof_err").html("<ul>"+err+"</ul>");
            $("#proof_err").css("display","block");
        }
        if(err_flag == 0){
            var ajaxRequest, fd;
            try {
                ajaxRequest = new XMLHttpRequest();
            }catch (e) {
                try {
                    ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                }catch (e) {
                    try{
                        ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                    }catch (e){
                        alert("Your browser broke!");
                        return false;
                    }
                }
            }
            ajaxRequest.onreadystatechange = function(){
                if(ajaxRequest.readyState == 4){
                    var data = JSON.parse(ajaxRequest.responseText);
                    if(data.code == "200"){
                        window.location = "index.php";
                    }else{
                        $("#login_err").html("<ul>"+data.msg+"</ul>");
                        $("#login_err").css("display","block");
                    }
                }
            }
            fd = new FormData();
            fd.append("f_name", f_name);
            fd.append("m_name", m_name);
            fd.append("l_name", l_name);
            fd.append("gender", gender);
            fd.append("dob", dob);
            fd.append("alternet_phone", alternet_phone);
            fd.append("email", email);
            fd.append("alternet_email", alternet_email);
            fd.append("locality", locality);
            fd.append("address", address);
            fd.append("state", state);
            fd.append("dist", dist);
            fd.append("pin", pin);
            fd.append("govt_proof", govt_proof);
            fd.append("govt_proof_no", govt_proof_no);
            fd.append("gst", gst);
            fd.append("pan", pan);
            fd.append("xcsrf", "<?php echo $csrf_token;?>");          
            ajaxRequest.open("POST", "superadmindetails_background.php", true);
            ajaxRequest.send(fd);
        }
    }
    $(document).ready(function () {
        $("#state").change(function () {
            var state = $(this).val();
            if(state >= 0){
                var ajaxRequest, fd;
                try {
                    ajaxRequest = new XMLHttpRequest();
                }catch (e) {
                    try {
                        ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
                    }catch (e) {
                        try{
                            ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
                        }catch (e){
                            alert("Your browser broke!");
                            return false;
                        }
                    }
                }
                ajaxRequest.onreadystatechange = function(){
                    if(ajaxRequest.readyState == 4){
                        var data = JSON.parse(ajaxRequest.responseText);
                        //dist//
                        var select = document.getElementById('dist');
                        $("#dist").empty();
                        var opt = document.createElement('option');
                        opt.value = -1;
                        opt.innerHTML = "Select district";
                        select.appendChild(opt);
                        
                        for (var i = 0; i<data.length; i++){  
                            var opt = document.createElement('option');                              
                            opt.value = data[i].value;
                            opt.innerHTML = data[i].id;
                            select.appendChild(opt);
                        }
                    }
                }
                fd = new FormData();
                fd.append("state", state);
                fd.append("xcsrf", "<?php echo $csrf_token;?>");            
                ajaxRequest.open("POST", "selectdist.php", true);
                ajaxRequest.send(fd);
                
            }
        });
    });
</script>
</body>
</html>