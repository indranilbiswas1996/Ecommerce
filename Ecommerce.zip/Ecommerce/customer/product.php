<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
if(isset($_GET['product'])){
    $product_id = $_GET['product'];
    //echo $product_id;
}
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <?php include 'header_files.php';?>
</head>
<body>
    <?php include 'header.php';?>
    <div class="container">
    <?php 
        include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
        $zero = 0;
        $stmt = $conn->prepare("SELECT pmc.details, psc.details, p.product_name, p.product_details, p.original_price, p.basic_offer, p.selling_price, p.return_type, p.return_details, p.delivery_charges, p.delivery_time, s.shop_name, p.status, p.live_status, p.payment_details FROM product p, product_main_category pmc, product_sub_category psc, shop s WHERE p.id = ? AND p.status > ? AND p.live_status > ? AND pmc.id = p.product_main_id AND p.product_sub_id = psc.id AND p.shop_uid = s.shop_uid");        
        $stmt->bind_param('sss', $product_id, $zero, $zero);
        $stmt->execute();
        $stmt->store_result();
        if($stmt->num_rows() != 0){                    
            $stmt->bind_result($product_main_details, $product_sub_details, $product_name, $product_details, $original_price, $basic_offer, $selling_price, $return_type, $return_details, $delivery_charges, $delivery_time, $shop_name, $status, $live_status, $payment_details);               
            $stmt->fetch();
            $flag = 0;
            if($status == 1){
                $flag = 1;
            }
            if($status == 2){
                date_default_timezone_set('Asia/Kolkata');
                $current_time = date('Y-m-d H:i:s');
                if($current_time > $publish_date){
                    $flag = 1;
                }                                                   
            }
            if($status == 3){
                date_default_timezone_set('Asia/Kolkata');
                $current_time = date('Y-m-d H:i:s');
                if($current_time < $close_date){
                    $flag = 1;
                }                                                   
            }
            if($status == 4){
                date_default_timezone_set('Asia/Kolkata');
                $current_time = date('Y-m-d H:i:s');
                if($current_time > $publish_date && $current_time < $close_date){
                    $flag = 1;
                }                                                    
            }
            if($flag == 1){ ?>
                <div class="view-product-container">
                    <div class="view-product-img-container">
                        <div class="view-product-img-container-div">
                            <span class="wishlist-span">
                                <i class="fa fa-heart" onclick="wishlist('<?php echo $product_id ?>')" aria-hidden="true"></i>
                            </span>
                            <div class="view-product-imglist-container">   
                                <ul id="imglist_container_ul">

                                <?php
                                    $imgview = '';
                                    $stmt1 = $conn->prepare("SELECT `img` FROM `product_pics` WHERE product_id = ?");
                                    $stmt1->bind_param('s', $product_id);
                                    $stmt1->execute();
                                    $stmt1->store_result();
                                    if($stmt1->num_rows() != 0){                    
                                        $stmt1->bind_result($img);
                                        $img_flag = 0;
                                        while($stmt1->fetch()){
                                            if($img_flag == 0){
                                                echo '<li class="border-blue"  onmouseover="changeTo(this,\''.$img_link.'img/'.$img.'\')"><img src="'.$img_link.'img/'.$img.'"></li>';
                                                $img_flag++;
                                                $imgview = $img_link.'img/'.$img;
                                            }else{
                                                echo '<li onmouseover="changeTo(this,\''.$img_link.'img/'.$img.'\')"><img src="'.$img_link.'img/'.$img.'"></li>';
                                                $img_flag++;
                                            }
                                        }
                                    }
                                    $stmt1->close();
                                ?>
                                    
                                </ul>
                                <span class="angle-up" onclick="up()"><i class="fa fa-angle-up" aria-hidden="true"></i></span>
                                <span class="angle-down" onclick="down()"><i class="fa fa-angle-down" aria-hidden="true"></i></span>      
                            </div>
                            <div class="view-product-imgview-container">  
                                <img id="imgview" src="<?php echo $imgview; ?>">            
                            </div>
                        </div>
                        <div class="view-product-action-container">
                            <div class="view-product-add-to-cart-action-div">
                                <button type="submit" class="cart-button" onclick="add_to_cart('<?php echo $product_id; ?>')">ADD TO CART</button>
                            </div>
                            <div class="view-product-order-now-action-div">
                                <button type="submit" class="cart-button background-green" onclick="buy_now('<?php echo $product_id; ?>')">BUY NOW</button>
                            </div>
                        </div>
                    </div>
                    <div class="view-product-details-container">
                        <div class="view-product-details-category">
                            <a href="#"><?php echo $product_main_details; ?></a>
                            <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                            <a href="#"><?php echo $product_sub_details; ?></a>
                        </div>
                        <h3 class="view-product-product-name"><?php echo $product_name.' '.$product_details; ?></h3>
                        <div>
                            <span class="special-price green">Special price</span>
                            <span class="view-product-product-price-selling">₹<?php echo $selling_price; ?></span>
                            <span class="view-product-product-price-actual">₹<?php echo $original_price; ?></span>
                            <span class="view-product-product-price-offer"><?php echo $basic_offer; ?>% off</span>
                        </div>
                        <div class="view-product-offer-container">
                            <?php
                                $one =1;
                                $stmt2 = $conn->prepare("SELECT id, offer_details, offer_percentage, max_offer, min_order, start_date, end_date, offer_type FROM offer WHERE offer_status = ? AND id IN (SELECT `offer_id` FROM `product_offer` WHERE `product_id` = ?) ORDER BY offer_details ASC");
                                $stmt2->bind_param('ss', $one, $product_id);
                                $stmt2->execute();
                                $stmt2->store_result();
                                if($stmt2->num_rows() != 0){                    
                                    $stmt2->bind_result($id, $offer_details, $offer_percentage, $max_offer, $min_order, $start_date, $end_date, $offer_type);
                                    while($stmt2->fetch()){	
                                        date_default_timezone_set('Asia/Kolkata');
                                        $current_time = date('Y-m-d H:i:s');
                                        if($start_date < $current_time && $end_date > $current_time){
                                            echo '<div class="view-product-offer"><i class="fa fa-tag" aria-hidden="true"></i>'.$offer_details.'</div>';
                                        }
                                    }
                                }
                                $stmt2->close();
                            ?>
                        </div>
                        <div class="view-product-pin-check-container">
                            <span class="view-product-topic">Delivery</span>
                            <div class="view-product-topic-details">
                                <input type="number" name="pin" id="pin" class="view-product-pin-check-input" placeholder="Enter pin no">
                                <button type="submit" class="view-product-pin-check-button" onclick="pincheck()" >Check</button>
                                <span class="view-product-pin-check-span">Faster delivery by <?php echo $delivery_time; ?> days|₹<?php echo $delivery_charges; ?></span>
                            </div>
                        </div>
                        <div class="view-product-pin-check-container">
                            <span class="view-product-topic">Services</span>
                            <div class="view-product-topic-details">
                                <span class="view-product-return-span"><i class="fa fa-refresh" aria-hidden="true"></i>
                                <?php
                                    if($return_type == 0){ echo 'No Returns Applicable '.$return_details;}
                                    if($return_type == 1){ echo 'Return '.$return_details;}
                                    if($return_type == 2){ echo 'Replacement '.$return_details;}
                                    if($return_type == 3){ echo 'Return/Replacement '.$return_details;}
                                ?></span>
                                <span class="view-product-delivery-type-span"><i class="fa fa-inr" aria-hidden="true"></i>
                                Payment 
                                <?php
                                    if($payment_details == 0){ echo 'Cash on delivery';}
                                    if($payment_details == 1){ echo 'Online';}
                                    if($payment_details == 2){ echo 'Cash on delivery/Online';}
                                ?>                                
                                 available</span>
                            </div>
                        </div>
                        <div class="view-product-pin-check-container">
                            <span class="view-product-topic">Seller</span>
                            <div class="view-product-topic-details">
                                <span class="view-product-shop-span"><?php echo $shop_name; ?></span>
                            </div>
                        </div>
                        <div class="view-product-specifications-container">
                            <div class="view-product-specifications-headline">Specifications</div>
                            <div class="view-product-specifications-body">
                            <table class="view-product-specifications-table">
                                <?php
                                    $stmt2 = $conn->prepare("SELECT details_type, details FROM product_details WHERE product_id = ?");
                                    $stmt2->bind_param('s', $product_id);
                                    $stmt2->execute();
                                    $stmt2->store_result();
                                    if($stmt2->num_rows() != 0){                    
                                        $stmt2->bind_result($details_type, $details);
                                        while($stmt2->fetch()){	
                                            echo '
                                            <tr>
                                                <td>'.$details_type.'</td>
                                                <td>'.$details.'</td>
                                            </tr>
                                            ';
                                        }
                                    }
                                    $stmt2->close();
                                ?>
                                </table>
                            </div>
                        </div>
                    </div>   
                    <div class="secure-tag-container">
                        <img class="secure-tag-icon" src="icons/shield.png">
                        <span class="secure-tag-details">Safe and Secure Payments. Easy returns. 100% Authentic products.</span>
                    </div>         
                </div>
            <?php
            }else{
                echo '<h1>Something went wrong!</h1>';
            }   
        }else{
            echo '<h1>Something went wrong!</h1>';
        }               
        $stmt->close();
        $conn->close();
    ?>
    </div>
</body>
<script type="text/javascript">
    function changeTo(x, img) {
        try{
            $('li').removeClass('border-blue');
        }catch(e){}
        x.classList.add("border-blue");
        document.getElementById('imgview').src = img;
    }
    function up(){
        var scroll = 192;
        var div_height = 450;
        var total_height = document.getElementById("imglist_container_ul").offsetHeight;
        /*Current translate */
        var style = window.getComputedStyle(document.getElementById('imglist_container_ul'));
        var matrix = new WebKitCSSMatrix(style.transform);
        var current_translate = matrix.m42;

        if(current_translate<0){
            if((current_translate+scroll) > 0){
                document.getElementById('imglist_container_ul').style.transform = "translateY(0px)";
            }else{
                document.getElementById('imglist_container_ul').style.transform = "translateY("+(current_translate+scroll)+"px)";
            }
        }
    }
    function down(){
        var scroll = 192;
        var div_height = 450;
        var total_height = document.getElementById("imglist_container_ul").offsetHeight;
        /*Current translate */
        var style = window.getComputedStyle(document.getElementById('imglist_container_ul'));
        var matrix = new WebKitCSSMatrix(style.transform);
        var current_translate = matrix.m42;
        if((total_height-div_height)>(-1*(current_translate))){
            if((-1*(current_translate-scroll))>(total_height-div_height)){
                document.getElementById('imglist_container_ul').style.transform = "translateY("+(-1 * (total_height-div_height))+"px)";
            }
            else{
                document.getElementById('imglist_container_ul').style.transform = "translateY("+(current_translate-scroll)+"px)";
            }
        }
    }
    //localStorage.clear();
    function add_to_cart(id){
        var storedNames = JSON.parse(localStorage.getItem("product"));
        if(storedNames == null){
            var namesArr = [];  
            namesArr.push(id); 
            localStorage.setItem('product', JSON.stringify(namesArr));
        }else{
            var namesArr = storedNames;
            const index = namesArr.indexOf(id);
            if (index < 0) {
                namesArr.push(id); 
                localStorage.setItem('product', JSON.stringify(namesArr));
            }
        }
        //
        /*for(var i=0; i<storedNames.length; i++){
            alert(storedNames[i]);
        }*/
        window.location.reload();
    }
    function buy_now(id){
        window.location = "cart.php?id="+id;
    }
</script>
</html>