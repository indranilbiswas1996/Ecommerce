<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(login_check() != true){
    if(isset($_POST['xcsrf']) ){
        if($_POST['xcsrf'] == $csrf_token) {
            $phone = htmlspecialchars($_POST["phone"]);
            $confirm_password = htmlspecialchars($_POST["password"]);
            if(empty($phone)){
                $code = 400;
                $msg .= "<li>Enter Mobile number</li>";
            }else{
                $phone = $_POST["phone"];
                if(!preg_match("/^[6-9]{1}[0-9]{9}$/", $phone)) {
                    $code = 400;
                    $msg .= "<li>Invalid Mobile no</li>";
                }
            }
            if($confirm_password == ""){
                $code = 400;
                $msg .= "<li>Enter Password</li>";
            }
            if(empty($msg)){
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                //$zero = 0;
                //$one = 1;
                $stmt = $conn->prepare("SELECT id, customer_uid, f_name, password, verify_phone FROM customer WHERE phone = ?");        
                $stmt->bind_param('s', $phone);
                $stmt->execute();
                $stmt->store_result();
                $stmt->bind_result($id, $customer_uid, $f_name, $passwordHash, $verify_phone);
                if($stmt->num_rows() == 1){
                    $stmt->fetch();
                    if(check_hash($confirm_password,$passwordHash)){
                        //$code = 200;
                        //$msg = "Suss";
                        $_SESSION['phone'] = $phone;
                        $_SESSION['f_name'] = $f_name;
                        $_SESSION['customer_uid'] = $customer_uid;
                        if($verify_phone == 1){
                            $_SESSION['logged_in'] = 1;
                            $code = 200;
                            $msg = "Success";
                        }else{

                            $stmt2 = $conn->prepare("SELECT p_resend_count, e_resend_count FROM customer_otp WHERE phone = ?");        
                            $stmt2->bind_param('s', $phone);
                            $stmt2->execute();
                            $stmt2->store_result();
                            $stmt2->bind_result($p_resend_count, $e_resend_count);
                            $p_count = 0; $e_count = 0;
                            if($stmt2->num_rows() == 1){
                                $stmt2->fetch();
                                $p_count = $p_resend_count;
                                $e_count = $e_resend_count;
                            }
                            $stmt2->close();
                            $p_count++;
                            $e_count++;
                            //Create OTP
                            $generator = "135792468"; 
                            $phone_otp = "";   
                            for ($i = 1; $i <= 6; $i++) { 
                                $phone_otp .= substr($generator, (rand()%(strlen($generator))), 1); 
                            } 
                            $email_otp = "";   
                            for ($i = 1; $i <= 6; $i++) { 
                                $email_otp .= substr($generator, (rand()%(strlen($generator))), 1); 
                            } 
                            //To set IST time
                            date_default_timezone_set('Asia/Kolkata');
                            $p_resend_time = date('Y-m-d h:i:s');

                            $stmt3 = $conn->prepare("UPDATE customer_otp SET phone_otp = ? ,p_resend_count = ?, p_resend_time = ?, email_otp = ?, e_resend_count = ?, e_resend_time = ? WHERE phone = ?");        
                            $stmt3->bind_param('sssssss', $phone_otp, $p_count, $p_resend_time, $email_otp, $e_count, $p_resend_time, $phone);
                            $stmt3->execute();
                            $stmt3->close();


                            $code = 201;
                            $msg = "Account not verified";
                            /* SMS and Mail*/
                            sendsmsotp($phone, $phone_otp);
                            sendemailotp($phone, $email_otp);
                        }
                    }else{
                        $code = 400;
                        $msg = "<li>Wrong password</li>";
                    }
                }
                else{
                    $code = 400;
                    $msg = "<li>Account Doesn't exist</li>";
                }
                $stmt->close();
                $conn->close();
            }else{
                $code = 400;
            }
        }
    }
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>