<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(login_check() == true){
    if(isset($_POST['xcsrf']) ){
        if($_POST['xcsrf'] == $csrf_token) {
            $f_name =htmlspecialchars($_POST["f_name"]);
            $m_name =htmlspecialchars($_POST["m_name"]);
            $l_name =htmlspecialchars($_POST["l_name"]);
            $gender = htmlspecialchars($_POST["gender"]);
            $dob =htmlspecialchars($_POST["dob"]);
            $shop_name =htmlspecialchars($_POST["shop_name"]);
            $shop_type =htmlspecialchars($_POST["shop_type"]);
            $alternet_phone =htmlspecialchars($_POST["alternet_phone"]);
            $email =htmlspecialchars($_POST["email"]);
            $alternet_email =htmlspecialchars($_POST["alternet_email"]);
            $locality =htmlspecialchars($_POST["locality"]);
            $address =htmlspecialchars($_POST["address"]);
            $state =htmlspecialchars($_POST["state"]);
            $dist =htmlspecialchars($_POST["dist"]);
            $pin =htmlspecialchars($_POST["pin"]);
            $govt_proof =htmlspecialchars($_POST["govt_proof"]);
            $govt_proof_no =htmlspecialchars($_POST["govt_proof_no"]);
            $gst =htmlspecialchars($_POST["gst"]);
            $pan =htmlspecialchars($_POST["pan"]);  
            if(empty($f_name)){
                $code = 400;
                $msg .= "<li>Enter First name</li>";
            }
            if(empty($l_name)){
                $code = 400;
                $msg .= "<li>Enter last name</li>";
            }
            if(empty($gender)){
                $code = 400;
                $msg .= "<li>Select gender</li>";
            } 
            if(empty($dob)){
                $code = 400;
                $msg .= "<li>Enter date of birth</li>";
            } 
            if(empty($shop_name)){
                $code = 400;
                $msg .= "<li>Enter shop name</li>";
            }
            if($shop_type <= 0){
                $code = 400;
                $msg .= "<li>Select shop type</li>";
            }
            if(empty($locality)){
                $code = 400;
                $msg .= "<li>Enter locality</li>";
            }
            if(empty($address)){
                $code = 400;
                $msg .= "<li>Enter address</li>";
            }
            if($state <= 0){
                $code = 400;
                $msg .= "<li>Select state</li>";
            }
            if($dist <= 0){
                $code = 400;
                $msg .= "<li>Select district</li>";
            }
            if(empty($pin)){
                $code = 400;
                $msg .= "<li>Enter pin no</li>";
            }
            if(empty($govt_proof)){
                $code = 400;
                $msg .= "<li>Select Govt proof type</li>";
            }
            if(empty($govt_proof_no)){
                $code = 400;
                $msg .= "<li>Enter Govt proof no</li>";
            }          
            if(empty($msg)){
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                if($_SESSION['shop_uid'] == null){
                    $stmt = $conn->prepare("SELECT id FROM admin WHERE phone = ?");        
                    $stmt->bind_param('s', $_SESSION['phone']);
                    $stmt->execute();
                    $stmt->store_result();
                    $stmt->bind_result($id);
                    if($stmt->num_rows() == 1){
                        $stmt->fetch();
                        $shop_uid = date('Y').'SDVN'.date('m').'N'.(00000+$id);

                        $stmt2 = $conn->prepare("INSERT INTO shop (shop_uid,shop_name,shop_type,phone,alternet_phone,email,alternet_email,locality,address,state,dist,pin,govt_proof,govt_proof_no,gst,pan) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"); 
                        $stmt2->bind_param('ssssssssssssssss', $shop_uid,$shop_name,$shop_type,$_SESSION['phone'],$alternet_phone,$email,$alternet_email,$locality,$address,$state,$dist,$pin,$govt_proof,$govt_proof_no,$gst,$pan);
                        $stmt2->execute();
                        $stmt2->close();

                        $stmt3 = $conn->prepare("UPDATE admin SET shop_uid = ?, f_name = ?, m_name = ?, l_name = ?, gender = ?, dob = ?  WHERE phone = ?"); 
                        $stmt3->bind_param('sssssss', $shop_uid, $f_name, $m_name, $l_name, $gender, $dob, $_SESSION['phone']);
                        $stmt3->execute();
                        $stmt3->close();

                        $_SESSION['shop_uid'] = $shop_uid;
                        $_SESSION['f_name'] = $f_name;
                        $code = 200;
                        $msg = "Success";
                    }
                    $stmt->close();
                    
                }else{
                    if($_SESSION['admin_status'] == 0){
                        $zero = 0;
                        $stmt2 = $conn->prepare("UPDATE `shop` SET `shop_name` = ?,`shop_type` = ?,`email` = ?,`alternet_phone` = ?,`alternet_email` = ?,`locality` = ?,`address` = ?,`state` = ?,`dist` = ?,`pin` = ?,`govt_proof` = ?,`govt_proof_no` = ?, `gst` = ?, `pan` = ?,`status` = ? WHERE `shop_uid` = ?"); 
                        $stmt2->bind_param('ssssssssssssssss', $shop_name,$shop_type,$email,$alternet_phone,$alternet_email,$locality,$address,$state,$dist,$pin,$govt_proof,$govt_proof_no,$gst,$pan, $zero, $_SESSION['shop_uid']);
                        $stmt2->execute();
                        $stmt2->close();
                        
                        $stmt3 = $conn->prepare("UPDATE admin SET f_name = ?, m_name = ?, l_name = ?, gender = ?, dob = ?  WHERE phone = ?"); 
                        $stmt3->bind_param('ssssss', $f_name, $m_name, $l_name, $gender, $dob, $_SESSION['phone']);
                        $stmt3->execute();
                        $stmt3->close();
                        $_SESSION['f_name'] = $f_name;
                        $code = 200;
                        $msg = "Success";
                    }
                    if($_SESSION['admin_status'] == 1){
                        //Can't change govt_proof, govt_proof_no after varified by super admin
                        $zero = 0;
                        $stmt2 = $conn->prepare("UPDATE `shop` SET `shop_name` = ?,`shop_type` = ?,`email` = ?,`alternet_phone` = ?,`alternet_email` = ?,`locality` = ?,`address` = ?,`state` = ?,`dist` = ?,`pin` = ?, `gst` = ?, `pan` = ?,`status` = ? WHERE `shop_uid` = ?"); 
                        $stmt2->bind_param('ssssssssssssss', $shop_name,$shop_type,$email,$alternet_phone,$alternet_email,$locality,$address,$state,$dist,$pin,$gst,$pan, $zero, $_SESSION['shop_uid']);
                        $stmt2->execute();
                        $stmt2->close();
                        
                        $stmt3 = $conn->prepare("UPDATE admin SET f_name = ?, m_name = ?, l_name = ?, gender = ?, dob = ?  WHERE phone = ?"); 
                        $stmt3->bind_param('ssssss', $f_name, $m_name, $l_name, $gender, $dob, $_SESSION['phone']);
                        $stmt3->execute();
                        $stmt3->close();
                        $_SESSION['f_name'] = $f_name;
                        $code = 200;
                        $msg = "Success";
                    }                    
                }
                $conn->close();
            }else{
                $code = 400;
            }
        }
    }
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>