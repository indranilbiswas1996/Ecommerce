<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(backend_full_access_check() == true){
    if(isset($_POST['xcsrf']) ){
        if($_POST['xcsrf'] == $csrf_token) {
            $new_mobile = htmlspecialchars($_POST["new_mobile"]);
            $confirm_password = htmlspecialchars($_POST["password"]);     
            if($new_mobile == ""){
                $code = 400;
                $msg .= "<li>Enter Mobile no</li>";
            }else{
                if(!preg_match("/^[6-9]{1}[0-9]{9}$/", $new_mobile)) {
                    $code = 400;
                    $msg .= "<li>Invalid mobile number</li>";
                }
            }
            if($confirm_password == ""){
                $code = 400;
                $msg .= "<li>Enter password</li>";
            }
            if(empty($msg)){
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                $stmt = $conn->prepare("SELECT password FROM admin WHERE shop_uid = ?");        
                $stmt->bind_param('s', $_SESSION['shop_uid']);
                $stmt->execute();
                $stmt->store_result();
                $stmt->bind_result($passwordHash);
                if($stmt->num_rows() == 1){
                    $stmt->fetch();
                    if(check_hash($confirm_password,$passwordHash)){
                        $stmt1 = $conn->prepare("SELECT id FROM admin WHERE phone = ?");
                        $stmt1->bind_param('s', $new_mobile);
                        $stmt1->execute();
                        $stmt1->store_result();
                        $stmt1->bind_result($id);
                        if($stmt1->num_rows() == 0){
                            $stmt2 = $conn->prepare("UPDATE admin SET phone = ? WHERE shop_uid = ?");        
                            $stmt2->bind_param('ss', $new_mobile, $_SESSION['shop_uid']);
                            $stmt2->execute();
                            $stmt2->close();
                            $stmt3 = $conn->prepare("UPDATE shop SET phone = ? WHERE shop_uid = ?");        
                            $stmt3->bind_param('ss', $new_mobile, $_SESSION['shop_uid']);
                            $stmt3->execute();
                            $stmt3->close();
			    $stmt4 = $conn->prepare("UPDATE admin_otp SET phone = ? WHERE phone = ?");        
                            $stmt4->bind_param('ss', $new_mobile, $_SESSION['phone']);
                            $stmt4->execute();
                            $stmt4->close();
                            $code = 200;
                            $msg = "Success";
                            $_SESSION['phone'] = $new_mobile;
                        }else{
                            $code = 400;
                            $msg = "Mobile number already exist";
                        }   
                        $stmt1->close();                     
                    }else{
                        $code = 404;
                        $msg = "<li>Wrong password</li>";
                    }
                }
                else{
                    $code = 400;
                    $msg = "<li>Account Does not exist</li>";
                }
                $stmt->close();
                $conn->close();
            }else{
                $code = 400;
            }
        }
    }
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>