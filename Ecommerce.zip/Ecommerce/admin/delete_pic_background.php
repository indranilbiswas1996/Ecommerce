<?php
include 'vugy8y90u78edcvjb/poivd9fj59746hbj.php';
$code = 0;
$msg = "";
if(backend_full_access_check() == true){
    if($_SESSION['shop_uid'] != null || $_SESSION['shop_uid'] != ""){
        if(isset($_POST['xcsrf']) ){
            if($_POST['xcsrf'] == $csrf_token) {
                include_once 'vugy8y90u78edcvjb/jlkio9786rtfkbjhu.php';
                $img_id = htmlspecialchars($_POST["img_id"]);
                $img = htmlspecialchars($_POST["img"]);
                if($img_id > 0){
                    //----- Update product_offer
                    $stmt = $conn->prepare("DELETE FROM product_pics WHERE id = ?"); 
                    $stmt->bind_param('s', $img_id);
                    $stmt->execute();
                    $stmt->close();
                    unlink('img/'.$img);
                    $code = 200;
                    $msg .= "Success";
                }
                $conn->close();
            }
        }
    }
}
echo json_encode(['code'=>$code, 'msg'=>$msg]);
?>